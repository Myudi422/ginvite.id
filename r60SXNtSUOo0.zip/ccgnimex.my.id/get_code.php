<?php
// Simpan URL halaman saat ini di $_SESSION['redirect_streaming']
$_SESSION['redirect_streaming'] = $_SERVER['REQUEST_URI'];

// Cek apakah pengguna Telegram sudah login
if (isset($_SESSION['telegram_id'])) {
    // Pengguna sudah login, tampilkan fitur pemotongan video

    // Ambil URL video yang ingin dipotong
    $videoUrl = $episodes[$_GET['episode'] - 1]['video_url']; // Ganti dengan URL video yang ingin dipotong

    // Inisialisasi Redis
    $redis = new Redis();
    $redis->connect('127.0.0.1', 6379);

    // Buat key Redis berdasarkan URL video
    $cacheKey = 'video_duration:' . md5($videoUrl);

    // Cek apakah informasi durasi video sudah ada di cache Redis
    $videoDuration = $redis->get($cacheKey);
    if ($videoDuration === false) {
        // Jika informasi durasi video belum ada di cache, ambil durasi video menggunakan FFprobe
        $ffprobeCommand = "ffprobe -i " . escapeshellarg($videoUrl) . " -show_entries format=duration -v quiet -of csv='p=0'";
        $videoDuration = round(floatval(shell_exec($ffprobeCommand)));

        // Simpan informasi durasi video ke cache Redis dengan waktu kadaluarsa 1 jam (3600 detik)
        $redis->set($cacheKey, $videoDuration, 3600);
    }

    // Konversi durasi video ke format hh:mm:ss
    function formatTime($seconds) {
        if (!is_numeric($seconds) || $seconds < 0) {
            return "00:00:00";
        }
        $hours = floor($seconds / 3600);
        $minutes = floor(($seconds % 3600) / 60);
        $secs = $seconds % 60;

        return sprintf("%02d:%02d:%02d", $hours, $minutes, $secs);
    }

    $videoDurationFormatted = formatTime($videoDuration);
    ?>

    <form action="" method="post">
        <div class="form-group">
            <label for="time_range">Potong Video | <span id="start_time_info">00:00:00</span> - <span id="end_time_info"><?php echo $videoDurationFormatted; ?></span></label>
            <input type="text" id="time_range_slider" name="time_range" />
            <small class="form-text text-muted"></small>
            <input type="hidden" name="start_time" id="start_time" required>
            <input type="hidden" name="end_time" id="end_time" required>
        </div>
        <br>

        <button type="submit" class="btn btn-primary" id="potong_video_btn">
            <span id="btn_text">Potong Video</span>
            <span id="loading_icon" style="display: none;">
                <i class="fa fa-spinner fa-spin"></i> Memuat...
            </span>
        </button>
    </form>

    <?php
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $start = $_POST['start_time'];
        $end = $_POST['end_time'];

        // Konversi waktu dalam format hh:mm:ss menjadi detik
        $startSeconds = strtotime("1970-01-01 $start UTC");
        $endSeconds = strtotime("1970-01-01 $end UTC");

        if ($startSeconds > $endSeconds || $startSeconds > $videoDuration || $endSeconds > $videoDuration) {
            echo '<div class="alert alert-danger mt-3">Masukkan waktu yang valid.</div>';
        } else {
            // Nama file output
            $outputPath = 'klip/hasil_potongan_' . time() . '.mp4'; // Menambahkan timestamp pada nama file

             // Eksekusi perintah FFmpeg dengan opsi -y untuk mengizinkan penggantian file output yang sudah ada:
            $command = "ffmpeg -y -i " . escapeshellarg($videoUrl) . " -ss $startSeconds -to $endSeconds -c:v copy -c:a copy " . escapeshellarg($outputPath);
            exec($command);
            if (file_exists($outputPath)) {
                // Tampilkan link untuk mengunduh video hasil potongan
                echo '<a href="' . $outputPath . '" target="_blank" rel="noopener noreferrer" class="mt-3 btn btn-success">Unduh Video Hasil Potongan</a>';
                echo '<br>';
            } else {
                echo '<div class="alert alert-danger mt-3">Terjadi kesalahan saat memotong video.</div>';
            }
        }
    }
    ?>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/ion-rangeslider/2.3.1/js/ion.rangeSlider.min.js"></script>
    <script>
        var $j = jQuery.noConflict(); // Using $j as a replacement for $

        $j(document).ready(function() {
            var timeRangeSlider = $j("#time_range_slider");
            var startTimeInput = $j("#start_time");
            var endTimeInput = $j("#end_time");
            var startTimeInfo = $j("#start_time_info");
            var endTimeInfo = $j("#end_time_info");
            var potongVideoBtn = $j("#potong_video_btn");
            var btnText = $j("#btn_text");
            var loadingIcon = $j("#loading_icon");

            timeRangeSlider.ionRangeSlider({
                type: "double",
                grid: true,
                min: 0,
                max: <?php echo $videoDuration; ?>,
                from: 0,
                to: <?php echo $videoDuration; ?>,
                step: 1,
                prettify: function(value) {
                    return formatTime(value);
                },
                onFinish: function(data) {
                    startTimeInput.val(formatTime(data.from));
                    endTimeInput.val(formatTime(data.to));
                    startTimeInfo.text(formatTime(data.from));
                    endTimeInfo.text(formatTime(data.to));
                }
            });

            function pad(number) {
                return (number < 10) ? "0" + number : number;
            }

            function formatTime(seconds) {
                if (isNaN(seconds) || seconds < 0) {
                    return "00:00:00";
                }
                var hours = Math.floor(seconds / 3600);
                var minutes = Math.floor((seconds % 3600) / 60);
                var secs = seconds % 60;

                return pad(hours) + ":" + pad(minutes) + ":" + pad(secs);
            }

            $j("form").on("submit", function() {
                potongVideoBtn.attr("disabled", true);
                btnText.hide();
                loadingIcon.show();
            });

            $j(document).ajaxStop(function() {
                potongVideoBtn.attr("disabled", false);
                loadingIcon.hide();
                btnText.show();
                btnText.text("Potong Video Lagi");
            });
        });
    </script>
<?php
} else {
    // Pengguna belum login, tampilkan info bahwa fitur pemotongan hanya untuk pengguna yang login dengan akun Telegram
    echo '<div class="alert alert-info mt-3" role="alert">
              <i class="fa fa-info-circle"></i> Fitur pemotongan video hanya tersedia untuk pengguna yang login dengan akun Telegram, silahkan <a href="login.php">login</a>.
          </div>';
}