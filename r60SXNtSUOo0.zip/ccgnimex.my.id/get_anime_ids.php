<?php
// Set up Anilist API
$clientId = '10813';
$clientSecret = 'j4jtW20LRQ4YrA6ClvZu11E0VlTcghNZijwCJXoa';

// Get access token using client_credentials grant
$accessToken = getAccessToken($clientId, $clientSecret);

// Get selected data source from POST data
$selectedDataSource = $_POST['data_source'];

// Get anime IDs from selected data source
if ($selectedDataSource === 'database') {
  // Get anime IDs from database
  $animeIds = getAnimeIdsFromDatabase();
} else {
  // Get anime IDs from Anilist
  $animeIds = getAnimeIdsFromAnilist($accessToken);
}

// Return anime IDs as JSON
header('Content-Type: application/json');
echo json_encode($animeIds);

function getAccessToken($clientId, $clientSecret) {
    // Set up cURL
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://anilist.co/api/v2/oauth/token');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
        'grant_type' => 'client_credentials',
        'client_id' => $clientId,
        'client_secret' => $clientSecret,
    ]));
    // Execute cURL request and get response
    $response = curl_exec($ch);
    curl_close($ch);

    // Decode JSON response and return access token
    return json_decode($response)->access_token;
}

function getAnimeIdsFromDatabase() {
  // Set up database connection (replace with your own connection details)
  $dbHost = 'localhost';
  $dbUsername = 'ccgnimex';
  $dbPassword = 'aaaaaaac';
  $dbName = 'ccgnimex';
  $db = new mysqli($dbHost,$dbUsername,$dbPassword,$dbName);

  // Check connection
  if ($db->connect_error) {
      die("Connection failed: " . $db->connect_error);
  }

  // Execute SQL query to get anime IDs from database
  $sql = "SELECT anime_id FROM nonton";
  $result = $db->query($sql);

  // Check if query was successful
  if ($result === false) {
    die("Error executing query: " . $db->error);
  }

  // Fetch all rows as an array
  $rows = $result->fetch_all(MYSQLI_ASSOC);

  // Extract anime IDs from rows
  $animeIds = array_column($rows, 'anime_id');

  // Return anime IDs
  return $animeIds;
}
function getAnimeIdsFromAnilist($accessToken) {
    // Set up query and variables
    $query = '
query ($page: Int, $perPage: Int) {
    Page (page: $page, perPage: $perPage) {
        media {
            id
        }
    }
}
';
    $variables = [
        'page' => 1,
        'perPage' => 10,
    ];

    // Execute query and get results
    $results = executeQuery($query, $variables, $accessToken);

    // Extract anime IDs from results
    $animeIds = array_column($results['data']['Page']['media'], 'id');

    // Return anime IDs
    return $animeIds;
}