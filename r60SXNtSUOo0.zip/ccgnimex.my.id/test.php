<?php
// Start the session
session_start();


// When the user is not logged in, go to the login page
if (!isset($_SESSION['logged-in'])) {
    die(header('Location: login.php'));
}


// Import database connection and class
require('db-config.php');

include 'jumlah-user.php';


// Get current logged in user data with session
$user_data = $db->Select(
    "SELECT *
        FROM `users_web`
            WHERE `telegram_id` = :id",
    [
        'id' => $_SESSION['telegram_id']
    ]
);


// Define clean variables with user data
$firstName        = $user_data[0]['first_name'];
$lastName         = $user_data[0]['last_name'];
$profilePicture   = $user_data[0]['profile_picture'];
$telegramID       = $user_data[0]['telegram_id'];
$telegramUsername = $user_data[0]['telegram_username'];
$userID           = $user_data[0]['id'];



if (!is_null($profilePicture)) {
    $FOTO = '<span class="d-inline-block me-2 align-middle">';
    $FOTO .= '<img class="border rounded-circle img-profile" src="' . $profilePicture . '?v=' . time() . '" width="32" height="32">';
    $FOTO .= '</span>';
};


#ini untuk nama header
if (!is_null($lastName)) {
    // Display first name and last name
    $NAMA = '<span class="d-none d-lg-inline">' . $firstName . ' ' . $lastName . '</span>';
} else {
    // Display first name
    $NAMA = '<span class="d-none d-lg-inline">' . $firstName . '</span>';
    $NAMA .= '<span class="d-inline-block d-lg-none">' . $firstName . '</span>';
};


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Cari Anime | Kategori</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i&amp;display=swap">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
    
    <style>
/* Magnific Popup CSS */
.mfp-bg {
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 502;
  overflow: hidden;
  position: fixed;
  background: #0b0b0b;
  opacity: 0.8;
  filter: alpha(opacity=80); }

.mfp-wrap {
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 503;
  position: fixed;
  outline: none !important;
  -webkit-backface-visibility: hidden; }

.mfp-container {
  height: 100%;
  text-align: center;
  position: absolute;
  width: 100%;
  height: 100%;
  left: 0;
  top: 0;
  padding: 0 8px;
  -webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  box-sizing: border-box; }

.mfp-container:before {
  content: '';
  display: inline-block;
  height: 100%;
  vertical-align: middle; }

.mfp-align-top .mfp-container:before {
  display: none; }

.mfp-content {
  position: relative;
  display: inline-block;
  vertical-align: middle;
  margin: 0 auto;
  text-align: left;
  z-index: 505; }

.mfp-inline-holder .mfp-content,
.mfp-ajax-holder .mfp-content {
  width: 100%;
  cursor: auto; }

.mfp-ajax-cur {
  cursor: progress; }

.mfp-zoom-out-cur,
.mfp-zoom-out-cur .mfp-image-holder .mfp-close {
  cursor: -moz-zoom-out;
  cursor: -webkit-zoom-out;
  cursor: zoom-out; }

.mfp-zoom {
  cursor: pointer;
  cursor: -webkit-zoom-in;
  cursor: -moz-zoom-in;
  cursor: zoom-in; }

.mfp-auto-cursor .mfp-content {
  cursor: auto; }

.mfp-close,
.mfp-arrow,
.mfp-preloader,
.mfp-counter {
  -webkit-user-select: none;
  -moz-user-select: none;
  user-select: none; }

.mfp-loading.mfp-figure {
  display: none; }

.mfp-hide {
  display: none !important; }

.mfp-preloader {
  color: #cccccc;
  position: absolute;
  top: 50%;
  width: auto;
  text-align: center;
  margin-top: -0.8em;
  left: 8px;
  right: 8px;
  z-index: 504; }

.mfp-preloader a {
  color: #cccccc; }

.mfp-preloader a:hover {
  color: white; }

.mfp-s-ready .mfp-preloader {
  display: none; }

.mfp-s-error .mfp-content {
  display: none; }

button.mfp-close,
button.mfp-arrow {
  overflow: visible;
  cursor: pointer;
  background: transparent;
  border: 0;
  -webkit-appearance: none;
  display: block;
  padding: 0;
  z-index: 506; }

button::-moz-focus-inner {
  padding: 0;
  border: 0; }

.mfp-close {
  width: 44px;
  height: 44px;
  line-height: 44px;
  position: absolute;
  right: 0;
  top: 0;
  text-decoration: none;
  text-align: center;
  opacity: 0.65;
  padding: 0 0 18px 10px;
  color: white;
  font-style: normal;
  font-size: 28px;
  font-family: Arial, Baskerville, monospace; }
  .mfp-close:hover, .mfp-close:focus {
    opacity: 1; }
  .mfp-close:active {
    top: 1px; }

.mfp-close-btn-in .mfp-close {
  color: #333333; }

.mfp-image-holder .mfp-close,
.mfp-iframe-holder .mfp-close {
  color: white;
  right: -6px;
  text-align: right;
  padding-right: 6px;
  width: 100%; }

.mfp-counter {
  position: absolute;
  top: 0;
  right: 0;
  color: #cccccc;
  font-size: 12px;
  line-height: 18px; }

.mfp-arrow {
  position: absolute;
  top: 0;
  opacity: 0.65;
  margin: 0;
  top: 50%;
  margin-top: -55px;
  padding: 0;
  width: 90px;
  height: 110px;
  -webkit-tap-highlight-color: rgba(0, 0, 0, 0); }

.mfp-arrow:active {
  margin-top: -54px; }

.mfp-arrow:hover,
.mfp-arrow:focus {
  opacity: 1; }

.mfp-arrow:before, .mfp-arrow:after,
.mfp-arrow .mfp-b,
.mfp-arrow .mfp-a {
  content: '';
  display: block;
  width: 0;
  height: 0;
  position: absolute;
  left: 0;
  top: 0;
  margin-top: 35px;
  margin-left: 35px;
  border: solid transparent; }
.mfp-arrow:after,
.mfp-arrow .mfp-a {
  opacity: 0.8;
  border-top-width: 12px;
  border-bottom-width: 12px;
  top: 8px; }
.mfp-arrow:before,
.mfp-arrow .mfp-b {
  border-top-width: 20px;
  border-bottom-width: 20px; }

.mfp-arrow-left {
  left: 0; }
  .mfp-arrow-left:after,
  .mfp-arrow-left .mfp-a {
    border-right: 12px solid black;
    left: 5px; }
  .mfp-arrow-left:before,
  .mfp-arrow-left .mfp-b {
    border-right: 20px solid white; }

.mfp-arrow-right {
  right: 0; }
  .mfp-arrow-right:after,
  .mfp-arrow-right .mfp-a {
    border-left: 12px solid black;
    left: 3px; }
  .mfp-arrow-right:before,
  .mfp-arrow-right .mfp-b {
    border-left: 20px solid white; }

.mfp-iframe-holder {
  padding-top: 40px;
  padding-bottom: 40px; }

.mfp-iframe-holder .mfp-content {
  line-height: 0;
  width: 100%;
  max-width: 900px; }

.mfp-iframe-scaler {
  width: 100%;
  height: 0;
  overflow: hidden;
  padding-top: 56.25%; }

.mfp-iframe-scaler iframe {
  position: absolute;
  top: -3px;
  left: 0;
  width: 100%;
  height: 100%;
  box-shadow: 0 0 8px rgba(0, 0, 0, 0.6);
  background: black; }

.mfp-iframe-holder .mfp-close {
  top: -43px; }

/* Main image in popup */
img.mfp-img {
  width: auto;
  max-width: 100%;
  height: auto;
  display: block;
  line-height: 0;
  -webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  box-sizing: border-box;
  padding: 40px 0 40px;
  margin: 0 auto; }

/* The shadow behind the image */
.mfp-figure:after {
  content: '';
  position: absolute;
  left: 0;
  top: 40px;
  bottom: 40px;
  display: block;
  right: 0;
  width: auto;
  height: auto;
  z-index: -1;
  box-shadow: 0 0 8px rgba(0, 0, 0, 0.6); }

.mfp-figure {
  line-height: 0; }

.mfp-bottom-bar {
  margin-top: -36px;
  position: absolute;
  top: 100%;
  left: 0;
  width: 100%;
  cursor: auto; }

.mfp-title {
  text-align: left;
  line-height: 18px;
  color: #f3f3f3;
  word-break: break-word;
  padding-right: 36px; }

.mfp-figure small {
  color: #bdbdbd;
  display: block;
  font-size: 12px;
  line-height: 14px; }

.mfp-image-holder .mfp-content {
  max-width: 100%; }

.mfp-gallery .mfp-image-holder .mfp-figure {
  cursor: pointer; }

@media screen and (max-width: 800px) and (orientation: landscape), screen and (max-height: 300px) {
  /**
   * Remove all paddings around the image on small screen
   */
  .mfp-img-mobile .mfp-image-holder {
    padding-left: 0;
    padding-right: 0; }

  .mfp-img-mobile img.mfp-img {
    padding: 0; }

  /* The shadow behind the image */
  .mfp-img-mobile .mfp-figure:after {
    top: 0;
    bottom: 0; }

  .mfp-img-mobile .mfp-bottom-bar {
    background: rgba(0, 0, 0, 0.6);
    bottom: 0;
    margin: 0;
    top: auto;
    padding: 3px 5px;
    position: fixed;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    box-sizing: border-box; }

  .mfp-img-mobile .mfp-bottom-bar:empty {
    padding: 0; }

  .mfp-img-mobile .mfp-counter {
    right: 5px;
    top: 3px; }

  .mfp-img-mobile .mfp-close {
    top: 0;
    right: 0;
    width: 35px;
    height: 35px;
    line-height: 35px;
    background: rgba(0, 0, 0, 0.6);
    position: fixed;
    text-align: center;
    padding: 0; }

  .mfp-img-mobile .mfp-figure small {
    display: inline;
    margin-left: 5px; } }
@media all and (max-width: 800px) {
  .mfp-arrow {
    -webkit-transform: scale(0.75);
    transform: scale(0.75); }

  .mfp-arrow-left {
    -webkit-transform-origin: 0;
    transform-origin: 0; }

  .mfp-arrow-right {
    -webkit-transform-origin: 100%;
    transform-origin: 100%; }

  .mfp-container {
    padding-left: 6px;
    padding-right: 6px; } }
.mfp-ie7 .mfp-img {
  padding: 0; }
.mfp-ie7 .mfp-bottom-bar {
  width: 600px;
  left: 50%;
  margin-left: -300px;
  margin-top: 5px;
  padding-bottom: 5px; }
.mfp-ie7 .mfp-container {
  padding: 0; }
.mfp-ie7 .mfp-content {
  padding-top: 44px; }
.mfp-ie7 .mfp-close {
  top: 0;
  right: 0;
  padding-top: 0; }
</style>
</head>

<body id="page-top" class="sidebar-toggled">
    <div id="wrapper">
        <nav class="navbar navbar-dark align-items-start sidebar sidebar-dark accordion bg-gradient-primary p-0 toggled">
            <div class="container-fluid d-flex flex-column p-0"><a class="navbar-brand d-flex justify-content-center align-items-center sidebar-brand m-0" href="#">
                    <div class="sidebar-brand-icon">
  <img src="/icon1/apple-icon-144x144.png" alt="Icon" style="width: 50px; height: 50px;" />
</div>


                    <div class="sidebar-brand-text mx-3"><span>ccgnimex</span></div>
                </a>
                <hr class="sidebar-divider my-0">
                <ul class="navbar-nav text-light" id="accordionSidebar">
                    <li class="nav-item"><a class="nav-link" href="/"><i class="fas fa-tachometer-alt"></i><span> Beranda</span></a></li>
                    <li class="nav-item"><a class="nav-link" href="#"><i class="fas fa-user"></i><span> Progress</span></a></li>
                    <li class="nav-item"><a class="nav-link" href="komik"><i class="fas fa-book"></i><span> Manga</span></a></li>
                        <li class="nav-item"><a class="nav-link active" href="kategori"><i class="fas fa-table"></i><span> Kategori</span></a></li>
                        <li class="nav-item"><a class="nav-link" href="#"><i class="fas fa-trophy"></i><span> Leaderboard</span></a></li>
                </ul>
                <div class="text-center d-none d-md-inline"><button class="btn rounded-circle border-0" id="sidebarToggle" type="button"></button></div>
            </div>
        </nav>
        <div class="d-flex flex-column" id="content-wrapper">
            <div id="content">
                <nav class="navbar navbar-light navbar-expand bg-white shadow mb-4 topbar static-top">
                    <div class="container-fluid"><button class="btn btn-link d-md-none rounded-circle me-3" id="sidebarToggleTop" type="button"><i class="fas fa-bars"></i></button>
                        <!-- Create a search form -->
<form class="d-none d-sm-inline-block me-auto ms-md-3 my-2 my-md-0 mw-100 navbar-search" method="GET" action="https://ccgnimex.my.id/">
    <div class="input-group">
        <input class="bg-light form-control border-0 small" type="text" name="search" placeholder="Search for ...">
        <button class="btn btn-primary py-0" type="submit"><i class="fas fa-search"></i></button>
    </div>
</form>
                        <ul class="navbar-nav flex-nowrap ms-auto">
                            <li class="nav-item dropdown d-sm-none no-arrow"><a class="dropdown-toggle nav-link" aria-expanded="false" data-bs-toggle="dropdown" href="#"><i class="fas fa-search"></i></a>
                                <div class="dropdown-menu dropdown-menu-end p-3 animated--grow-in" aria-labelledby="searchDropdown">
                                    <form class="me-auto navbar-search w-100" method="GET" action="https://ccgnimex.my.id/">
    <div class="input-group">
        <input class="bg-light form-control border-0 small" type="text" name="search" placeholder="Search for ...">
        <div class="input-group-append">
            <button class="btn btn-primary py-0" type="submit"><i class="fas fa-search"></i></button>
        </div>
    </div>
</form>
                                </div>
                            </li>
                                                       <?php
// Set up Anilist API
$clientId = '10813';
$clientSecret = 'j4jtW20LRQ4YrA6ClvZu11E0VlTcghNZijwCJXoa';

// Get access token using client_credentials grant
$accessToken = getAccessToken($clientId, $clientSecret);

function getAccessToken($clientId, $clientSecret) {
    $tokenUrl = 'https://anilist.co/api/v2/oauth/token';
    
    $postData = array(
        'grant_type' => 'client_credentials',
        'client_id' => $clientId,
        'client_secret' => $clientSecret
    );

    $ch = curl_init($tokenUrl);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $response = curl_exec($ch);
    curl_close($ch);

    $data = json_decode($response, true);

    if (isset($data['access_token'])) {
        return $data['access_token'];
    } else {
        return null;
    }
}

// Database connection
$db_host = "localhost";
$db_name = "ccgnimex";
$db_user = "ccgnimex";
$db_password = "aaaaaaac";

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

session_start();
if (isset($_SESSION['telegram_id'])) {
    $telegramId = $_SESSION['telegram_id'];

    $sql = "SELECT * FROM notif_anime WHERE telegram_id = $telegramId AND is_read = 0 ORDER BY created_at DESC";
    $result = $conn->query($sql);

    $api_url = "https://graphql.anilist.co/";
?>

<li class="nav-item dropdown no-arrow mx-1">
    <div class="nav-item dropdown no-arrow">
        <a class="dropdown-toggle nav-link" aria-expanded="false" data-bs-toggle="dropdown" href="#">
            <span class="badge bg-danger badge-counter"><?php echo $result->num_rows; ?></span>
            <i class="fas fa-bell fa-fw"></i>
        </a>
        <div class="dropdown-menu dropdown-menu-end dropdown-list animated--grow-in">
            <h6 class="dropdown-header">Alerts Center</h6>
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $animeId = $row['anilist_id'];
                    $notificationDate = date('F j, Y', strtotime($row['notification_date']));
                    $episode = $row['episode'];

                    $query = '{
                        Media(id: '.$animeId.', type: ANIME) {
                            id
                            title {
                                romaji
                            }
                            coverImage {
                                medium
                            }
                        }
                    }';

                    $ch = curl_init($api_url);
                    curl_setopt($ch, CURLOPT_POST, 1);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(['query' => $query]));
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_HTTPHEADER, [
                        'Content-Type: application/json',
                        'Authorization: Bearer ' . $accessToken,
                    ]);

                    $response = curl_exec($ch);
                    curl_close($ch);

                    $data = json_decode($response, true);

                    if (isset($data['data']['Media'])) {
                        $anime = $data['data']['Media'];
                        $title = $anime['title']['romaji'];
                        $coverImage = $anime['coverImage']['medium'];
                    }
            ?>
                    <a class="dropdown-item d-flex align-items-center" href="streaming.php?id=<?php echo $animeId; ?>&episode=<?php echo $episode; ?>" onclick="markAsRead(<?php echo $row['id']; ?>)">
                        <div class="me-3">
                            <img src="<?php echo $coverImage; ?>" alt="Anime Cover" width="40" height="40" class="rounded-circle">
                        </div>
                        <div>
                            <span class="small text-gray-500"><?php echo $notificationDate; ?></span>
                            <p><strong><?php echo $title; ?></strong> (Episode <?php echo $episode; ?>) Sudah Tersedia</p>
                        </div>
                    </a>
            <?php
                }
            } else {
                echo '<p class="dropdown-item text-center small text-gray-500">Tidak ada notifikasi tersedia, silahkan aktifkan notifikasi anime, dihalaman streaming, agar nanti muncul, jika admin update</p>';
            }
            ?>
            <a class="dropdown-item text-center small text-gray-500" href="#">Show All Alerts</a>
        </div>
    </div>
</li>

<script>
function markAsRead(notificationId) {
    $.ajax({
        url: "update_notification.php",
        method: "POST",
        data: { notification_id: notificationId },
        success: function(response) {
            console.log("Notification marked as read");
            // Atur tampilan notifikasi sesuai keinginan Anda
        },
        error: function(error) {
            console.error("Error updating notification:", error);
        }
    });
}
</script>

<?php
    $conn->close();
} else {
}
?>
                            <li class="nav-item dropdown no-arrow mx-1">
                                <div class="nav-item dropdown no-arrow"><a class="dropdown-toggle nav-link" aria-expanded="false" data-bs-toggle="dropdown" href="#"><span class="badge bg-danger badge-counter">7</span><i class="fas fa-envelope fa-fw"></i></a>
                                    <div class="dropdown-menu dropdown-menu-end dropdown-list animated--grow-in">
                                        <h6 class="dropdown-header">alerts center</h6><a class="dropdown-item d-flex align-items-center" href="#">
                                            <div class="dropdown-list-image me-3"><img class="rounded-circle" src="assets/img/avatars/avatar4.jpeg">
                                                <div class="bg-success status-indicator"></div>
                                            </div>
                                            <div class="fw-bold">
                                                <div class="text-truncate"><span>Hi there! I am wondering if you can help me with a problem I've been having.</span></div>
                                                <p class="small text-gray-500 mb-0">Emily Fowler - 58m</p>
                                            </div>
                                        </a><a class="dropdown-item d-flex align-items-center" href="#">
                                            <div class="dropdown-list-image me-3"><img class="rounded-circle" src="assets/img/avatars/avatar2.jpeg">
                                                <div class="status-indicator"></div>
                                            </div>
                                            <div class="fw-bold">
                                                <div class="text-truncate"><span>I have the photos that you ordered last month!</span></div>
                                                <p class="small text-gray-500 mb-0">Jae Chun - 1d</p>
                                            </div>
                                        </a><a class="dropdown-item d-flex align-items-center" href="#">
                                            <div class="dropdown-list-image me-3"><img class="rounded-circle" src="assets/img/avatars/avatar3.jpeg">
                                                <div class="bg-warning status-indicator"></div>
                                            </div>
                                            <div class="fw-bold">
                                                <div class="text-truncate"><span>Last month's report looks great, I am very happy with the progress so far, keep up the good work!</span></div>
                                                <p class="small text-gray-500 mb-0">Morgan Alvarez - 2d</p>
                                            </div>
                                        </a><a class="dropdown-item d-flex align-items-center" href="#">
                                            <div class="dropdown-list-image me-3"><img class="rounded-circle" src="assets/img/avatars/avatar5.jpeg">
                                                <div class="bg-success status-indicator"></div>
                                            </div>
                                            <div class="fw-bold">
                                                <div class="text-truncate"><span>Am I a good boy? The reason I ask is because someone told me that people say this to all dogs, even if they aren't good...</span></div>
                                                <p class="small text-gray-500 mb-0">Chicken the Dog · 2w</p>
                                            </div>
                                        </a><a class="dropdown-item text-center small text-gray-500" href="#">Show All Alerts</a>
                                    </div>
                                </div>
                                <div class="shadow dropdown-list dropdown-menu dropdown-menu-end" aria-labelledby="alertsDropdown"></div>
                            </li>
                            <div class="d-none d-sm-block topbar-divider"></div>
                            <li class="nav-item dropdown no-arrow">
                                <div class="nav-item dropdown show no-arrow"><a class="dropdown-toggle nav-link" aria-expanded="true" data-bs-toggle="dropdown" href="#"><span class="d-none d-lg-inline me-2 text-gray-600 small"><?= $NAMA ?></span><?= $FOTO ?></a>
                                <div class="dropdown-menu shadow dropdown-menu-end animated--grow-in" data-bs-popper="none"><a class="dropdown-item" href="#"><i class="fas fa-user fa-sm fa-fw me-2 text-gray-400"></i>&nbsp;Profile</a><a class="dropdown-item" href="#"><i class="fas fa-cogs fa-sm fa-fw me-2 text-gray-400"></i>&nbsp;Settings</a><a class="dropdown-item" href="#"><i class="fas fa-list fa-sm fa-fw me-2 text-gray-400"></i>&nbsp;Activity log</a>
                                        <div class="dropdown-divider"></div><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt fa-sm fa-fw me-2 text-gray-400"></i>&nbsp;Logout</a>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </nav>
                
                
<?php

// Set up query and variables
$query = '
query ($page: Int, $perPage: Int, $genre_in: [String], $format: [MediaFormat], $tag_in: [String]) {
  Page (page: $page, perPage: $perPage) {
    media (genre_in: $genre_in, format_in: $format, tag_in: $tag_in, type: ANIME) {
      id
      title {
        romaji
        english
        native
      }
      coverImage {
        large
      }
      trailer {
        id
        site
        thumbnail
      }
      averageScore
    }
  }
}
';

// Get selected status from URL or use default value
$selectedStatus = isset($_GET['status']) ? $_GET['status'] : '';

// Check if "ALL" status is selected
if ($selectedStatus === 'ALL') {
  $selectedStatus = '';
}

// Get selected genres from URL or use default value
$selectedGenres = isset($_GET['genres']) ? (array)$_GET['genres'] : [];

// Get selected formats from URL or use default value
$selectedFormats = isset($_GET['formats']) ? (array)$_GET['formats'] : [];

// Get selected tags from URL or use default value
$selectedTags = isset($_GET['tags']) ? (array)$_GET['tags'] : [];

// Set up variables for query
$variables = [
  'page' => $currentPage,
  'perPage' => 8,
  'genre_in' => $selectedGenres,
  'format' => $selectedFormats,
  'status_in' => $selectedStatus,
  'tag_in' => $selectedTags, // Add selected tags to variables
];

// Execute query and get results
$results = executeQuery($query, $variables, $accessToken);

$availableStatus = [
  'FINISHED',
  'RELEASING',
  'NOT_YET_RELEASED',
  'CANCELLED',
  'HIATUS',
];

// Set up list of available genres
$availableGenres = [
  'Action',
  'Adventure',
  'Comedy',
  'Drama',
  'Ecchi',
  'Fantasy',
  'Horror',
  'Mahou Shoujo',
  'Mecha',
  'Music',
  'Mystery',
  'Psychological',
  'Romance',
  'Sci-Fi',
  'Slice of Life',
  'Sports',
  'Supernatural',
  'Thriller',
];

// Set up list of available formats
$availableFormats = [
  'TV',
  'TV_SHORT',
  'MOVIE',
  'SPECIAL',
  'OVA',
  'ONA',
  'MUSIC',
];


function executeQuery($query, $variables, $accessToken) {
    // Set up cURL
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://graphql.anilist.co');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Accept: application/json',
        'Authorization: Bearer ' . $accessToken,
    ]);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
        'query' => $query,
        'variables' => $variables,
    ]));
    // Execute cURL request and get response
    $response = curl_exec($ch);
    curl_close($ch);

    // Decode JSON response and return data
    return json_decode($response,true);
}
?>

<!-- Add jQuery library -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- Add custom styles for genre selection menu -->
<style>
  .form-group {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    margin-right: 1rem; /* Penambahan margin kanan */
  }

  .form-group label {
    margin-right: 1rem;
  }

  .form-check {
    margin-right: 1rem;
    margin-left: 10px; /* Penambahan margin kiri */
  }

  .form-check-input {
    margin-top: 0.3rem;
  }

  /* Add custom styles for media grid */
  #media-grid .col-sm-6.col-md-4.col-lg-3 {
    display: flex;
  }

  #media-grid .card {
    width: 100%;
    border: 1px solid #dee2e6;
  }

  /* Hide the genres by default */
  .genre-dropdown-content {
    display: none;
  }
</style>
<!-- Display status selection menu using Bootstrap 4 -->
<div class="container">
    
<div class="alert alert-info alert-dismissible fade show" role="alert" id="notification">
  <strong><i class="fas fa-info-circle"></i> Terkait keterangan tersedianya anime untuk didownload & ditonton, berikut infonya:</strong>
  <ul class="mt-3 mb-0">
    <li><i class="fas fa-check"></i> Stream : Hanya tersedia untuk ditonton & diunduh per episode</li>
    <li><i class="fas fa-check"></i> Batch : Hanya tersedia versi batch nya tanpa ada streaming di web</li>
    <li><i class="fas fa-check"></i> Stream & Batch : Itu tersedia semua</li>
  </ul>
</div>



  <form method="get">
      <label for="status-select">Status:</label>
      <select id="status-select" class="form-control">
        <option value="">All</option>
        <option value="FINISHED">Finished</option>
        <option value="RELEASING">Releasing</option>
        <option value="NOT_YET_RELEASED">Not Yet Released</option>
        <option value="CANCELLED">Cancelled</option>
      </select>
  </form>
</div>
<br>
<!-- Display media format selection menu using Bootstrap 4 -->
<div class="container">
  <form method="get">
      <label for="format-select">Format:</label>
      <select id="format-select" class="form-control">
        <option value="">All</option>
        <option value="TV">TV</option>
        <option value="TV_SHORT">TV Short</option>
        <option value="MOVIE">Movie</option>
        <option value="SPECIAL">Special</option>
        <option value="OVA">OVA</option>
        <option value="ONA">ONA</option>
        <option value="MUSIC">Music</option>
      </select>
  </form>
</div>

<br>
<!-- Display genre selection menu using Bootstrap 4 -->
<div class="container">
  <form method="get">
      <label for="genre-select">Genre:</label>
      <div id="genre-select" class="form-control genre-select-scroll">
        <?php $genresPerRow = 3; ?>
        <div class="row">
          <?php $counter = 0; ?>
          <?php foreach ($availableGenres as $genre): ?>
            <div class="col-sm-<?php echo 12 / $genresPerRow; ?> col-md-<?php echo 12 / $genresPerRow; ?>">
              <div class="form-check">
                <input class="form-check-input" type="checkbox" name="genres[]" value="<?= htmlspecialchars($genre) ?>" id="<?= htmlspecialchars($genre) ?>"<?= in_array($genre,$selectedGenres)?' checked':'' ?>>
                <label class="form-check-label" for="<?= htmlspecialchars($genre) ?>"><?= htmlspecialchars($genre) ?></label>
              </div>
            </div>
            <?php $counter++; ?>
            <?php if ($counter % $genresPerRow == 0): ?>
              </div><div class="row">
            <?php endif; ?>
          <?php endforeach; ?>
        </div>
      </div>
  </form>
</div>

<style>
  /* Additional CSS for genre selection */
  .genre-select-scroll {
    max-height: 200px;
    overflow-y: auto;
  }
</style>

<br>

<script>
  // Show/hide genres when the dropdown is clicked
  const dropdown = document.getElementById('genre-dropdown');
  const genreDropdownContent = document.querySelector('.genre-dropdown-content');

  dropdown.addEventListener('click', function() {
    genreDropdownContent.classList.toggle('show');
  });

  // Close the dropdown if the user clicks outside of it
  window.addEventListener('click', function(event) {
    if (!event.target.matches('.btn-secondary')) {
      if (genreDropdownContent.classList.contains('show')) {
        genreDropdownContent.classList.remove('show');
      }
    }
  });
  
  // Show/hide status options when the dropdown is clicked
const statusDropdown = document.getElementById('status-dropdown');
const statusDropdownContent = document.querySelector('.status-dropdown-content');

statusDropdown.addEventListener('click', function() {
  statusDropdownContent.classList.toggle('show');
});

// Close the dropdown if the user clicks outside of it
window.addEventListener('click', function(event) {
  if (!event.target.matches('.btn-secondary')) {
    if (statusDropdownContent.classList.contains('show')) {
      statusDropdownContent.classList.remove('show');
    }
  }
});


// Handle change event on status checkboxes
$('.form-check-input').on('change', function() {
  currentPage = 1; // Reset current page to 1
  loadMedia();
});
</script>

<style>
#media-grid .col-sm-4.col-md-3.col-lg-3 {
  display: flex;
  margin-bottom: 1rem;
}

#media-grid .card {
  width: 100%;
  border: 1px solid #dee2e6;
}

.rating {
  position: absolute;
  top: 8px;
  right: 16px;
  color: white;
  background-color: rgba(0, 0, 0, 0.7);
  padding: 4px;
  border-radius: 4px;
}

.fa-star {
  color: yellow;
}

.score {
  margin-left: 4px; /* Atur jarak spasi ke kiri */
}

/* CSS for mobile view */
@media (max-width: 576px) {
  .rating {
    font-size: 12px; /* Ubah ukuran font untuk tampilan mobile */
  }
}


.animex-trailer {
  position: absolute;
  top: 5px;
  left: 5px;
  background-color: rgba(0, 0, 0, 0.7);
  color: white;
  padding: 5px;
  margin-left: 10px
  border-radius: 5px;
  cursor: pointer;
}

.animex-trailer:hover {
  background-color: #007bff;
}

.animex-trailer i {
  font-size: 16px;
}

.animex-watched {
  position: absolute;
  bottom: 5px;
  right: 5px;
  background-color: rgba(0, 0, 0, 0.7);
  color: white;
  padding: 5px;
  border-radius: 5px;
  cursor: pointer;
}

.animex-watched i {
  margin-right: 5px;
}
</style>

<style> #media-grid .col-sm-4.col-md-3.col-lg-3 { display: flex; margin-bottom: 1rem; } #media-grid .card { width: 100%; border: 1px solid #dee2e6; } </style>

  <!-- Display results in a grid using Bootstrap 4 -->
  <div class="container">
    <div class="row" id="media-grid">
      <?php foreach ($results['data']['Page']['media'] as $media): ?>
        <?php 
          $title = mb_strimwidth($media['title']['romaji'], 0, 24, '...');
          $animeId = $media['id']; // Ambil ID anime
          $averageScore = $media['averageScore']; // Ambil skor rata-rata
          $trailerId = $media['trailer']['id'] ?? null; // Ambil ID trailer jika tersedia, jika tidak set sebagai null
        ?>
        <div class="col-6 col-sm-4 col-md-3 col-lg-3">
          <div class="card h-100">
            <a href="https://ccgnimex.my.id/anime_detail?id=<?= $animeId ?>">
              <img class="card-img-top img-fluid" src="<?= $media['coverImage']['large'] ?>" alt="<?= htmlspecialchars($title) ?>">
              <!-- Tambahkan icon bintang dan rating di sini -->
              <div class="rating">
                <span class="fa fa-star checked"></span>
                <?= htmlspecialchars($averageScore) ?>
              </div>
              <?php if ($trailerId): ?>
                <a class="popup-youtube" href="https://www.youtube.com/watch?v=<?= $trailerId ?>" target="_blank">
                  <div class="animex-trailer" style="margin-left: 4px;">
                    <i class="fas fa-film"></i>
                  </div>
                </a>
              <?php endif; ?>
              <div class="card-body text-center">
                <h5 class="card-title"><?= htmlspecialchars($title) ?></h5>
              </div>
            </a>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- Include jQuery library -->
  <script src="https://code.jquery.com/jquery-3.0.0.min.js"></script>
  
  <!-- Include Magnific Popup library -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/jquery.magnific-popup.min.js"></script>
  
  <!-- Your JavaScript code -->
  <script>
    $(document).ready(function() {
      $('.popup-youtube').magnificPopup({
        type: 'iframe'
      });
    });
  </script>



<!-- Add prev/next buttons -->
<div class="containerx">
  <div class="d-flex justify-content-center my-4">
    <div class="navbar-floating rounded">
      <div class="navbar-item">
        <i class="fas fa-home"></i>
      </div>
      <div class="navbar-item">
        <i class="fas fa-save" id="save-icon"></i>
      </div>
      <div class="navbar-item">
        <i class="fas fa-history" id="history-icon"></i>
      </div>
      <div class="navbar-slider">
        <button type="button" class="navbar-slider-prev" id="prev-btn">
          Prev
        </button>
        <button type="button" class="navbar-slider-next" id="next-btn">
          Next
        </button>
      </div>
    </div>
  </div>
</div>
</div>






<script src="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/jquery.magnific-popup.min.js"></script>

<!-- Add AJAX script to handle genre selection -->
<script>
$(document).ready(function() {
  var currentPage = 1; // Variable to keep track of current page
  var lastPage = 1; // Variable to store the last page
  var selectedGenres = []; // Array to store selected genres
  var selectedStatus = ""; // Variable to store selected status
  var selectedFormat = ""; // Variable to store selected format

  // Function to load media for the current page
  function loadMedia() {
    // Set up query and variables
    var query = `
      query ($page: Int, $perPage: Int, $genre_in: [String], $status: MediaStatus, $format: MediaFormat) {
        Page (page: $page, perPage: $perPage) {
          pageInfo {
            total
            perPage
            currentPage
            lastPage
          }
          media (genre_in: $genre_in, status: $status, format: $format, sort: [TRENDING_DESC], type: ANIME) {
            id
            title {
              romaji
              english
              native
            }
            coverImage {
              large
            }
            averageScore
            trailer {
              id
            }
          }
        }
      }
    `;

    // Set up variables for query
    var variables = {
      page: currentPage,
      perPage: 8,
      genre_in: selectedGenres,
    };

    if (selectedStatus !== "") {
      variables.status = selectedStatus;
    }

    if (selectedFormat !== "") {
      variables.format = selectedFormat;
    }

    // Send AJAX request to server to execute query
    $.ajax({
      url: 'execute_query.php',
      method: 'POST',
      data: {
        query: query,
        variables: variables,
      },
      dataType: 'json',
      success: function(data) {
        // Clear media grid
        $('#media-grid').empty();

        // Loop through media and add to grid
        data.data.Page.media.forEach(function(media) {
          // Truncate title to 24 characters
          var title = media.title.romaji.substring(0, 24);

          // Create media card
          var card = $('<div>').addClass('col-6 col-sm-4 col-md-3 col-lg-3');
          var link = $('<a>').attr('href', 'https://ccgnimex.my.id/anime_detail?id=' + media.id);
          var img = $('<img>').addClass('card-img-top img-fluid').attr('src', media.coverImage.large).attr('alt', title);
          var rating = $('<div>').addClass('rating').append(
            $('<span>').addClass('fa fa-star checked'),
            media.averageScore
          );

          var trailerLink = null;
          if (media.trailer && media.trailer.id) {
            trailerLink = $('<a>').addClass('popup-youtube').attr('href', 'https://www.youtube.com/watch?v=' + media.trailer.id).attr('target', '_blank');
            var trailerIcon = $('<div>').addClass('animex-trailer').css({
              'margin-left': '5px',
              'margin-top': '2px'
            }).append(
              $('<i>').addClass('fas fa-film')
            );
            trailerLink.append(trailerIcon);

            // Check if browser supports Magnific Popup
            if ($.magnificPopup && $.magnificPopup.instance) {
              // Initialize magnificPopup for the trailer link
              trailerLink.magnificPopup({
                type: 'iframe',
                mainClass: 'mfp-fade',
                removalDelay: 160,
                preloader: false
              });
            } else {
              // If Magnific Popup is not supported, directly open YouTube link
              trailerLink.attr('href', 'https://www.youtube.com/watch?v=' + media.trailer.id);
              trailerLink.attr('target', '_blank');
            }
          }

          // Check if anime exists in database table
$.ajax({
  url: 'check_anime.php',
  method: 'POST',
  data: {
    anime_id: media.id,
  },
  dataType: 'json',
  success: function(response) {
    if (response.exists) {
      var watchedIcon = $('<div>').addClass('animex-watched').css({
        'position': 'absolute',
        'bottom': '100px',
        'right': '5px',
        'background-color': 'rgba(0, 0, 0, 0.7)',
        'color': 'white',
        'padding': '5px',
        'border-radius': '5px',
        'cursor': 'pointer',
        'font-size': '12px' // Ubah ukuran font di sini
      });
      
      var hasBatch = false;

      // Check if anime has batch
      $.ajax({
        url: 'check_batch.php',
        method: 'POST',
        data: {
          anime_id: media.id,
        },
        dataType: 'json',
        success: function(response) {
          hasBatch = response.exists;
          updateWatchedIcon();
        }
      });

      // Check if anime is in 'nonton' table
      var isInNonton = response.exists; // Assuming this is the correct response from the 'check_anime.php' call
      if (isInNonton) {
        updateWatchedIcon();
      }

      function updateWatchedIcon() {
        watchedIcon.empty();

        var iconElement = $('<i>').addClass('fas fa-check');
        watchedIcon.append(iconElement);

        if (hasBatch) {
          watchedIcon.append(' Stream | Batch');
        } else {
          watchedIcon.append(' Stream');
        }

        // Append the watched icon to the image container
        card.find('.card-img-top').parent().append(watchedIcon);

        // Responsive positioning for mobile view
        if (window.innerWidth <= 576) {
          watchedIcon.css({
            'bottom': '150px',
            'right': '8px',
            'font-size': '10px' // Ubah ukuran font di sini untuk tampilan mobile
          });
        }
      }

      updateWatchedIcon();
    }
  }
});

          card.append(
            $('<div>').addClass('card h-100').append(
              link.append(
                img,
                rating,
                trailerLink,
                $('<div>').addClass('card-body text-center').append(
                  $('<h5>').addClass('card-title').text(title)
                )
              )
            )
          );

          // Add card to media grid
          $('#media-grid').append(card);
        });

        // Update pagination buttons and lastPage variable
        var pageInfo = data.data.Page.pageInfo;
        lastPage = pageInfo.lastPage;
        updatePaginationButtons(pageInfo.currentPage, lastPage);
      },
    });
  }

  // Function to update pagination buttons
  function updatePaginationButtons(currentPage, lastPage) {
    // Enable/disable prev button
    if (currentPage === 1) {
      $('#prev-btn').prop('disabled', true);
    } else {
      $('#prev-btn').prop('disabled', false);
    }

    // Enable/disable next button
    if (currentPage === lastPage) {
      $('#next-btn').prop('disabled', true);
    } else {
      $('#next-btn').prop('disabled', false);
    }
  }

  // Handle change event on genre checkboxes
  $('.form-check-input').on('change', function() {
    currentPage = 1; // Reset current page to 1

    // Update selectedGenres based on checked checkboxes
    if ($('.form-check-input:checked').val() === 'ALL') {
      selectedGenres = []; // Clear selectedGenres if ALL is checked
    } else {
      selectedGenres = $('.form-check-input:checked').map(function() {
        return $(this).val();
      }).get();
    }

    loadMedia();
  });

  // Handle change event on format dropdown
  $('#format-select').on('change', function() {
    currentPage = 1; // Reset current page to 1
    selectedFormat = $(this).val(); // Get selected format

    if (selectedFormat === 'ALL') {
      selectedFormat = ''; // Change selectedFormat to empty string
    }

    loadMedia();
  });

  // Handle change event on status dropdown
  $('#status-select').on('change', function() {
    currentPage = 1; // Reset current page to 1
    selectedStatus = $(this).val(); // Get selected status

    if (selectedStatus === 'ALL') {
      selectedStatus = ''; // Change selectedStatus to empty string
    }

    loadMedia();
  });

  // Set the selected status on page load
  $(document).ready(function() {
    const statusDropdown = $('#status-select');
    let selectedStatus = statusDropdown.val();

    if (selectedStatus === null) {
      statusDropdown.val('ALL');
      selectedStatus = 'ALL';
    }

    loadMedia();
  });

  // Handle click event on prev button
  $('#prev-btn').on('click', function() {
    if (currentPage > 1) {
      currentPage--;
      loadMedia();
    }
  });

  // Handle click event on next button
  $('#next-btn').on('click', function() {
    if (currentPage < lastPage) {
      currentPage++;
      loadMedia();
    }
  });

  // Function to initialize the page
  function initializePage() {
    // Load media for the initial page
    loadMedia();
  }

  // Call initializePage function to start the page
  initializePage();
});
</script>


                
            <footer class="bg-white sticky-footer">
                <div class="container my-auto">
                    <div class="text-center my-auto copyright"><span>Copyright © Brand 2023</span></div>
                </div>
            </footer>
        </div><a class="border rounded d-inline scroll-to-top" href="#page-top"><i class="fas fa-angle-up"></i></a>
    </div>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/bs-init.js"></script>
    <script src="assets/js/theme.js"></script>
    <script>
// Function to update auth_date
function updateAuthDate() {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4) {
      if (this.status == 200) {
        // Successful update
        console.log('Auth date updated successfully');
      } else if (this.status == 401) {
        // User not logged in
        console.log('User not logged in');
      } else {
        // Update failed
        console.log('Failed to update auth_date');
      }
    }
  };
  xhttp.open('GET', 'update_auth_date.php', true);
  xhttp.send();
}

// Get current time in Jakarta
function getCurrentTime() {
  var currentTime = new Date();
  var datetimeWib = new Date(
    currentTime.toLocaleString('en-US', { timeZone: 'Asia/Jakarta' })
  );
  return datetimeWib.toISOString().slice(0, 19).replace('T', ' ');
}

// Retrieve user data and update the table
function retrieveUserData() {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      var user_data = JSON.parse(this.responseText);
      var table_rows = '';
      for (var i = 0; i < user_data.length; i++) {
        var profile_picture = user_data[i].profile_picture;
        var telegram_username = user_data[i].telegram_username;
        var last_login = user_data[i].last_login;

        var time_ago = calculateTimeAgo(last_login);

        table_rows += '<tr>';
        table_rows += '<td><img src="' + profile_picture + '"></td>';
        table_rows += '<td>' + telegram_username + '</td>';
        table_rows += '<td>' + time_ago + '</td>';
        table_rows += '</tr>';
      }
      document.getElementById('user-table-body').innerHTML = table_rows;
    }
  };
  xhttp.open('GET', 'retrieve_user_data.php?current_time=' + getCurrentTime(), true);
  xhttp.send();
}

// Call the retrieveUserData and updateAuthDate functions when the page loads
window.onload = function() {
  retrieveUserData();
  updateAuthDate();
};

</script>

<style>
#content-wrapper {
  position: relative;
  min-height: 100vh;
}

#content {
  margin-bottom: 60px; /* Tinggi navbar + margin */
}

.navbar-floating {
  position: fixed;
  bottom: 20px;
  left: 50%;
  transform: translateX(-50%);
  background-color: rgba(255, 255, 255, 0.5); /* Ubah alpha (0.5) sesuai kebutuhan */
  backdrop-filter: blur(10px); /* Ubah nilai blur sesuai kebutuhan */
  padding: 10px;
  border-radius: 30px;
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1); /* Tambahkan properti box-shadow */
}

.navbar-item {
  border-radius: 50%;
  padding: 10px;
  margin-right: 10px;
}

.navbar-item i {
  color: #333333;
}

.navbar-slider {
  display: flex;
  align-items: center;
  margin-left: 10px;
}

.navbar-slider-prev,
.navbar-slider-next {
  border: none;
  background-color: transparent;
  cursor: pointer;
  margin: 0 5px;
}

.navbar-slider-prev:hover,
.navbar-slider-next:hover {
  color: #999999;
}

/* Responsive adjustments */
@media (max-width: 767px) {
  .navbar-floating {
    padding: 5px;
    border-radius: 20px;
    left: 47%;
    buttom: 17px;
  }
  
  .navbar-item {
    padding: 5px;
    margin-right: 5px;
  }
  
  .navbar-slider-prev,
  .navbar-slider-next {
    margin: 0 2px;
  }
}

/* Additional adjustment for 320px width */
@media (max-width: 320px) {
  .navbar-floating {
    padding: 3px;
    border-radius: 12px;
    left: 47%;
  }
  
  .navbar-item {
    padding: 3px;
    margin-right: 3px;
  }
  
  .navbar-slider-prev,
  .navbar-slider-next {
    margin: 0 1px;
  }
}
</style>





<!-- Add the following CSS code to your existing style block -->
<style>
  .popup {
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background-color: white;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    z-index: 1000;
    display: none;
  }

  .popup-content {
    text-align: center;
  }

  .popup-close {
    position: absolute;
    top: 10px;
    right: 10px;
    cursor: pointer;
  }
</style>

<!-- Add the following JavaScript code to your HTML file -->

<!-- Add the following HTML code after the closing </style> tag -->
<div class="popup" id="save-popup">
  <div class="popup-content">
    <h3>Save Popup</h3>
    <p>This is a sample Save popup content.</p>
    <span class="popup-close">&times;</span>
  </div>
</div>

<div class="popup" id="history-popup">
  <div class="popup-content">
    <h3>History Popup</h3>
    <p>This is a sample History popup content.</p>
    <span class="popup-close">&times;</span>
  </div>
</div>

<script>
  // Show popup when Save icon is clicked
  document.getElementById("save-icon").addEventListener("click", function() {
    document.getElementById("save-popup").style.display = "block";
  });

  // Show popup when History icon is clicked
  document.getElementById("history-icon").addEventListener("click", function() {
    document.getElementById("history-popup").style.display = "block";
  });

  // Close the popup when close button is clicked
  document.querySelectorAll(".popup-close").forEach(function(closeButton) {
    closeButton.addEventListener("click", function() {
      this.parentNode.parentNode.style.display = "none";
    });
  });
</script>

<script async src="https://analytics.umami.is/script.js" data-website-id="1641f207-dcb7-4386-9ec4-a971881a8622"></script>
</body>

</html>