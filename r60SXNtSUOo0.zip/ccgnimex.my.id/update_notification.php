<?php
session_start();

if (isset($_SESSION['telegram_id']) && isset($_POST['notification_id'])) {
    $telegramId = $_SESSION['telegram_id'];
    $notificationId = $_POST['notification_id'];

    // Koneksi ke database
    $db_host = "localhost";
    $db_name = "ccgnimex";
    $db_user = "ccgnimex";
    $db_password = "aaaaaaac";

    $conn = new mysqli($db_host, $db_user, $db_password, $db_name);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Perbarui status notifikasi menjadi "dibaca" di basis data
    $updateSql = "UPDATE notif_anime SET is_read = 1 WHERE telegram_id = $telegramId AND id = $notificationId";
    $conn->query($updateSql);

    // Tutup koneksi
    $conn->close();

    // Respon berhasil ke AJAX
    echo "success";
} else {
    // Respon gagal ke AJAX
    echo "error";
}
?>
