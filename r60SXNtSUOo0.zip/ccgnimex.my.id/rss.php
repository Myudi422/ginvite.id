<?php
    $rss = simplexml_load_file('https://samehadaku.cam/feed/');
    echo '<div class="container">';
    echo '<h1>' . $rss->channel->title . '</h1>';
    foreach ($rss->channel->item as $item) {
        echo '<div class="card">';
        echo '<div class="card-body">';
        echo '<h5 class="card-title"><a href="item.php?url=' . $item->link . '">' . $item->title . '</a></h5>';
        echo '<p class="card-text">' . $item->description . '</p>';
        echo '</div>';
        echo '</div>';
    }
    echo '</div>';
?>