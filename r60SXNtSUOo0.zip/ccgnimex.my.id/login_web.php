<?php
// Start the session
session_start();


// Di auth.php
// Ketika pengguna sudah masuk, pergi ke halaman yang ditentukan oleh $_SESSION['redirect_index'] atau $_SESSION['redirect_streaming']
if (isset($_SESSION['logged-in']) && $_SESSION['logged-in'] == TRUE) {
    if (isset($_SESSION['redirect_index'])) {
        $redirect_page = $_SESSION['redirect_index'];
    } elseif (isset($_SESSION['redirect_streaming'])) {
        $redirect_page = $_SESSION['redirect_streaming'];
    } else {
        $redirect_page = 'index.php';
    }
    die(header('Location: ' . $redirect_page));
}

// Place username of your bot here
define('BOT_USERNAME', 'ccgnimeX_bot');

include 'jumlah-user.php';
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login</title>
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.15/dist/tailwind.min.css" rel="stylesheet">
  <style>
    /* Additional custom styles can be added here */
    /* Example: */
    /* .logo {
         width: 100px;
         height: 100px;
         object-fit: contain;
       } */
  </style>
</head>
<body class="bg-gray-100">
  <div class="min-h-screen flex items-center justify-center">
    <div class="bg-white shadow-lg rounded-lg p-8 w-full sm:w-96">
      <h2 class="text-2xl font-bold text-center mb-6">Sign In</h2>
      <form action="process_login.php" method="POST">
        <div class="mb-4">
          <label for="email" class="block text-gray-700 font-bold mb-2">Email</label>
          <input type="email" class="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:border-indigo-500" id="email" name="email" required>
        </div>
        <div class="mb-4">
          <label for="password" class="block text-gray-700 font-bold mb-2">Password</label>
          <input type="password" class="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:border-indigo-500" id="password" name="password" required>
        </div>
        <div class="form-group">
          <button type="submit" class="w-full bg-indigo-500 text-white font-bold py-2 rounded-md hover:bg-indigo-600 transition duration-300">Sign In</button>
        </div>
        <div class="form-group d-md-flex">
          <div class="w-1/2">
            <label class="checkbox-wrap checkbox-primary">
              <input type="checkbox" name="remember_me" class="mr-2 leading-tight">
              <span class="text-gray-700">Remember Me</span>
              <span class="checkmark"></span>
            </label>
          </div>
          <div class="w-1/2 text-right">
            <a href="#" class="text-indigo-600 hover:text-indigo-800">Forgot Password</a>
          </div>
        </div>
      </form>
      <!-- Optional Telegram Login Widget -->
      <div class="mt-4">
        <form class="user">
          <script async src="https://telegram.org/js/telegram-widget.js" data-telegram-login="<?= BOT_USERNAME ?>" data-size="large" data-radius="10" data-auth-url="auth.php"></script>
        </form>
      </div>
      <!-- End of Optional Telegram Login Widget -->
    </div>
  </div>
</body>
</html>

