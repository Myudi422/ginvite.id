<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
  <title>Spotify Web Music</title>
 
</head>
<div class="NekomoeVercelAppByHtmlToDesignFreeVersion30072023141952Gmt7 w-96 h-96 pb-9 bg-white flex-col justify-start items-center gap-1 inline-flex">
  <div class="PresentationResizablehorizontalgridModuleContainerAlfqw justify-center items-start gap-0.5 inline-flex">
    <div class="Aside w-64 self-stretch px-1 pt-1 pb-96 flex-col justify-start items-start gap-2 inline-flex">
      <div class="DivBgZinc100 h-24 px-4 py-3.5 bg-zinc-100 rounded-md flex-col justify-start items-start gap-3 flex">
        <div class="Link w-52 pr-28 justify-start items-center gap-4 inline-flex">
          <div class="Svg h-5 px-px pt-px pb-0.5 justify-start items-start flex"></div>
          <div class="SpanTextXl justify-start items-start flex">
            <div class="Home text-zinc-500 text-xl font-semibold leading-7">Home</div>
          </div>
        </div>
        <div class="Link w-52 pr-28 justify-start items-center gap-4 inline-flex">
          <div class="Svg h-5 p-0.5 justify-start items-start flex"></div>
          <div class="SpanTextXl justify-start items-start flex">
            <div class="Search text-zinc-500 text-xl font-semibold leading-7">Search</div>
          </div>
        </div>
      </div>
      <div class="DivBgZinc100 grow shrink basis-0 px-4 py-3.5 bg-zinc-100 rounded-md flex-col justify-between items-start gap-96 flex">
        <div class="DivSpaceY4 h-48 flex-col justify-start items-start gap-3 flex">
          <div class="Link w-52 pr-20 justify-start items-center gap-4 inline-flex">
            <div class="Svg h-5 px-px py-px justify-start items-start flex"></div>
            <div class="SpanTextXl justify-start items-start flex">
              <div class="OnGoing text-zinc-500 text-xl font-semibold leading-7">On Going</div>
            </div>
          </div>
          <div class="Link w-52 pr-24 justify-start items-center gap-4 inline-flex">
            <div class="Svg h-5 px-0.5 justify-start items-start flex"></div>
            <div class="SpanTextXl justify-start items-start flex">
              <div class="Finished text-zinc-500 text-xl font-semibold leading-7">Finished</div>
            </div>
          </div>
          <div class="Link w-52 pr-9 justify-start items-center gap-4 inline-flex">
            <div class="Svg h-5 justify-start items-start flex"></div>
            <div class="SpanTextXl justify-start items-start flex">
              <div class="Summer2023 text-zinc-500 text-xl font-semibold leading-7">Summer 2023</div>
            </div>
          </div>
          <div class="Link w-52 pr-20 justify-start items-center gap-4 inline-flex">
            <div class="Svg h-5 p-px justify-start items-start flex"></div>
            <div class="SpanTextXl justify-start items-start flex">
              <div class="Schedule text-zinc-500 text-xl font-semibold leading-7">Schedule</div>
            </div>
          </div>
          <div class="Link w-52 pr-16 justify-start items-center gap-4 inline-flex">
            <div class="Svg h-5 px-0.5 pt-0.5 pb-px justify-start items-start flex"></div>
            <div class="SpanTextXl justify-start items-start flex">
              <div class="Properties text-zinc-500 text-xl font-semibold leading-7">Properties</div>
            </div>
          </div>
        </div>
        <div class="Link w-52 pr-20 justify-start items-center gap-4 inline-flex">
          <div class="Svg h-5 p-px justify-start items-start flex"></div>
          <div class="SpanTextXl justify-start items-start flex">
            <div class="Analytics text-zinc-500 text-xl font-semibold leading-7">Analytics</div>
          </div>
        </div>
      </div>
    </div>
    <div class="Main self-stretch px-1 pt-1 justify-start items-start inline-flex">
      <div class="DivHFull w-96 h-96 relative bg-gradient-to-t from-zinc-100 via-zinc-100 to-zinc-200 rounded-md">
        <div class="DivWFull w-96 h-96 left-0 top-0 absolute bg-gradient-to-t from-zinc-100 via-zinc-100 to-zinc-200"></div>
        <div class="DivSpaceY4 w-96 h-96 left-0 top-[68px] absolute">
          <div class="DivWFull h-72 px-96 py-24 left-[16px] top-0 absolute flex-col justify-center items-center gap-6 inline-flex">
            <div class="DivAbsolute w-28 px-6 pt-1 pb-1.5 bg-white bg-opacity-50 rounded-full border border-zinc-200 justify-start items-start inline-flex">
              <div class="Sponsors text-zinc-950 text-sm font-normal leading-tight">Sponsors</div>
            </div>
            <div class="Heading1 w-80 pb-px justify-start items-start inline-flex">
              <div class="Nekomoe"><span style="text-zinc-500 text-7xl font-black leading-10">Neko</span><span style="text-green-600 text-7xl font-black leading-10">moe</span></div>
            </div>
            <div class="PTextMutedForeground w-96 justify-start items-start inline-flex">
              <div class="NontonAnimeSubtitleIndonesiaGratisTanpaIklan text-zinc-500 text-xl font-normal leading-7">Nonton anime subtitle Indonesia Gratis tanpa Iklan!</div>
            </div>
          </div>
          <div class="DivFlex w-96 left-[16px] top-[318.39px] absolute justify-between items-start gap-96 inline-flex">
            <div class="Heading3 justify-start items-start flex">
              <div class="OnGoing text-zinc-950 text-base font-semibold leading-normal">On Going</div>
            </div>
            <div class="Link justify-start items-start flex">
              <div class="ShowAll text-zinc-500 text-base font-normal leading-normal">Show all</div>
            </div>
          </div>
          <div class="DivWFull h-96 pb-2 left-[16px] top-[358.39px] absolute flex-col justify-start items-center gap-12 inline-flex">
            <div class="DivGrid w-96 h-96 relative">
              <div class="DivTextCardForeground w-52 h-72 p-px left-0 top-0 absolute bg-white bg-opacity-0 rounded-md shadow border border-zinc-200 flex-col justify-center items-center inline-flex">
                <div class="DivBgMuted self-stretch grow shrink basis-0 bg-zinc-100 flex-col justify-center items-center inline-flex">
                  <div class="Link w-52 h-72 relative flex-col justify-start items-start flex">
                    <img class="Image w-52 h-72" src="https://via.placeholder.com/214x285" />
                    <div class="Heading3 px-2 pt-0.5 pb-1 bg-white rounded-full justify-start items-start inline-flex">
                      <div class="Ep512 text-zinc-950 text-xs font-normal leading-none">Ep 5 / 12</div>
                    </div>
                    <div class="DivAbsolute w-52 h-36 bg-gradient-to-t from-zinc-100 to-zinc-100"></div>
                    <div class="Heading3Ayaka text-zinc-950 text-xs font-semibold leading-none">Ayaka</div>
                  </div>
                </div>
              </div>
              <div class="DivTextCardForeground w-52 h-72 p-px left-[232px] top-0 absolute bg-white bg-opacity-0 rounded-md shadow border border-zinc-200 flex-col justify-center items-center inline-flex">
                <div class="DivBgMuted self-stretch grow shrink basis-0 bg-zinc-100 flex-col justify-center items-center inline-flex">
                  <div class="Link w-52 h-72 relative flex-col justify-start items-start flex">
                    <img class="Image w-52 h-72" src="https://via.placeholder.com/214x285" />
                    <div class="Heading3 px-2 pt-0.5 pb-1 bg-white rounded-full justify-start items-start inline-flex">
                      <div class="Ep412 text-zinc-950 text-xs font-normal leading-none">Ep 4 / 12</div>
                    </div>
                    <div class="DivAbsolute w-52 h-36 bg-gradient-to-t from-zinc-100 to-zinc-100"></div>
                    <div class="Heading3JitsuWaOreSaikyouDeshita text-zinc-950 text-xs font-semibold leading-none">Jitsu wa Ore, Saikyou deshita?</div>
                  </div>
                </div>
              </div>
              <div class="DivTextCardForeground w-52 h-72 p-px left-[464px] top-0 absolute bg-white bg-opacity-0 rounded-md shadow border border-zinc-200 flex-col justify-center items-center inline-flex">
                <div class="DivBgMuted self-stretch grow shrink basis-0 bg-zinc-100 flex-col justify-center items-center inline-flex">
                  <div class="Link w-52 h-72 relative flex-col justify-start items-start flex">
                    <img class="Image w-52 h-72" src="https://via.placeholder.com/214x285" />
                    <div class="Heading3 px-2 pt-0.5 pb-1 bg-white rounded-full justify-start items-start inline-flex">
                      <div class="Ep18 text-zinc-950 text-xs font-normal leading-none">Ep 18 / ?</div>
                    </div>
                    <div class="DivAbsolute w-52 h-36 bg-gradient-to-t from-zinc-100 to-zinc-100"></div>
                    <div class="Heading3EdensZero2ndSeason text-zinc-950 text-xs font-semibold leading-none">Edens Zero 2nd Season</div>
                  </div>
                </div>
              </div>
              <div class="DivTextCardForeground w-52 h-72 p-px left-[696px] top-0 absolute bg-white bg-opacity-0 rounded-md shadow border border-zinc-200 flex-col justify-center items-center inline-flex">
                <div class="DivBgMuted self-stretch grow shrink basis-0 bg-zinc-100 flex-col justify-center items-center inline-flex">
                  <div class="Link w-52 h-72 relative flex-col justify-start items-start flex">
                    <img class="Image w-52 h-72" src="https://via.placeholder.com/214x285" />
                    <div class="Heading3 px-2 pt-0.5 pb-1 bg-white rounded-full justify-start items-start inline-flex">
                      <div class="Ep512 text-zinc-950 text-xs font-normal leading-none">Ep 5 / 12</div>
                    </div>
                    <div class="DivAbsolute w-52 h-36 bg-gradient-to-t from-zinc-100 to-zinc-100"></div>
                    <div class="Heading3 w-48 pb-px justify-start items-start inline-flex">
                      <div class="RyzaNoAtelierTokoyamiNoJoouToHimitsuNoKakurega text-zinc-950 text-xs font-semibold leading-none">Ryza no Atelier: Tokoyami no Joou<br/>to Himitsu no Kakurega</div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="DivTextCardForeground w-52 h-72 p-px left-[928px] top-0 absolute bg-white bg-opacity-0 rounded-md shadow border border-zinc-200 flex-col justify-center items-center inline-flex">
                <div class="DivBgMuted self-stretch grow shrink basis-0 bg-zinc-100 flex-col justify-center items-center inline-flex">
                  <div class="Link w-52 h-72 relative flex-col justify-start items-start flex">
                    <img class="Image w-52 h-72" src="https://via.placeholder.com/214x285" />
                    <div class="Heading3 px-2 pt-0.5 pb-1 bg-white rounded-full justify-start items-start inline-flex">
                      <div class="Ep412 text-zinc-950 text-xs font-normal leading-none">Ep 4 / 12</div>
                    </div>
                    <div class="DivAbsolute w-52 h-36 bg-gradient-to-t from-zinc-100 to-zinc-100"></div>
                    <div class="Heading3Temple text-zinc-950 text-xs font-semibold leading-none">Temple</div>
                  </div>
                </div>
              </div>
              <div class="DivTextCardForeground w-52 h-72 p-px left-[1160px] top-0 absolute bg-white bg-opacity-0 rounded-md shadow border border-zinc-200 flex-col justify-center items-center inline-flex">
                <div class="DivBgMuted self-stretch grow shrink basis-0 bg-zinc-100 flex-col justify-center items-center inline-flex">
                  <div class="Link w-52 h-72 relative flex-col justify-start items-start flex">
                    <img class="Image w-52 h-72" src="https://via.placeholder.com/214x285" />
                    <div class="Heading3 px-2 pt-0.5 pb-1 bg-white rounded-full justify-start items-start inline-flex">
                      <div class="Ep513 text-zinc-950 text-xs font-normal leading-none">Ep 5 / 13</div>
                    </div>
                    <div class="DivAbsolute w-52 h-36 bg-gradient-to-t from-zinc-100 to-zinc-100"></div>
                    <div class="Heading3HorimiyaPiece text-zinc-950 text-xs font-semibold leading-none">Horimiya: Piece</div>
                  </div>
                </div>
              </div>
              <div class="DivTextCardForeground w-52 h-72 p-px left-0 top-[303.33px] absolute bg-white bg-opacity-0 rounded-md shadow border border-zinc-200 flex-col justify-center items-center inline-flex">
                <div class="DivBgMuted self-stretch grow shrink basis-0 bg-zinc-100 flex-col justify-center items-center inline-flex">
                  <div class="Link w-52 h-72 relative flex-col justify-start items-start flex">
                    <img class="Image w-52 h-72" src="https://via.placeholder.com/214x285" />
                    <div class="Heading3 px-2 pt-0.5 pb-1 bg-white rounded-full justify-start items-start inline-flex">
                      <div class="Ep413 text-zinc-950 text-xs font-normal leading-none">Ep 4 / 13</div>
                    </div>
                    <div class="DivAbsolute w-52 h-36 bg-gradient-to-t from-zinc-100 to-zinc-100"></div>
                    <div class="Heading3 w-48 pr-7 pb-px justify-start items-start inline-flex">
                      <div class="BleachSennenKessenHenKetsubetsuTan text-zinc-950 text-xs font-semibold leading-none">Bleach: Sennen Kessen-hen -<br/>Ketsubetsu-tan</div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="DivTextCardForeground w-52 h-72 p-px left-[232px] top-[303.33px] absolute bg-white bg-opacity-0 rounded-md shadow border border-zinc-200 flex-col justify-center items-center inline-flex">
                <div class="DivBgMuted self-stretch grow shrink basis-0 bg-zinc-100 flex-col justify-center items-center inline-flex">
                  <div class="Link w-52 h-72 relative flex-col justify-start items-start flex">
                    <img class="Image w-52 h-72" src="https://via.placeholder.com/214x285" />
                    <div class="Heading3 px-2 pt-0.5 pb-1 bg-white rounded-full justify-start items-start inline-flex">
                      <div class="Ep512 text-zinc-950 text-xs font-normal leading-none">Ep 5 / 12</div>
                    </div>
                    <div class="DivAbsolute w-52 h-36 bg-gradient-to-t from-zinc-100 to-zinc-100"></div>
                    <div class="Heading3LiarLiar text-zinc-950 text-xs font-semibold leading-none">Liar Liar</div>
                  </div>
                </div>
              </div>
              <div class="DivTextCardForeground w-52 h-72 p-px left-[464px] top-[303.33px] absolute bg-white bg-opacity-0 rounded-md shadow border border-zinc-200 flex-col justify-center items-center inline-flex">
                <div class="DivBgMuted self-stretch grow shrink basis-0 bg-zinc-100 flex-col justify-center items-center inline-flex">
                  <div class="Link w-52 h-72 relative flex-col justify-start items-start flex">
                    <img class="Image w-52 h-72" src="https://via.placeholder.com/214x285" />
                    <div class="Heading3 px-2 pt-0.5 pb-1 bg-white rounded-full justify-start items-start inline-flex">
                      <div class="Ep4 text-zinc-950 text-xs font-normal leading-none">Ep 4 / ?</div>
                    </div>
                    <div class="DivAbsolute w-52 h-36 bg-gradient-to-t from-zinc-100 to-zinc-100"></div>
                    <div class="Heading3 w-48 pr-6 pb-px justify-start items-start inline-flex">
                      <div class="Level1DakedoUniqueSkillDeSaikyouDesu text-zinc-950 text-xs font-semibold leading-none">Level 1 dakedo Unique Skill de<br/>Saikyou desu</div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="DivTextCardForeground w-52 h-72 p-px left-[696px] top-[303.33px] absolute bg-white bg-opacity-0 rounded-md shadow border border-zinc-200 flex-col justify-center items-center inline-flex">
                <div class="DivBgMuted self-stretch grow shrink basis-0 bg-zinc-100 flex-col justify-center items-center inline-flex">
                  <div class="Link w-52 h-72 relative flex-col justify-start items-start flex">
                    <img class="Image w-52 h-72" src="https://via.placeholder.com/214x285" />
                    <div class="Heading3 px-2 pt-0.5 pb-1 bg-white rounded-full justify-start items-start inline-flex">
                      <div class="Ep1450 text-zinc-950 text-xs font-normal leading-none">Ep 14 / 50</div>
                    </div>
                    <div class="DivAbsolute w-52 h-36 bg-gradient-to-t from-zinc-100 to-zinc-100"></div>
                    <div class="Heading3WuhangZhanshen text-zinc-950 text-xs font-semibold leading-none">Wuhang Zhanshen</div>
                  </div>
                </div>
              </div>
              <div class="DivTextCardForeground w-52 h-72 p-px left-[928px] top-[303.33px] absolute bg-white bg-opacity-0 rounded-md shadow border border-zinc-200 flex-col justify-center items-center inline-flex">
                <div class="DivBgMuted self-stretch grow shrink basis-0 bg-zinc-100 flex-col justify-center items-center inline-flex">
                  <div class="Link w-52 h-72 relative flex-col justify-start items-start flex">
                    <img class="Image w-52 h-72" src="https://via.placeholder.com/214x285" />
                    <div class="Heading3 px-2 pt-0.5 pb-1 bg-white rounded-full justify-start items-start inline-flex">
                      <div class="Ep1150 text-zinc-950 text-xs font-normal leading-none">Ep 1150 / ?</div>
                    </div>
                    <div class="DivAbsolute w-52 h-36 bg-gradient-to-t from-zinc-100 to-zinc-100"></div>
                    <div class="Heading3DetectiveConan text-zinc-950 text-xs font-semibold leading-none">Detective Conan</div>
                  </div>
                </div>
              </div>
              <div class="DivTextCardForeground w-52 h-72 p-px left-[1160px] top-[303.33px] absolute bg-white bg-opacity-0 rounded-md shadow border border-zinc-200 flex-col justify-center items-center inline-flex">
                <div class="DivBgMuted self-stretch grow shrink basis-0 bg-zinc-100 flex-col justify-center items-center inline-flex">
                  <div class="Link w-52 h-72 relative flex-col justify-start items-start flex">
                    <img class="Image w-52 h-72" src="https://via.placeholder.com/214x285" />
                    <div class="Heading3 px-2 pt-0.5 pb-1 bg-white rounded-full justify-start items-start inline-flex">
                      <div class="Ep713 text-zinc-950 text-xs font-normal leading-none">Ep 7 / 13</div>
                    </div>
                    <div class="DivAbsolute w-52 h-36 bg-gradient-to-t from-zinc-100 to-zinc-100"></div>
                    <div class="Heading3BangDreamItSMygo text-zinc-950 text-xs font-semibold leading-none">BanG Dream! It's MyGO!!!!!</div>
                  </div>
                </div>
              </div>
              <div class="DivTextCardForeground w-52 h-72 p-px left-0 top-[606.66px] absolute bg-white bg-opacity-0 rounded-md shadow border border-zinc-200 flex-col justify-center items-center inline-flex">
                <div class="DivBgMuted self-stretch grow shrink basis-0 bg-zinc-100 flex-col justify-center items-center inline-flex">
                  <div class="Link self-stretch h-72 pl-2 pr-20 pt-2.5 pb-2 flex-col justify-start items-start gap-56 inline-flex">
                    <div class="Heading3 px-2 pt-0.5 pb-1 bg-white rounded-full justify-start items-start inline-flex">
                      <div class="Ep5060 text-zinc-950 text-xs font-normal leading-none">Ep 50 / 60</div>
                    </div>
                    <div class="DivAbsolute w-52 h-36 bg-gradient-to-t from-zinc-100 to-zinc-100"></div>
                    <div class="Heading3LianQiShiWanNian text-zinc-950 text-xs font-semibold leading-none">Lian Qi Shi Wan Nian</div>
                  </div>
                </div>
              </div>
              <div class="DivTextCardForeground w-52 h-72 p-px left-[232px] top-[606.66px] absolute bg-white bg-opacity-0 rounded-md shadow border border-zinc-200 flex-col justify-center items-center inline-flex">
                <div class="DivBgMuted self-stretch grow shrink basis-0 bg-zinc-100 flex-col justify-center items-center inline-flex">
                  <div class="Link self-stretch h-72 pl-2 pr-6 pt-2.5 pb-2 flex-col justify-start items-start gap-56 inline-flex">
                    <div class="Heading3 px-2 pt-0.5 pb-1 bg-white rounded-full justify-start items-start inline-flex">
                      <div class="Ep752 text-zinc-950 text-xs font-normal leading-none">Ep 7 / 52</div>
                    </div>
                    <div class="DivAbsolute w-52 h-36 bg-gradient-to-t from-zinc-100 to-zinc-100"></div>
                    <div class="Heading3DouluoDaluIiJueshiTangmen text-zinc-950 text-xs font-semibold leading-none">Douluo Dalu II: Jueshi Tangmen</div>
                  </div>
                </div>
              </div>
              <div class="DivTextCardForeground w-52 h-72 p-px left-[464px] top-[606.66px] absolute bg-white bg-opacity-0 rounded-md shadow border border-zinc-200 flex-col justify-center items-center inline-flex">
                <div class="DivBgMuted self-stretch grow shrink basis-0 bg-zinc-100 flex-col justify-center items-center inline-flex">
                  <div class="Link self-stretch h-72 pl-2 pr-20 pt-2.5 pb-2 flex-col justify-start items-start gap-56 inline-flex">
                    <div class="Heading3 px-2 pt-0.5 pb-1 bg-white rounded-full justify-start items-start inline-flex">
                      <div class="Ep1118 text-zinc-950 text-xs font-normal leading-none">Ep 11 / 18</div>
                    </div>
                    <div class="DivAbsolute w-52 h-36 bg-gradient-to-t from-zinc-100 to-zinc-100"></div>
                    <div class="Heading3ShiFangJianSheng text-zinc-950 text-xs font-semibold leading-none">Shi Fang Jian Sheng</div>
                  </div>
                </div>
              </div>
              <div class="DivTextCardForeground w-52 h-72 p-px left-[696px] top-[606.66px] absolute bg-white bg-opacity-0 rounded-md shadow border border-zinc-200 flex-col justify-center items-center inline-flex">
                <div class="DivBgMuted self-stretch grow shrink basis-0 bg-zinc-100 flex-col justify-center items-center inline-flex">
                  <div class="Link self-stretch h-72 pl-2 pr-20 pt-2.5 pb-2 flex-col justify-start items-start gap-56 inline-flex">
                    <div class="Heading3 px-2 pt-0.5 pb-1 bg-white rounded-full justify-start items-start inline-flex">
                      <div class="Ep740 text-zinc-950 text-xs font-normal leading-none">Ep 7 / 40</div>
                    </div>
                    <div class="DivAbsolute w-52 h-36 bg-gradient-to-t from-zinc-100 to-zinc-100"></div>
                    <div class="Heading3JiuChenFengyunLu text-zinc-950 text-xs font-semibold leading-none">Jiu Chen Fengyun Lu</div>
                  </div>
                </div>
              </div>
              <div class="DivTextCardForeground w-52 h-72 p-px left-[928px] top-[606.66px] absolute bg-white bg-opacity-0 rounded-md shadow border border-zinc-200 flex-col justify-center items-center inline-flex">
                <div class="DivBgMuted self-stretch grow shrink basis-0 bg-zinc-100 flex-col justify-center items-center inline-flex">
                  <div class="Link self-stretch h-72 pl-2 pr-28 pt-2.5 pb-2 flex-col justify-start items-start gap-56 inline-flex">
                    <div class="Heading3 px-2 pt-0.5 pb-1 bg-white rounded-full justify-start items-start inline-flex">
                      <div class="Ep44 text-zinc-950 text-xs font-normal leading-none">Ep 44 / ?</div>
                    </div>
                    <div class="DivAbsolute w-52 h-36 bg-gradient-to-t from-zinc-100 to-zinc-100"></div>
                    <div class="Heading3BinghuoMochu2 text-zinc-950 text-xs font-semibold leading-none">Binghuo Mochu 2</div>
                  </div>
                </div>
              </div>
              <div class="DivTextCardForeground w-52 h-72 p-px left-[1160px] top-[606.66px] absolute bg-white bg-opacity-0 rounded-md shadow border border-zinc-200 flex-col justify-center items-center inline-flex">
                <div class="DivBgMuted self-stretch grow shrink basis-0 bg-zinc-100 flex-col justify-center items-center inline-flex">
                  <div class="Link self-stretch h-72 pl-2 pr-7 pt-2.5 pb-2 flex-col justify-start items-start gap-56 inline-flex">
                    <div class="Heading3 px-2 pt-0.5 pb-1 bg-white rounded-full justify-start items-start inline-flex">
                      <div class="Ep2552 text-zinc-950 text-xs font-normal leading-none">Ep 25 / 52</div>
                    </div>
                    <div class="DivAbsolute w-52 h-36 bg-gradient-to-t from-zinc-100 to-zinc-100"></div>
                    <div class="Heading3ZhenWuDianfeng2ndSeason text-zinc-950 text-xs font-semibold leading-none">Zhen Wu Dianfeng 2nd Season</div>
                  </div>
                </div>
              </div>
            </div>
            <div class="LinkLihatSemua text-zinc-950 text-sm font-medium leading-tight">Lihat Semua</div>
          </div>
          <div class="DivFlex w-96 left-[16px] top-[1368.38px] absolute justify-between items-start gap-96 inline-flex">
            <div class="Heading3 justify-start items-start flex">
              <div class="Finished text-zinc-950 text-base font-semibold leading-normal">Finished</div>
            </div>
            <div class="Link justify-start items-start flex">
              <div class="ShowAll text-zinc-500 text-base font-normal leading-normal">Show all</div>
            </div>
          </div>
          <div class="DivWFull h-96 pb-2 left-[16px] top-[1408.38px] absolute flex-col justify-start items-center gap-12 inline-flex">
            <div class="DivGrid w-96 h-96 relative">
              <div class="DivBgCard w-52 h-72 p-px left-0 top-0 absolute bg-white rounded-md shadow border border-zinc-200 flex-col justify-center items-center inline-flex">
                <div class="DivBgMuted self-stretch grow shrink basis-0 bg-zinc-100 flex-col justify-center items-center inline-flex">
                  <div class="Link self-stretch h-72 px-2 pt-2.5 pb-2 flex-col justify-start items-start gap-52 inline-flex">
                    <div class="Heading3 px-2 pt-0.5 pb-1 bg-white rounded-full justify-start items-start inline-flex">
                      <div class="65 text-zinc-950 text-xs font-normal leading-none">6.65</div>
                    </div>
                    <div class="DivAbsolute w-52 h-36 bg-gradient-to-t from-zinc-100 to-zinc-100"></div>
                    <div class="Heading3 w-48 pr-9 pb-px justify-start items-start inline-flex">
                      <div class="FateZeroOnegaiEinzbernSoudanshitsu text-zinc-950 text-xs font-semibold leading-none">Fate/Zero: Onegai! Einzbern<br/>Soudanshitsu</div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="DivBgCard w-52 h-72 p-px left-[232px] top-0 absolute bg-white rounded-md shadow border border-zinc-200 flex-col justify-center items-center inline-flex">
                <div class="DivBgMuted self-stretch grow shrink basis-0 bg-zinc-100 flex-col justify-center items-center inline-flex">
                  <div class="Link self-stretch h-72 pl-2 pr-28 py-2.5 flex-col justify-start items-start gap-56 inline-flex">
                    <div class="Heading3 px-2 pt-0.5 pb-1 bg-white rounded-full justify-start items-start inline-flex">
                      <div class="64 text-zinc-950 text-xs font-normal leading-none">6.64</div>
                    </div>
                    <div class="DivAbsolute w-52 h-36 bg-gradient-to-t from-zinc-100 to-zinc-100"></div>
                    <div class="Heading3FatePrototype text-zinc-950 text-xs font-semibold leading-none">Fate/Prototype</div>
                  </div>
                </div>
              </div>
              <div class="DivBgCard w-52 h-72 p-px left-[464px] top-0 absolute bg-white rounded-md shadow border border-zinc-200 flex-col justify-center items-center inline-flex">
                <div class="DivBgMuted self-stretch grow shrink basis-0 bg-zinc-100 flex-col justify-center items-center inline-flex">
                  <div class="Link self-stretch h-72 pl-2 pr-36 py-2.5 flex-col justify-start items-start gap-56 inline-flex">
                    <div class="Heading3 px-2 pt-0.5 pb-1 bg-white rounded-full justify-start items-start inline-flex">
                      <div class="28 text-zinc-950 text-xs font-normal leading-none">8.28</div>
                    </div>
                    <div class="DivAbsolute w-52 h-36 bg-gradient-to-t from-zinc-100 to-zinc-100"></div>
                    <div class="Heading3FateZero text-zinc-950 text-xs font-semibold leading-none">Fate/Zero</div>
                  </div>
                </div>
              </div>
              <div class="DivBgCard w-52 h-72 p-px left-[696px] top-0 absolute bg-white rounded-md shadow border border-zinc-200 flex-col justify-center items-center inline-flex">
                <div class="DivBgMuted self-stretch grow shrink basis-0 bg-zinc-100 flex-col justify-center items-center inline-flex">
                  <div class="Link self-stretch h-72 pl-2 pr-20 py-2.5 flex-col justify-start items-start gap-56 inline-flex">
                    <div class="Heading3 px-2 pt-0.5 pb-1 bg-white rounded-full justify-start items-start inline-flex">
                      <div class="61 text-zinc-950 text-xs font-normal leading-none">7.61</div>
                    </div>
                    <div class="DivAbsolute w-52 h-36 bg-gradient-to-t from-zinc-100 to-zinc-100"></div>
                    <div class="Heading3NierAutomataVer11a text-zinc-950 text-xs font-semibold leading-none">NieR:Automata Ver1.1a</div>
                  </div>
                </div>
              </div>
              <div class="DivBgCard w-52 h-72 p-px left-[928px] top-0 absolute bg-white rounded-md shadow border border-zinc-200 flex-col justify-center items-center inline-flex">
                <div class="DivBgMuted self-stretch grow shrink basis-0 bg-zinc-100 flex-col justify-center items-center inline-flex">
                  <div class="Link self-stretch h-72 pl-2 pr-32 py-2.5 flex-col justify-start items-start gap-56 inline-flex">
                    <div class="Heading3 px-2 pt-0.5 pb-1 bg-white rounded-full justify-start items-start inline-flex">
                      <div class="15 text-zinc-950 text-xs font-normal leading-none">7.15</div>
                    </div>
                    <div class="DivAbsolute w-52 h-36 bg-gradient-to-t from-zinc-100 to-zinc-100"></div>
                    <div class="Heading3AiyouDeMishi text-zinc-950 text-xs font-semibold leading-none">Aiyou de Mishi</div>
                  </div>
                </div>
              </div>
              <div class="DivBgCard w-52 h-72 p-px left-[1160px] top-0 absolute bg-white rounded-md shadow border border-zinc-200 flex-col justify-center items-center inline-flex">
                <div class="DivBgMuted self-stretch grow shrink basis-0 bg-zinc-100 flex-col justify-center items-center inline-flex">
                  <div class="Link self-stretch h-72 pl-2 pr-28 py-2.5 flex-col justify-start items-start gap-56 inline-flex">
                    <div class="Heading3 px-2 pt-0.5 pb-1 bg-white rounded-full justify-start items-start inline-flex">
                      <div class="28 text-zinc-950 text-xs font-normal leading-none">7.28</div>
                    </div>
                    <div class="DivAbsolute w-52 h-36 bg-gradient-to-t from-zinc-100 to-zinc-100"></div>
                    <div class="Heading3FateStayNight text-zinc-950 text-xs font-semibold leading-none">Fate/stay night</div>
                  </div>
                </div>
              </div>
              <div class="DivBgCard w-52 h-72 p-px left-0 top-[303.32px] absolute bg-white rounded-md shadow border border-zinc-200 flex-col justify-center items-center inline-flex">
                <div class="DivBgMuted self-stretch grow shrink basis-0 bg-zinc-100 flex-col justify-center items-center inline-flex">
                  <div class="Link self-stretch h-72 pl-2 pr-6 pt-2.5 pb-2 flex-col justify-start items-start gap-56 inline-flex">
                    <div class="Heading3 px-2 pt-0.5 pb-1 bg-white rounded-full justify-start items-start inline-flex">
                      <div class="40 text-zinc-950 text-xs font-normal leading-none">7.40</div>
                    </div>
                    <div class="DivAbsolute w-52 h-36 bg-gradient-to-t from-zinc-100 to-zinc-100"></div>
                    <div class="Heading3ShuumatsuNoWalkReIiPart2 text-zinc-950 text-xs font-semibold leading-none">Shuumatsu no Walküre II Part 2</div>
                  </div>
                </div>
              </div>
              <div class="DivBgCard w-52 h-72 p-px left-[232px] top-[303.32px] absolute bg-white rounded-md shadow border border-zinc-200 flex-col justify-center items-center inline-flex">
                <div class="DivBgMuted self-stretch grow shrink basis-0 bg-zinc-100 flex-col justify-center items-center inline-flex">
                  <div class="Link self-stretch h-72 pl-2 pr-16 pt-2.5 pb-2 flex-col justify-start items-start gap-56 inline-flex">
                    <div class="Heading3 px-2 pt-0.5 pb-1 bg-white rounded-full justify-start items-start inline-flex">
                      <div class="52 text-zinc-950 text-xs font-normal leading-none">7.52</div>
                    </div>
                    <div class="DivAbsolute w-52 h-36 bg-gradient-to-t from-zinc-100 to-zinc-100"></div>
                    <div class="Heading3ShuumatsuNoWalkReIi text-zinc-950 text-xs font-semibold leading-none">Shuumatsu no Walküre II</div>
                  </div>
                </div>
              </div>
              <div class="DivBgCard w-52 h-72 p-px left-[464px] top-[303.32px] absolute bg-white rounded-md shadow border border-zinc-200 flex-col justify-center items-center inline-flex">
                <div class="DivBgMuted self-stretch grow shrink basis-0 bg-zinc-100 flex-col justify-center items-center inline-flex">
                  <div class="Link self-stretch h-72 px-2 pt-2.5 pb-2 flex-col justify-start items-start gap-52 inline-flex">
                    <div class="Heading3 px-2 pt-0.5 pb-1 bg-white rounded-full justify-start items-start inline-flex">
                      <div class="68 text-zinc-950 text-xs font-normal leading-none">7.68</div>
                    </div>
                    <div class="DivAbsolute w-52 h-36 bg-gradient-to-t from-zinc-100 to-zinc-100"></div>
                    <div class="Heading3 w-48 pr-7 pb-px justify-start items-start inline-flex">
                      <div class="TheIdolmSterCinderellaGirlsU149 text-zinc-950 text-xs font-semibold leading-none">The IDOLM@STER Cinderella<br/>Girls: U149</div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="DivBgCard w-52 h-72 p-px left-[696px] top-[303.32px] absolute bg-white rounded-md shadow border border-zinc-200 flex-col justify-center items-center inline-flex">
                <div class="DivBgMuted self-stretch grow shrink basis-0 bg-zinc-100 flex-col justify-center items-center inline-flex">
                  <div class="Link self-stretch h-72 pl-2 pr-12 pt-2.5 pb-2 flex-col justify-start items-start gap-56 inline-flex">
                    <div class="Heading3 px-2 pt-0.5 pb-1 bg-white rounded-full justify-start items-start inline-flex">
                      <div class="02 text-zinc-950 text-xs font-normal leading-none">8.02</div>
                    </div>
                    <div class="DivAbsolute w-52 h-36 bg-gradient-to-t from-zinc-100 to-zinc-100"></div>
                    <div class="Heading3KimiWaHoukagoInsomnia text-zinc-950 text-xs font-semibold leading-none">Kimi wa Houkago Insomnia</div>
                  </div>
                </div>
              </div>
              <div class="DivBgCard w-52 h-72 p-px left-[928px] top-[303.32px] absolute bg-white rounded-md shadow border border-zinc-200 flex-col justify-center items-center inline-flex">
                <div class="DivBgMuted self-stretch grow shrink basis-0 bg-zinc-100 flex-col justify-center items-center inline-flex">
                  <div class="Link self-stretch h-72 px-2 pt-2.5 pb-2 flex-col justify-start items-start gap-52 inline-flex">
                    <div class="Heading3 px-2 pt-0.5 pb-1 bg-white rounded-full justify-start items-start inline-flex">
                      <div class="71 text-zinc-950 text-xs font-normal leading-none">6.71</div>
                    </div>
                    <div class="DivAbsolute w-52 h-36 bg-gradient-to-t from-zinc-100 to-zinc-100"></div>
                    <div class="Heading3 w-48 pr-7 pb-px justify-start items-start inline-flex">
                      <div class="KaminakiSekaiNoKamisamaKatsudou text-zinc-950 text-xs font-semibold leading-none">Kaminaki Sekai no Kamisama<br/>Katsudou</div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="DivBgCard w-52 h-72 p-px left-[1160px] top-[303.32px] absolute bg-white rounded-md shadow border border-zinc-200 flex-col justify-center items-center inline-flex">
                <div class="DivBgMuted self-stretch grow shrink basis-0 bg-zinc-100 flex-col justify-center items-center inline-flex">
                  <div class="Link self-stretch h-72 pl-2 pr-9 pt-2.5 pb-2 flex-col justify-start items-start gap-56 inline-flex">
                    <div class="Heading3 px-2 pt-0.5 pb-1 bg-white rounded-full justify-start items-start inline-flex">
                      <div class=" text-zinc-950 text-xs font-normal leading-none">?</div>
                    </div>
                    <div class="DivAbsolute w-52 h-36 bg-gradient-to-t from-zinc-100 to-zinc-100"></div>
                    <div class="Heading3DuoXuanShiQianQingPian text-zinc-950 text-xs font-semibold leading-none">Duo Xuan Shi: Qian Qing Pian</div>
                  </div>
                </div>
              </div>
              <div class="DivBgCard w-52 h-72 p-px left-0 top-[606.65px] absolute bg-white rounded-md shadow border border-zinc-200 flex-col justify-center items-center inline-flex">
                <div class="DivBgMuted self-stretch grow shrink basis-0 bg-zinc-100 flex-col justify-center items-center inline-flex">
                  <div class="Link self-stretch h-72 pl-2 pr-20 pt-2.5 pb-2 flex-col justify-start items-start gap-56 inline-flex">
                    <div class="Heading3 px-2 pt-0.5 pb-1 bg-white rounded-full justify-start items-start inline-flex">
                      <div class="61 text-zinc-950 text-xs font-normal leading-none">6.61</div>
                    </div>
                    <div class="DivAbsolute w-52 h-36 bg-gradient-to-t from-zinc-100 to-zinc-100"></div>
                    <div class="Heading3FateStrangeFakePv text-zinc-950 text-xs font-semibold leading-none">Fate/strange Fake PV</div>
                  </div>
                </div>
              </div>
              <div class="DivBgCard w-52 h-72 p-px left-[232px] top-[606.65px] absolute bg-white rounded-md shadow border border-zinc-200 flex-col justify-center items-center inline-flex">
                <div class="DivBgMuted self-stretch grow shrink basis-0 bg-zinc-100 flex-col justify-center items-center inline-flex">
                  <div class="Link self-stretch h-72 px-2 pt-2.5 pb-2 flex-col justify-start items-start gap-52 inline-flex">
                    <div class="Heading3 px-2 pt-0.5 pb-1 bg-white rounded-full justify-start items-start inline-flex">
                      <div class="54 text-zinc-950 text-xs font-normal leading-none">7.54</div>
                    </div>
                    <div class="DivAbsolute w-52 h-36 bg-gradient-to-t from-zinc-100 to-zinc-100"></div>
                    <div class="Heading3 w-48 pr-1.5 pb-px justify-start items-start inline-flex">
                      <div class="MushokuTenseiIiIsekaiIttaraHonkiDasuShugoJutsushiFitz text-zinc-950 text-xs font-semibold leading-none">Mushoku Tensei II: Isekai Ittara<br/>Honki Dasu - Shugo Jutsushi Fitz</div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="DivBgCard w-52 h-72 p-px left-[464px] top-[606.65px] absolute bg-white rounded-md shadow border border-zinc-200 flex-col justify-center items-center inline-flex">
                <div class="DivBgMuted self-stretch grow shrink basis-0 bg-zinc-100 flex-col justify-center items-center inline-flex">
                  <div class="Link self-stretch h-72 pl-2 pr-36 pt-2.5 pb-2 flex-col justify-start items-start gap-56 inline-flex">
                    <div class="Heading3 px-2 pt-0.5 pb-1 bg-white rounded-full justify-start items-start inline-flex">
                      <div class="25 text-zinc-950 text-xs font-normal leading-none">8.25</div>
                    </div>
                    <div class="DivAbsolute w-52 h-36 bg-gradient-to-t from-zinc-100 to-zinc-100"></div>
                    <div class="Heading3Jigokuraku text-zinc-950 text-xs font-semibold leading-none">Jigokuraku</div>
                  </div>
                </div>
              </div>
              <div class="DivBgCard w-52 h-72 p-px left-[696px] top-[606.65px] absolute bg-white rounded-md shadow border border-zinc-200 flex-col justify-center items-center inline-flex">
                <div class="DivBgMuted self-stretch grow shrink basis-0 bg-zinc-100 flex-col justify-center items-center inline-flex">
                  <div class="Link self-stretch h-72 px-2 pt-2.5 pb-2 flex-col justify-start items-start gap-52 inline-flex">
                    <div class="Heading3 px-2 pt-0.5 pb-1 bg-white rounded-full justify-start items-start inline-flex">
                      <div class="27 text-zinc-950 text-xs font-normal leading-none">8.27</div>
                    </div>
                    <div class="DivAbsolute w-52 h-36 bg-gradient-to-t from-zinc-100 to-zinc-100"></div>
                    <div class="Heading3 w-48 pr-2.5 pb-px justify-start items-start inline-flex">
                      <div class="KidouSenshiGundamSuiseiNoMajoSeason2 text-zinc-950 text-xs font-semibold leading-none">Kidou Senshi Gundam: Suisei no<br/>Majo Season 2</div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="DivBgCard w-52 h-72 p-px left-[928px] top-[606.65px] absolute bg-white rounded-md shadow border border-zinc-200 flex-col justify-center items-center inline-flex">
                <div class="DivBgMuted self-stretch grow shrink basis-0 bg-zinc-100 flex-col justify-center items-center inline-flex">
                  <div class="Link self-stretch h-72 pl-2 pr-20 pt-2.5 pb-2 flex-col justify-start items-start gap-56 inline-flex">
                    <div class="Heading3 px-2 pt-0.5 pb-1 bg-white rounded-full justify-start items-start inline-flex">
                      <div class="13 text-zinc-950 text-xs font-normal leading-none">6.13</div>
                    </div>
                    <div class="DivAbsolute w-52 h-36 bg-gradient-to-t from-zinc-100 to-zinc-100"></div>
                    <div class="Heading3BaMaLaiziErCiyuan text-zinc-950 text-xs font-semibold leading-none">Ba Ma Laizi Er Ciyuan</div>
                  </div>
                </div>
              </div>
              <div class="DivBgCard w-52 h-72 p-px left-[1160px] top-[606.65px] absolute bg-white rounded-md shadow border border-zinc-200 flex-col justify-center items-center inline-flex">
                <div class="DivBgMuted self-stretch grow shrink basis-0 bg-zinc-100 flex-col justify-center items-center inline-flex">
                  <div class="Link self-stretch h-72 pl-2 pr-32 pt-2.5 pb-2 flex-col justify-start items-start gap-56 inline-flex">
                    <div class="Heading3 px-2 pt-0.5 pb-1 bg-white rounded-full justify-start items-start inline-flex">
                      <div class="93 text-zinc-950 text-xs font-normal leading-none">5.93</div>
                    </div>
                    <div class="DivAbsolute w-52 h-36 bg-gradient-to-t from-zinc-100 to-zinc-100"></div>
                    <div class="Heading3WanGuoZhi text-zinc-950 text-xs font-semibold leading-none">Wan Guo Zhi</div>
                  </div>
                </div>
              </div>
            </div>
            <div class="LinkLihatSemua text-zinc-950 text-sm font-medium leading-tight">Lihat Semua</div>
          </div>
        </div>
        <div class="DivFlex w-96 left-[16px] top-[16px] absolute justify-between items-start gap-96 inline-flex">
          <div class="DivSpaceX4 justify-start items-start gap-4 flex">
            <div class="Button h-9 p-1.5 bg-white rounded-full justify-center items-center flex">
              <div class="Svg h-6 pl-2 pr-2.5 py-1.5 justify-start items-start flex"></div>
            </div>
            <div class="Button h-9 p-1.5 bg-white rounded-full justify-center items-center flex">
              <div class="Svg h-6 pl-2.5 pr-2 py-1.5 justify-start items-start flex"></div>
            </div>
          </div>
          <div class="DivFlex justify-start items-start gap-4 flex">
            <div class="Button px-3 pt-1.5 pb-2 bg-zinc-900 rounded-full shadow justify-center items-start gap-1.5 flex">
              <div class="Svg self-stretch px-px py-px justify-start items-start inline-flex"></div>
              <div class="Contribution text-center text-neutral-50 text-xs font-medium leading-none">Contribution</div>
            </div>
            <div class="Button h-9 p-2.5 bg-white rounded-full justify-center items-center flex">
              <div class="Svg h-4 pt-0.5 pb-px justify-start items-start flex"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="Aside w-64 self-stretch p-1 bg-white flex-col justify-start items-start gap-2 inline-flex">
      <div class="DivBgZinc100 w-60 grow shrink basis-0 px-4 pt-4 pb-36 bg-zinc-100 rounded-md justify-center items-start inline-flex">
        <div class="DivMaxH80 w-52 pb-10 rounded-md flex-col justify-start items-center inline-flex">
          <div class="DivRelative w-52 h-72 relative flex-col justify-start items-start flex">
            <div class="Pseudo w-52 h-72 bg-gradient-to-r from-black via-zinc-300 to-black"></div>
            <div class="DivAbsolute w-20 px-4 pt-1 pb-1.5 bg-white bg-opacity-50 rounded-full border border-zinc-200 justify-start items-start inline-flex">
              <div class="Sponsors text-zinc-950 text-xs font-normal leading-none">Sponsors</div>
            </div>
          </div>
        </div>
      </div>
      <div class="DivBgZinc100 w-60 grow shrink basis-0 px-4 pt-4 pb-36 bg-zinc-100 rounded-md justify-center items-start inline-flex">
        <div class="DivMaxH80 w-52 pb-10 rounded-md flex-col justify-start items-center inline-flex">
          <div class="DivRelative self-stretch justify-start items-start inline-flex">
            <div class="DivWFull grow shrink basis-0 h-72 bg-white bg-opacity-0 shadow"></div>
            <div class="DivAbsolute h-6 px-4 pt-1 pb-1.5 bg-white bg-opacity-50 rounded-full border border-zinc-200 justify-start items-start flex">
              <div class="Queue text-zinc-950 text-xs font-normal leading-none">Queue</div>
            </div>
            <div class="Pseudo w-52 h-72 bg-gradient-to-r from-black via-zinc-300 to-black"></div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="Footer w-96 pl-96 pr-4 justify-start items-start inline-flex">
    <div class="DivColSpan3 w-96 px-96 flex-col justify-center items-center inline-flex">
      <div class="Link h-16 flex-col justify-start items-center flex">
        <div class="Svg w-10 h-10 relative">
          <div class="Group w-5 h-5 left-[9.12px] top-[9.05px] absolute">
          </div>
        </div>
        <div class="DivFontBold w-24 justify-start items-start inline-flex">
          <div class="Nekomoe"><span style="text-zinc-950 text-opacity-50 text-xl font-bold leading-7">Neko</span><span style="text-green-400 text-xl font-bold leading-7">moe</span></div>
        </div>
      </div>
    </div>
    <div class="DivColSpan1 h-16 pl-80 py-4 justify-end items-center flex">
      <div class="LinkButton h-9 px-4 pt-1.5 pb-2 bg-white rounded-full shadow border border-zinc-200 justify-center items-end gap-2 flex">
        <div class=" text-center text-zinc-950 text-sm font-medium leading-tight">0</div>
        <div class="Svg grow shrink basis-0 self-stretch py-0.5 justify-start items-start inline-flex"></div>
      </div>
    </div>
  </div>
</div>