<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <title>Navbar Sticky</title>
    <!-- Tambahkan link ke Tailwind CSS dan Font Awesome CSS di sini -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.15/dist/tailwind.min.css" rel="stylesheet">
    <!-- Sertakan file CSS eksternal -->
    <link rel="stylesheet" href="navbar_home.css">
</head>
<body>
    <!-- Konten halaman web lainnya di sini -->

    <div class="navbar flex">
        <a href="index.php"><i class="fas fa-home"></i></a> <!-- Menggunakan ikon SEARCH -->
        <a href="search.php"><i class="fas fa-search"></i></a> <!-- Menggunakan ikon HOME -->
        <a href="#" class="active"><i class="fas fa-globe"></i></a>
        <a href="notifikasi.php"><i class="fas fa-bell"></i></a>
        <a href="setting.php"><i class="fas fa-cog"></i></a>
    </div>

</body>
</html>
