<?php

// Koneksi ke database
$db = new PDO('mysql:host=localhost;dbname=ccgnimex', 'ccgnimex', 'aaaaaaac');

// Cek apakah anime_id diberikan dalam query parameter
if (isset($_GET['anime_id'])) {
    $animeId = $_GET['anime_id'];

    // Ambil semua episode dengan anime_id yang sesuai
    $stmt = $db->prepare('SELECT * FROM nonton WHERE anime_id = ? ORDER BY episode_number ASC');
    $stmt->execute([$animeId]);
    $episodes = $stmt->fetchAll();

    // Kirim data episode sebagai respons JSON
    header('Content-Type: application/json');
    echo json_encode($episodes);
} else {
    echo 'Anime ID is not provided.';
}
