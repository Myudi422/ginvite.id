
<style>
    /* Hide scrollbar for Chrome, Safari and Opera */
    #riwayatAnimeGrid::-webkit-scrollbar {
        display: none;
    }

    /* Hide scrollbar for IE, Edge and Firefox */
    #riwayatAnimeGrid {
        -ms-overflow-style: none;  /* IE and Edge */
        scrollbar-width: none;  /* Firefox */
    }
</style>

<style>
    /* ... Your existing CSS ... */

    .anime-card {
        position: relative;
        width: 90%;
        margin: 16px auto; /* Centers the card */
        overflow: hidden;
        border-radius: 10px;
        flex-shrink: 0; /* Prevent cards from shrinking in the flex container */
    }
    .anime-image {
        width: 100%;
        height: 150px;
        object-fit: cover;
    }
    .anime-info {
        position: absolute;
        bottom: 0;
        left: 0;
        width: 100%;
        padding: 8px;
        text-align: center;
    }
    .anime-title {
        font-size: 1rem;
        font-weight: bold;
    }

    #riwayatAnimeGrid {
        display: flex;
        overflow-x: scroll;
        gap: 16px;
        padding: 16px;
    }

    @media (min-width: 480px) {
        .anime-card {
            width: 70%;
        }
    }

    @media (min-width: 768px) {
        .anime-card {
            width: 40%;
        }
    }

    @media (min-width: 1024px) {
        .anime-card {
            width: 30%;
        }
        .anime-title {
            font-size: 1.2rem;
        }
    }

    @media (min-width: 1200px) {
        .anime-card {
            width: 25%;
        }
    }
</style>

<?php
session_start();
$animeHistory = [];
if (isset($_SESSION['telegram_id'])) {
    $telegram_id = $_SESSION['telegram_id'];

    // Your database connection and query here...
    $conn = new mysqli('127.0.0.1', 'ccgnimex', 'aaaaaaac', 'ccgnimex');

    if ($conn->connect_error) {
        die('Connection failed: ' . $conn->connect_error);
    }

    $limit = 6;
    $offset = 0;
$sql = "SELECT wt.anime_id, wt.episode_number, wt.video_time
    FROM waktu_terakhir_tontonan wt
    JOIN (
        SELECT anime_id, MAX(last_watched) as max_last_watched
        FROM waktu_terakhir_tontonan
        WHERE telegram_id = ?
        GROUP BY anime_id
    ) max_last_watched
    ON wt.anime_id = max_last_watched.anime_id AND wt.last_watched = max_last_watched.max_last_watched
    ORDER BY wt.last_watched DESC
    LIMIT ? OFFSET ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sii", $telegram_id, $limit, $offset);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $animeHistory[] = $row;
        }
    }
    $conn->close();
}
?>


<?php if(!empty($animeHistory)): ?>
<section class="mt-5 px-4">
    <div class="flex justify-between items-center mb-4">
        <h2 class="text-2xl font-bold flex items-center">
            <span class="bg-red-500 text-white rounded-full p-1 text-xs mr-2">
                <i class="fas fa-history text-xs"></i>
            </span>
            Riwayat Tontonan
        </h2>
    </div>
    <div id="riwayatLoadingAnimation" class="text-xl flex space-x-2 justify-center py-5">
        <span>.</span><span>.</span><span>.</span>
    </div>
    <div id="riwayatAnimeGrid" class="flex flex-row space-x-4 overflow-x-scroll scrollbar-hide py-2" style="white-space: nowrap; display: none;">
        <!-- Anime cards will be populated here by the JavaScript -->
    </div>
</section>

<script>
    const animeHistory = <?php echo json_encode($animeHistory); ?>;
    const riwayatDatavariables = {
        id_in: animeHistory.map(anime => anime.anime_id)
    };

    const riwayatQuery = `
        query ($id_in: [Int]) {
            Page {
                media (id_in: $id_in, type: ANIME) {
                    id
                    title {
                        romaji
                    }
                    coverImage {
                        large
                    }
                    averageScore
                    popularity
                    trailer {
                        site
                        id
                    }
                    status
                }
            }
        }
    `;

    const riwayatUrl = 'https://graphql.anilist.co';

    async function riwayatFetchData() {
        const response = await fetch(riwayatUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
            },
            body: JSON.stringify({
                query: riwayatQuery,
                variables: riwayatDatavariables,
            }),
        });
        const data = await response.json();

        // Sort data based on the original order of IDs in animeHistory
        data.data.Page.media.sort((a, b) => {
            const orderA = animeHistory.findIndex(anime => anime.anime_id == a.id);
            const orderB = animeHistory.findIndex(anime => anime.anime_id == b.id);
            return orderA - orderB;
        });

        console.log(data.data.Page.media); // Log data ke console
        riwayatDisplayData(data);
    }

    function riwayatFormatPopularity(value) {
        if (value >= 1000) {
            return (value / 1000).toFixed(1) + 'K';
        }
        return value;
    }

function riwayatDisplayData(data) {
    document.getElementById("riwayatLoadingAnimation").style.display = "none";
    const riwayatAnimeGrid = document.getElementById("riwayatAnimeGrid");
    riwayatAnimeGrid.style.display = "flex";
    riwayatAnimeGrid.innerHTML = "";

    data.data.Page.media.forEach((anime, index) => {
        let formattedPopularity = anime.popularity ? riwayatFormatPopularity(anime.popularity) : 'N/A';

        // Get the episode number from the animeHistory array
        const episodeNumber = animeHistory[index].episode_number;

        // Create the streaming link with episode number
        const streamingLink = `https://ccgnimex.my.id/v2/streaming.php?anime_id=${anime.id}&EP=${episodeNumber}`;

        riwayatAnimeGrid.innerHTML += `
            <div class="anime-card">
                <img class="anime-image" src="${anime.coverImage.large}" alt="${anime.title.romaji}" loading="lazy">
                <a href="${streamingLink}" class="anime-info bg-red-100">
                    <div class="anime-title">${anime.title.romaji}</div>
                    <div class="anime-rating">${anime.averageScore ? anime.averageScore + '%' : 'N/A'}</div>
                </a>
            </div>
        `;
    });
}

window.addEventListener("load", function() {
    riwayatFetchData();
});

    
    document.addEventListener("DOMContentLoaded", function() {
    let isDown = false;
    let startX;
    let scrollLeft;
    const riwayatAnimeGrid = document.getElementById('riwayatAnimeGrid');

    riwayatAnimeGrid.addEventListener('mousedown', (e) => {
        isDown = true;
        startX = e.pageX - riwayatAnimeGrid.offsetLeft;
        scrollLeft = riwayatAnimeGrid.scrollLeft;
    });

    riwayatAnimeGrid.addEventListener('mouseleave', () => {
        isDown = false;
        riwayatAnimeGrid.style.cursor = 'grab';
    });

    riwayatAnimeGrid.addEventListener('mouseup', () => {
        isDown = false;
        riwayatAnimeGrid.style.cursor = 'grab';
    });

    riwayatAnimeGrid.addEventListener('mousemove', (e) => {
        if (!isDown) return;
        e.preventDefault();
        const x = e.pageX - riwayatAnimeGrid.offsetLeft;
        const walk = (x - startX) * 3; //scroll-fast
        riwayatAnimeGrid.scrollLeft = scrollLeft - walk;
        riwayatAnimeGrid.style.cursor = 'grabbing';
    });
});

</script>
<?php endif; ?>