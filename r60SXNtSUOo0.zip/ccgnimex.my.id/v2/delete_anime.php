<?php

// Define your database connection details
$servername = "localhost";
$username = "ccgnimex";
$password = "aaaaaaac";
$dbname = "ccgnimex";

// Create a database connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check if the connection is successful
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the anime_id and hari parameters are set and not empty
if (isset($_POST['anime_id']) && !empty($_POST['anime_id']) && isset($_POST['hari']) && !empty($_POST['hari'])) {
    // Sanitize the anime_id and hari to prevent SQL injection
    $anime_id = mysqli_real_escape_string($conn, $_POST['anime_id']);
    $hari = mysqli_real_escape_string($conn, $_POST['hari']);

    // Define the SQL query to delete the anime with the specified ID and hari
    $sql = "DELETE FROM jadwal WHERE anime_id = '$anime_id' AND hari = '$hari'";

    // Perform the deletion query
    if ($conn->query($sql) === true) {
        // Deletion was successful
        echo "success";
    } else {
        // Deletion failed
        echo "error: " . $conn->error;
    }
} else {
    // If anime_id or hari is not provided or empty
    echo "error: Missing anime_id or hari";
}

// Close the database connection
$conn->close();
?>
