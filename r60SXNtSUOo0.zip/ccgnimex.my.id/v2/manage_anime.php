<?php
if (isset($_GET['anime_id'])) {
    $animeId = $_GET['anime_id'];
} else {
    echo 'Anime ID is not provided.';
    exit;
}

$db = new PDO('mysql:host=localhost;dbname=ccgnimex', 'ccgnimex', 'aaaaaaac');

if (isset($_POST['update_jadwal'])) {
    $anime_id = $_POST['anime_id'];

    if (empty($anime_id)) {
        echo 'Silahkan masukkan ID Anime!';
    } else {
        date_default_timezone_set('Asia/Jakarta');
        $hari = date('l'); // Hari dalam bahasa Inggris, seperti 'Monday'
        $jam = date("H:i");

        // Konversi nama hari ke bahasa Indonesia
        $namaHari = array(
            'Sunday' => 'Minggu',
            'Monday' => 'Senin',
            'Tuesday' => 'Selasa',
            'Wednesday' => 'Rabu',
            'Thursday' => 'Kamis',
            'Friday' => 'Jumat',
            'Saturday' => 'Sabtu'
        );
        $hari = $namaHari[$hari];

        // Cek apakah anime ID ada dalam tabel jadwal
        $stmt = $db->prepare('SELECT COUNT(*) FROM jadwal WHERE anime_id = ?');
        $stmt->execute([$anime_id]);
        $animeExistsInJadwal = $stmt->fetchColumn();

        if ($animeExistsInJadwal) {
            // Update jadwal
            $stmt = $db->prepare('UPDATE jadwal SET hari = ?, jam = ? WHERE anime_id = ?');
            $stmt->execute([$hari, $jam, $anime_id]);
            echo 'Jadwal berhasil diperbarui!';
        } else {
            echo 'Anime ID tidak ditemukan dalam tabel jadwal.';
        }
    }
}


// Cek apakah form telah disubmit
if (isset($_POST['submit'])) {
    // Ambil data dari form
    $anime_id = $_POST['anime_id'];
    $episode_links_en = $_POST['episode_links_en'];
    $episode_links_pt = $_POST['episode_links_pt'];
    $episode_links_softsub = $_POST['episode_links_softsub'];
    $link_count = $_POST['link_count'];
    $episode_number_start = $_POST['episode_number_start'];
    $episode_number_end = $_POST['episode_number_end'];
    $episode_number_manual = $_POST['episode_number_manual'];
    $thumbnail_link = $_POST['thumbnail_link'];

    // Cek apakah anime_id kosong
    if (empty($anime_id)) {
        echo 'Silahkan masukkan ID Anime!';
    } else {
        // Pisahkan setiap link menjadi array
        $links_en = explode("\n", $episode_links_en);
        $links_pt = explode("\n", $episode_links_pt);
        $links_softsub = explode("\n", $episode_links_softsub);

        // Validasi setiap link
        $valid_links_en = [];
        foreach ($links_en as $link) {
            $link = trim($link);
            if (!empty($link) && strpos($link, 'https://t.me/c/1844389952/') === 0) {
                // Ubah link menjadi format yang diinginkan
                $link_parts = explode('/', $link);
                $new_link = 'https://subjective-tobye-myudi422.koyeb.app/' . end($link_parts);
                $valid_links_en[] = $new_link;

                // Tambahkan link tambahan sesuai dengan jumlah yang dimasukkan
                for ($i = 1; $i < $link_count; $i++) {
                    $next_link_number = end($link_parts) + $i;
                    $next_link = 'https://subjective-tobye-myudi422.koyeb.app/' . $next_link_number;
                    $valid_links_en[] = $next_link;
                }
            }
        }
        
$valid_thumbnail_links = [];
if (!empty($thumbnail_link) && strpos($thumbnail_link, 'https://t.me/c/1844389952/') === 0) {
    // Change the link format as needed
    $link_parts = explode('/', $thumbnail_link);
    
    // Insert or update the thumbnail link in the 'thumbnail' table and generate additional links
    for ($i = 0; $i < $link_count; $i++) {
        $next_thumbnail_number = end($link_parts) + $i;
        $next_thumbnail_link = 'https://subjective-tobye-myudi422.koyeb.app/' . $next_thumbnail_number;

        // Check if the thumbnail link already exists
        $stmt = $db->prepare('SELECT COUNT(*) FROM thumbnail WHERE anime_id = ? AND episode_number = ?');
        $stmt->execute([$anime_id, $episode_number_start + $i]);
        $thumbnail_exists = $stmt->fetchColumn() > 0;

        if ($thumbnail_exists) {
            // If the thumbnail link already exists, update the existing row
            $stmt = $db->prepare('UPDATE thumbnail SET link_gambar = ? WHERE anime_id = ? AND episode_number = ?');
            $stmt->execute([$next_thumbnail_link, $anime_id, $episode_number_start + $i]);
        } else {
            // If the thumbnail link doesn't exist, insert a new row
            $stmt = $db->prepare('INSERT INTO thumbnail (anime_id, episode_number, link_gambar) VALUES (?, ?, ?)');
            $stmt->execute([$anime_id, $episode_number_start + $i, $next_thumbnail_link]);
        }

        $valid_thumbnail_links[] = $next_thumbnail_link;
    }
}


        $valid_links_pt = [];
        foreach ($links_pt as $link) {
            $link = trim($link);
            if (!empty($link) && strpos($link, 'https://t.me/c/1844389952/') === 0) {
                // Ubah link menjadi format yang diinginkan
                $link_parts = explode('/', $link);
                $new_link = 'https://subjective-tobye-myudi422.koyeb.app/' . end($link_parts);
                $valid_links_pt[] = $new_link;

                // Tambahkan link tambahan sesuai dengan jumlah yang dimasukkan
                for ($i = 1; $i < $link_count; $i++) {
                    $next_link_number = end($link_parts) + $i;
                    $next_link = 'https://subjective-tobye-myudi422.koyeb.app/' . $next_link_number;
                    $valid_links_pt[] = $next_link;
                }
            }
        }

        $valid_links_softsub = [];
        foreach ($links_softsub as $link) {
            $link = trim($link);
            if (!empty($link) && strpos($link, 'https://t.me/c/1844389952/') === 0) {
                // Ubah link menjadi format yang diinginkan
                $link_parts = explode('/', $link);
                $new_link = 'https://subjective-tobye-myudi422.koyeb.app/' . end($link_parts);
                $valid_links_softsub[] = $new_link;

                // Tambahkan link tambahan sesuai dengan jumlah yang dimasukkan
                for ($i = 1; $i < $link_count; $i++) {
                    $next_link_number = end($link_parts) + $i;
                    $next_link = 'https://subjective-tobye-myudi422.koyeb.app/' . $next_link_number;
                    $valid_links_softsub[] = $next_link;
                }
            }
        }

        if (empty($valid_links_en) && empty($valid_links_pt) && empty($valid_links_softsub)) {
            echo 'Mohon masukkan link yang valid!';
        } else {
            // Tampilkan episode yang sudah ada di dalam database
            $stmt = $db->prepare('SELECT * FROM nonton WHERE anime_id = ? ORDER BY episode_number ASC');
            $stmt->execute([$anime_id]);
            $episodes = $stmt->fetchAll();

            echo '<ul>';
            foreach ($episodes as $episode) {
                echo '<li>';
                echo 'Episode ' . htmlspecialchars($episode['episode_number']) . ': ';
                echo ' <button onclick="deleteEpisode(' . htmlspecialchars($episode['id']) . ')">Delete</button>';
                echo '</li>';
            }
            echo '</ul>';

            // Masukkan setiap link ke dalam database sebagai episode terpisah
            foreach ($valid_links_en as $index => $link) {
                $episode_number = $episode_number_start + $index;
                if ($episode_number <= $episode_number_end) {
                    if (!empty($episode_number_manual)) {
                        // Jika nomor episode manual dimasukkan, gunakan sebagai episode_number
                        $episode_number = intval($episode_number_manual);
                    }

                    // Cek apakah episode sudah ada di dalam database
                    // Tambahkan resolusi sebagai parameter tambahan untuk mengecek duplikat
                    $stmt = $db->prepare('SELECT COUNT(*) FROM nonton WHERE anime_id = ? AND episode_number = ? AND resolusi = ?');
                    $stmt->execute([$anime_id, $episode_number, 'en']);
                    if ($stmt->fetchColumn() == 0) {
                        // Episode belum ada di dalam database, masukkan ke dalam tabel nonton
                        $stmt = $db->prepare('INSERT INTO nonton (anime_id, episode_number, title, video_url, resolusi) VALUES (?, ?, ?, ?, ?)');
                        $stmt->execute([$anime_id, $episode_number, 'Episode ' . $episode_number, $link, 'en']);
                    }
                }
            }

            foreach ($valid_links_pt as $index => $link) {
                $episode_number = $episode_number_start + $index;
                if ($episode_number <= $episode_number_end) {
                    if (!empty($episode_number_manual)) {
                        // Jika nomor episode manual dimasukkan, gunakan sebagai episode_number
                        $episode_number = intval($episode_number_manual);
                    }

                    // Cek apakah episode sudah ada di dalam database
                    // Tambahkan resolusi sebagai parameter tambahan untuk mengecek duplikat
                    $stmt = $db->prepare('SELECT COUNT(*) FROM nonton WHERE anime_id = ? AND episode_number = ? AND resolusi = ?');
                    $stmt->execute([$anime_id, $episode_number, 'pt']);
                    if ($stmt->fetchColumn() == 0) {
                        // Episode belum ada di dalam database, masukkan ke dalam tabel nonton
                        $stmt = $db->prepare('INSERT INTO nonton (anime_id, episode_number, title, video_url, resolusi) VALUES (?, ?, ?, ?, ?)');
                        $stmt->execute([$anime_id, $episode_number, 'Episode ' . $episode_number, $link, 'pt']);
                    }
                }
            }

            foreach ($valid_links_softsub as $index => $link) {
                $episode_number = $episode_number_start + $index;
                if ($episode_number <= $episode_number_end) {
                    if (!empty($episode_number_manual)) {
                        // Jika nomor episode manual dimasukkan, gunakan sebagai episode_number
                        $episode_number = intval($episode_number_manual);
                    }

                    // Cek apakah episode sudah ada di dalam database
                    // Tambahkan resolusi sebagai parameter tambahan untuk mengecek duplikat
                    $stmt = $db->prepare('SELECT COUNT(*) FROM nonton WHERE anime_id = ? AND episode_number = ? AND resolusi = ?');
                    $stmt->execute([$anime_id, $episode_number, 'softsub']);
                    if ($stmt->fetchColumn() == 0) {
                        // Episode belum ada di dalam database, masukkan ke dalam tabel nonton
                        $stmt = $db->prepare('INSERT INTO nonton (anime_id, episode_number, title, video_url, resolusi) VALUES (?, ?, ?, ?, ?)');
                        $stmt->execute([$anime_id, $episode_number, 'Episode ' . $episode_number, $link, 'softsub']);
                    }
                }
            }

            echo 'Episode berhasil ditambahkan!';
        }
    }
}

// Cek apakah tombol delete ditekan
if (isset($_POST['delete'])) {
    // Ambil ID episode yang akan dihapus
    $episode_id = $_POST['episode_id'];
    // Hapus episode dari database
    $stmt = $db->prepare('DELETE FROM nonton WHERE id = ?');
    $stmt->execute([$episode_id]);

    echo 'Episode berhasil dihapus!';
}
?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Anime</title>
    <!-- Add the Tailwind CSS link here -->
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>

</head>
<body class="bg-gray-100">
    <div class="container mx-auto p-4">
        <h1 class="text-2xl font-bold mb-4">Manage Anime</h1>
        <div class="flex justify-between mb-4">
            <button id="addEpisodeButton" class="bg-blue-500 text-white font-bold py-2 px-4 rounded">Add Episode</button>
            <button id="manageEpisodeButton" class="bg-green-500 text-white font-bold py-2 px-4 rounded">Manage Episode</button>
        </div>
        <div id="addEpisodeForm">
             <form method="post" class="bg-white p-4 rounded shadow">
            <div class="grid grid-cols-2 gap-4 mb-4">
                <div>
                    <label for="anime_id" class="block text-sm font-medium text-gray-700">ID Anime</label>
                    <input type="text" name="anime_id" class="w-full p-2 border rounded" required value="<?php echo isset($animeId) ? $animeId : ''; ?>">
                </div>
                <div>
                    <label for="link_count" class="block text-sm font-medium text-gray-700">Link Count</label>
                    <input type="number" name="link_count" class="w-full p-2 border rounded" required>
                </div>
            </div>

            <div class="mb-4">
                <label for="episode_links_en" class="block text-sm font-medium text-gray-700">Episode Links (EN)</label>
                <textarea name="episode_links_en" rows="5" class="w-full p-2 border rounded"></textarea>
            </div>

            <div class="mb-4">
                <label for="episode_links_pt" class="block text-sm font-medium text-gray-700">Episode Links (PT)</label>
                <textarea name="episode_links_pt" rows="5" class="w-full p-2 border rounded"></textarea>
            </div>

            <div class="mb-4">
                <label for="episode_links_softsub" class="block text-sm font-medium text-gray-700">Episode Links (Softsub)</label>
                <textarea name="episode_links_softsub" rows="5" class="w-full p-2 border rounded"></textarea>
            </div>

            <div class="grid grid-cols-2 gap-4 mb-4">
                <div>
                    <label for="episode_number_start" class="block text-sm font-medium text-gray-700">Episode Number Start</label>
                    <input type="number" name="episode_number_start" class="w-full p-2 border rounded" required>
                </div>
                <div>
                    <label for="episode_number_end" class="block text-sm font-medium text-gray-700">Episode Number End</label>
                    <input type="number" name="episode_number_end" class="w-full p-2 border rounded" required>
                </div>
            </div>

            <div class="mb-4">
                <label for="episode_number_manual" class="block text-sm font-medium text-gray-700">Manual Episode Number (optional)</label>
                <input type="number" name="episode_number_manual" class="w-full p-2 border rounded">
            </div>
            
            <div class="mb-4">
    <label for="thumbnail_link" class="block text-sm font-medium text-gray-700">Thumbnail Link</label>
    <textarea name="thumbnail_link" rows="2" class="w-full p-2 border rounded"></textarea>
</div>


            <button type="submit" name="submit" class="bg-blue-500 text-white font-bold py-2 px-4 rounded">Simpan Data</button>
        </form>
        </div>

<div id="updateJadwalForm">
    <form method="post" class="bg-white p-4 rounded shadow">
        <div class="grid grid-cols-2 gap-4 mb-4">
            <div>
                <label for="anime_id" class="block text-sm font-medium text-gray-700">ID Anime</label>
                <input type="text" name="anime_id" class="w-full p-2 border rounded" required value="<?php echo isset($animeId) ? $animeId : ''; ?>">
            </div>
        </div>

        <button type="submit" name="update_jadwal" class="bg-blue-500 text-white font-bold py-2 px-4 rounded">Update Jadwal</button>
    </form>
</div>
        <div id="manageEpisodeList" style="display: none;">
    <h2 class="text-2xl font-bold mb-4">Manage Episode</h2>
    <table id="episodeTable" class="min-w-full bg-white rounded shadow-md">
        <thead>
            <tr>
                <th class="px-4 py-2">Episode</th>
                <th class="px-4 py-2">URL</th>
                <th class="px-4 py-2">Resolusi</th>
                <th class="px-4 py-2">Action</th>
            </tr>
        </thead>
        <tbody id="episodeListTable">
            <!-- Episodes will be dynamically added here -->
        </tbody>
    </table>
</div>
    </div>

<script>
    document.addEventListener("DOMContentLoaded", function() {
    const episodeTable = $('#episodeTable').DataTable({
        // Konfigurasi DataTables
    });

    // Tambahkan event listener untuk tombol "Manage Episode"
    manageEpisodeButton.addEventListener("click", function () {
        addEpisodeButton.style.backgroundColor = "initial";
        manageEpisodeButton.style.backgroundColor = "#38a169";
        addEpisodeForm.style.display = "none";
        manageEpisodeList.style.display = "block";

        // Ganti animeId dengan nilai yang sesuai
        const animeId = document.querySelector('input[name="anime_id"]').value;

        // Fetch and display the list of episodes for the specific anime_id using AJAX
        fetch('get_episodes.php?anime_id=' + animeId)
            .then(response => response.json())
            .then(data => {
                // Hapus data sebelumnya
                episodeTable.clear().draw();

                // Tambahkan data episode ke DataTables
                data.forEach(episode => {
                    episodeTable.row.add([
                        episode.episode_number,
                        episode.video_url,
                        episode.resolusi,
                        `<button onclick="editEpisode(${episode.id})">Edit</button>
                        <button onclick="deleteEpisode(${episode.id})">Delete</button>`
                    ]).draw();
                });
            })
            .catch(error => {
                console.error('Error fetching episodes:', error);
            });
    });
});

// Function to handle episode deletion
function deleteEpisode(episodeId) {
    const confirmDeletion = confirm("Are you sure you want to delete this episode?");
    if (confirmDeletion) {
        // Kirim permintaan DELETE ke server untuk menghapus episode dengan episodeId yang diberikan
        fetch('delete_episode.php?episode_id=' + episodeId, {
            method: 'DELETE'
        })
        .then(response => {
            if (response.status === 200) {
                // Hapus baris episode dari tabel setelah berhasil menghapus dari server
                episodeTable.row($('#episodeTable tbody tr[data-id="' + episodeId + '"]').index()).remove().draw();
            } else {
                console.error('Error deleting episode:', response.statusText);
            }
        })
        .catch(error => {
            console.error('Error deleting episode:', error);
        });
    }
}

</script>

</body>
</html>

