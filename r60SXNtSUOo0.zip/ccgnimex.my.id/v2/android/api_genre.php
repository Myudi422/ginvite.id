<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

// Koneksi ke database
$servername = "localhost";
$username = "ccgnimex";
$password = "aaaaaaac";
$database = "ccgnimex";

$conn = new mysqli($servername, $username, $password, $database);

// Periksa koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Ambil genre dari parameter GET
$genre = $_GET['genre'];

// Query untuk mendapatkan data berdasarkan genre
$sql = "SELECT * FROM anilist_data WHERE genre LIKE '%$genre%'";
$result = $conn->query($sql);

// Cek apakah ada hasil
if ($result->num_rows > 0) {
    // Inisialisasi array untuk menyimpan data
    $animeList = array();

    // Ambil data dan masukkan ke dalam array
    while ($row = $result->fetch_assoc()) {
        $animeList[] = $row;
    }

    // Konversi array ke format JSON
    $jsonResponse = json_encode($animeList);

    // Set header untuk memberitahu bahwa respons adalah JSON
    header('Content-Type: application/json');

    // Tampilkan respons JSON
    echo $jsonResponse;
} else {
    // Jika tidak ada hasil, kirim respons kosong
    echo json_encode(array('message' => 'Tidak ada data yang ditemukan.'));
}

// Tutup koneksi ke database
$conn->close();
?>
