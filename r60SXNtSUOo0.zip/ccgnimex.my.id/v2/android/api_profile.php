<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

$server = 'localhost';
$username = 'ccgnimex';
$password = 'aaaaaaac';
$database = 'ccgnimex';

$conn = new mysqli($server, $username, $password, $database);

if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}

$email = $_POST['email'];

$sql = "SELECT * FROM users_web WHERE email='$email'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();

    // Assuming your database table has 'first_name', 'profile_pictures', and 'banner_picture' columns
    $response = [
        'status' => 'success',
        'first_name' => $row['first_name'],
        'profile_picture' => $row['profile_pictures'],
        'banner_picture' => $row['banner_picture'], // Add this line to include banner picture
    ];

    echo json_encode($response);
} else {
    echo json_encode(['status' => 'error', 'message' => 'User not found']);
}

$conn->close();
?>
