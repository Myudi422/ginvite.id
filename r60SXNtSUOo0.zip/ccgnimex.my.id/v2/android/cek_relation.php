<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

$servername = "localhost";
$username = "ccgnimex";
$password = "aaaaaaac";
$dbname = "ccgnimex";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$animeId = isset($_GET['anime_id']) ? $_GET['anime_id'] : null;

if (!$animeId) {
    $response = array('status' => 'error', 'message' => 'Parameter anime_id tidak diberikan.');
} else {
    $graphqlEndpoint = 'https://graphql.anilist.co';
    $graphqlQuery = <<<'GRAPHQL'
    query ($id: Int) {
        Media(id: $id, type: ANIME) {
            title {
                romaji
            }
            relations {
                edges {
                    relationType
                    node {
                        id
                        title {
                            romaji
                        }
                    }
                }
            }
        }
    }
GRAPHQL;

    $variables = ['id' => (int)$animeId];

    $ch = curl_init($graphqlEndpoint);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(['query' => $graphqlQuery, 'variables' => $variables]));
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);

    $anilistResponse = curl_exec($ch);

    if (curl_errno($ch)) {
        $response = array('status' => 'error', 'message' => 'Anilist API request failed: ' . curl_error($ch));
    } else {
        $anilistData = json_decode($anilistResponse, true);

        if (isset($anilistData['data']['Media'])) {
            $title = $anilistData['data']['Media']['title']['romaji'];
            $relations = $anilistData['data']['Media']['relations']['edges'];
            $prequel = null;
            $sequel = null;

            foreach ($relations as $relation) {
                $relationType = $relation['relationType'];
                $node = $relation['node'];
                $relationId = $node['id'];

                if ($relationType === 'PREQUEL') {
                    $sql = "SELECT anime_id FROM nonton WHERE anime_id = $relationId";
                    $result = $conn->query($sql);
                    $prequel = ($result->num_rows > 0) ? $relationId : null;
                } elseif ($relationType === 'SEQUEL') {
                    $sql = "SELECT anime_id FROM nonton WHERE anime_id = $relationId";
                    $result = $conn->query($sql);
                    $sequel = ($result->num_rows > 0) ? $relationId : null;
                }
            }

            $response = array(
                'status' => 'success',
                'anime_title' => $title,
                'relation' => array(
                    'prequel' => $prequel,
                    'sequel' => $sequel
                )
            );
        } else {
            $response = array('status' => 'error', 'message' => 'Data anime tidak ditemukan di AniList.');
        }
    }

    curl_close($ch);
}

$conn->close();

header('Content-Type: application/json');
echo json_encode($response);
?>
