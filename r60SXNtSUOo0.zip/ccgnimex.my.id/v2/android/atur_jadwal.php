<?php
// File: aturjadwal.php

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

header('Content-Type: application/json');

// Koneksi ke database
$koneksi = new mysqli("localhost", "ccgnimex", "aaaaaaac", "ccgnimex");

// Periksa koneksi
if ($koneksi->connect_error) {
    die(json_encode(['error' => 'Koneksi gagal: ' . $koneksi->connect_error]));
}

// Fungsi untuk mendapatkan semua jadwal dari database
function getJadwal($koneksi) {
    $sql = "SELECT * FROM jadwal ORDER BY FIELD(hari, 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu'), jam ASC";
    $result = $koneksi->query($sql);
    
    if ($result->num_rows > 0) {
        $jadwal = [];
        while ($row = $result->fetch_assoc()) {
            $jadwal[$row['hari']][] = [
                'anime_id' => $row['anime_id'],
                'waktu' => $row['jam']
            ];
        }
        return $jadwal;
    } else {
        return [];
    }
}

// Fungsi untuk memperbarui jadwal di database
function updateJadwal($koneksi, $jadwal) {
    // Ambil semua anime_id yang ada di jadwal lama
    $old_jadwal = [];
    $select_sql = "SELECT anime_id FROM jadwal";
    $result = $koneksi->query($select_sql);
    while ($row = $result->fetch_assoc()) {
        $old_jadwal[] = $row['anime_id'];
    }

    // Hapus semua jadwal lama
    $delete_sql = "DELETE FROM jadwal";
    $koneksi->query($delete_sql);

    // Masukkan data jadwal baru
    $insert_sql = "INSERT INTO jadwal (anime_id, hari, jam) VALUES (?, ?, ?)";
    $stmt = $koneksi->prepare($insert_sql);

    // Simpan daftar anime_id yang tetap ada di jadwal baru
    $new_anime_ids = [];

    foreach ($jadwal as $hari => $entries) {
        foreach ($entries as $entry) {
            $anime_id = $entry['anime_id'];
            $jam = $entry['waktu'];
            $stmt->bind_param("iss", $anime_id, $hari, $jam);
            $stmt->execute();
            $new_anime_ids[] = $anime_id; // Tambahkan ke daftar anime yang tetap ada
        }
    }

    // Tutup statement
    $stmt->close();

    // Cari anime yang dihapus dari jadwal
    $deleted_anime_ids = array_diff($old_jadwal, $new_anime_ids);

    if (!empty($deleted_anime_ids)) {
        // Update status menjadi FINISHED di tabel anilist_data jika status saat ini adalah RELEASING
        $update_status_sql = "UPDATE anilist_data SET status = 'FINISHED' WHERE anime_id = ? AND status = 'RELEASING'";
        $stmt_update = $koneksi->prepare($update_status_sql);

        foreach ($deleted_anime_ids as $anime_id) {
            $stmt_update->bind_param("i", $anime_id);
            $stmt_update->execute();
        }

        // Tutup statement update
        $stmt_update->close();
    }
}


// Mendapatkan metode HTTP
$method = $_SERVER['REQUEST_METHOD'];

// Mengelola jadwal berdasarkan metode
if ($method === 'GET') {
    // Jika GET, tampilkan jadwal dari database
    $jadwal = getJadwal($koneksi);
    echo json_encode(['jadwal' => $jadwal], JSON_PRETTY_PRINT);

} elseif ($method === 'POST') {
    // Jika POST, terima data baru untuk disimpan di database
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (isset($input['jadwal'])) {
        // Validasi apakah data 'jadwal' ada
        updateJadwal($koneksi, $input['jadwal']);
        echo json_encode(['message' => 'Jadwal berhasil diperbarui']);
    } else {
        echo json_encode(['error' => 'Data jadwal tidak valid']);
    }
} else {
    echo json_encode(['error' => 'Metode tidak didukung']);
}

// Menutup koneksi database
$koneksi->close();
?>
