<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

// Define your home URL
$home_url = "https://mangakita.id/";

// Initialize response array
$response = [];

// Buat koneksi ke database
$conn = new mysqli('127.0.0.1', 'ccgnimex', 'aaaaaaac', 'ccgnimex');
if ($conn->connect_error) {
    $response['error'] = 'Connection failed: ' . $conn->connect_error;
    echo json_encode($response);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // POST digunakan untuk operasi hapus

    // Pastikan parameter 'action' tersedia
    if (isset($_POST['action'])) {
        $action = $_POST['action'];

        // ---- HAPUS SEMUA RIWAYAT MANGA BERDASARKAN telegram_id ----
        if ($action === 'delete_all') {
            if (isset($_POST['telegram_id'])) {
                $telegram_id = $_POST['telegram_id'];
                $stmt = $conn->prepare("DELETE FROM manga_history WHERE telegram_id = ?");
                $stmt->bind_param("s", $telegram_id);
                if ($stmt->execute()) {
                    $response['message'] = "Semua riwayat manga untuk telegram_id $telegram_id telah dihapus.";
                } else {
                    $response['error'] = "Gagal menghapus riwayat manga: " . $stmt->error;
                }
                $stmt->close();
            } else {
                $response['error'] = "Parameter telegram_id tidak ditemukan.";
            }
        // ---- HAPUS ITEM TERTENTU (multi item) berdasarkan telegram_id dan manga_ids ----
        } elseif ($action === 'delete_item') {
            if (isset($_POST['telegram_id']) && isset($_POST['manga_ids'])) {
                $telegram_id = $_POST['telegram_id'];
                $manga_ids = $_POST['manga_ids'];

                // Jika manga_ids bukan array, asumsikan format string yang dipisahkan dengan koma
                if (!is_array($manga_ids)) {
                    $manga_ids = explode(",", $manga_ids);
                }

                // Buat placeholder dinamis untuk query
                $placeholders = implode(',', array_fill(0, count($manga_ids), '?'));
                $sql = "DELETE FROM manga_history WHERE telegram_id = ? AND id IN ($placeholders)";
                $stmt = $conn->prepare($sql);
                if ($stmt === false) {
                    $response['error'] = "Prepare failed: " . $conn->error;
                } else {
                    // Semua parameter: telegram_id (string) dan manga_ids (anggap string)
                    $types = 's' . str_repeat('s', count($manga_ids));
                    $params = array_merge([$telegram_id], $manga_ids);
                    $bind_names = [];
                    $bind_names[] = $types;
                    foreach ($params as $key => $value) {
                        $bind_names[] = &$params[$key];
                    }
                    call_user_func_array(array($stmt, 'bind_param'), $bind_names);

                    if ($stmt->execute()) {
                        $response['message'] = "Item manga tertentu telah dihapus untuk telegram_id $telegram_id.";
                    } else {
                        $response['error'] = "Gagal menghapus item manga: " . $stmt->error;
                    }
                    $stmt->close();
                }
            } else {
                $response['error'] = "Parameter telegram_id atau manga_ids tidak ditemukan.";
            }
        } else {
            $response['error'] = "Action tidak valid.";
        }
    } else {
        $response['error'] = "Parameter action tidak ditemukan.";
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // GET digunakan untuk mengambil riwayat baca manga

    // Cek parameter GET telegram_id dan page
    if (isset($_GET['telegram_id']) && isset($_GET['page'])) {
        $telegram_id = $_GET['telegram_id'];
        $page = $_GET['page'];
        $limit = 20;
        $offset = ($page - 1) * $limit;

        // Prepare SQL statement dengan LIMIT dan OFFSET untuk paginasi
        $sql = "SELECT mh.id, mh.image, mh.title, mh.episode_url, mh.title_eps, mh.telegram_id, mh.last_watched
                FROM manga_history mh
                WHERE mh.telegram_id = ?
                ORDER BY mh.last_watched DESC
                LIMIT ? OFFSET ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sii", $telegram_id, $limit, $offset);
        $stmt->execute();

        // Dapatkan hasil query
        $result = $stmt->get_result();

        // Cek apakah terdapat data
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                // Tambahkan atribut home_url ke dalam data
                $row['home_url'] = $home_url . 'komik/' . generateEpisodeUrl($row['title']);
                $response['mangaHistory'][] = $row;
            }
        } else {
            $response['message'] = 'No manga found for the specified telegram_id and page';
        }

        $stmt->close();
    } else {
        $response['error'] = 'Telegram ID or page not provided in the URL';
    }
} else {
    $response['error'] = 'Invalid request method';
}

$conn->close();
echo json_encode($response);

// Function untuk generate URL episode berdasarkan title
function generateEpisodeUrl($title) {
    $formattedTitle = strtolower(preg_replace('/[^A-Za-z0-9\- ]/', '', $title));
    $formattedTitle = str_replace(" ", "-", $formattedTitle);
    // Menghilangkan "komik" dari awal URL (jika ada)
    $formattedTitle = str_replace("komik-", "", $formattedTitle);
    return $formattedTitle;
}
?>
