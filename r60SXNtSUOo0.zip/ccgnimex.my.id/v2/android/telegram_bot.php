<?php
// Koneksi ke database
$servername = "localhost";
$username = "ccgnimex";
$password = "aaaaaaac";
$dbname = "ccgnimex";

$conn = new mysqli($servername, $username, $password, $dbname);

// Periksa koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Ambil data dari webhook Telegram
$content = file_get_contents("php://input");
$update = json_decode($content, true);

if (!$update) {
    exit;
}

if (isset($update['callback_query'])) {
    $callbackQuery = $update['callback_query'];
    $callbackData = $callbackQuery['data'];
    $callbackId = $callbackQuery['id'];
    $chatId = $callbackQuery['message']['chat']['id'];
    $messageId = $callbackQuery['message']['message_id'];

    // Fungsi untuk mengupdate data pengguna
    function updateUserSubscription($conn, $telegramId, $expiredDate) {
        // Siapkan statement SQL untuk mengupdate data pengguna
        $stmt = $conn->prepare("UPDATE users_web SET akses = 'Premium', expired = ? WHERE telegram_id = ?");
        $stmt->bind_param("ss", $expiredDate, $telegramId);

        if ($stmt->execute()) {
            return true;
        } else {
            return false;
        }
    }

    if (strpos($callbackData, 'accept_') === 0) {
        $telegramId = str_replace('accept_', '', $callbackData);
        // Retrieve the new expiration date for this user
        $stmt = $conn->prepare("SELECT expired FROM users_web WHERE telegram_id = ?");
        $stmt->bind_param("s", $telegramId);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        $newExpired = $row['expired'];

        if (updateUserSubscription($conn, $telegramId, $newExpired)) {
            $reply = "Langganan untuk $telegramId telah diterima dan diperbarui.";
        } else {
            $reply = "Gagal memperbarui langganan untuk $telegramId.";
        }
    } elseif (strpos($callbackData, 'reject_') === 0) {
        $telegramId = str_replace('reject_', '', $callbackData);
        $reply = "Langganan untuk $telegramId ditolak.";
    } else {
        $reply = "Perintah tidak dikenali.";
    }

    // Kirim balasan ke Telegram
    $botToken = "5239057973:AAEFjxIVnXmeEnjqaaObmLTkMQMRKTW5OWs";
    $url = "https://api.telegram.org/bot$botToken/answerCallbackQuery?" . http_build_query([
        'callback_query_id' => $callbackId,
        'text' => $reply
    ]);
    file_get_contents($url);

    // Kirim balasan update pesan
    $editUrl = "https://api.telegram.org/bot$botToken/editMessageText?" . http_build_query([
        'chat_id' => $chatId,
        'message_id' => $messageId,
        'text' => $reply
    ]);
    file_get_contents($editUrl);
}

$conn->close();
?>
