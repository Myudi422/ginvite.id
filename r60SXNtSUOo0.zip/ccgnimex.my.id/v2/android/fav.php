<?php

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

// Database connection
$servername = "localhost";
$username = "ccgnimex";
$password = "aaaaaaac";
$database = "ccgnimex";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve data from POST request
$animeId = $_POST['animeId'];
$telegramId = $_POST['telegramId'];
$action = $_POST['action']; // 'add' for adding to favorites, 'remove' for removing from favorites

if ($action == 'add') {
    // Check if the anime is already in favorites
    $sqlCheck = "SELECT * FROM fav_anime WHERE anime_id = $animeId AND telegram_id = '$telegramId'";
    $resultCheck = $conn->query($sqlCheck);

    if ($resultCheck->num_rows > 0) {
        // Anime already in favorites
        echo "Anime already in favorites";
    } else {
        // Add anime to favorites
        $sqlAdd = "INSERT INTO fav_anime (anime_id, telegram_id) VALUES ($animeId, '$telegramId')";
        if ($conn->query($sqlAdd) === TRUE) {
            echo "Anime added to favorites successfully";
        } else {
            echo "Error: " . $sqlAdd . "<br>" . $conn->error;
        }
    }
} elseif ($action == 'remove') {
    // Remove anime from favorites
    $sqlRemove = "DELETE FROM fav_anime WHERE anime_id = $animeId AND telegram_id = '$telegramId'";
    if ($conn->query($sqlRemove) === TRUE) {
        echo "Anime removed from favorites successfully";
    } else {
        echo "Error: " . $sqlRemove . "<br>" . $conn->error;
    }
} else {
    echo "Invalid action";
}

$conn->close();

?>
