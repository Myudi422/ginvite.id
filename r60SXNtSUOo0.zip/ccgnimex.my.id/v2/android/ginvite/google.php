
<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

// 2) Response JSON
header('Content-Type: application/json');

// 3) Bootstrapping: DB & JWT
require 'db.php';
require '../../../vendor/autoload.php'; // Pastikan autoload composer tersedia
use Firebase\JWT\JWT;

// 4) Ambil id_token dari body JSON
$body    = json_decode(file_get_contents('php://input'), true);
$idToken = $body['id_token'] ?? null;
if (!$idToken) {
    http_response_code(400);
    exit(json_encode(['status'=>'error','message'=>'id_token diperlukan']));
}

// 5) Decode payload tanpa verifikasi signature
$parts = explode('.', $idToken);
if (count($parts) < 2) {
    http_response_code(400);
    exit(json_encode(['status'=>'error','message'=>'id_token tidak valid']));
}
$payload = json_decode(base64_decode(strtr($parts[1], '-_', '+/')), true);
if (!$payload || !isset($payload['email'])) {
    http_response_code(400);
    exit(json_encode(['status'=>'error','message'=>'Payload token tidak lengkap']));
}

// 6) Ekstrak data user
$email      = $payload['email'];
$firstName  = $payload['given_name'] ?? $payload['name'] ?? '';
$pictureUrl = $payload['picture'] ?? '';
$now        = date('Y-m-d H:i:s');
$expired    = date('Y-m-d H:i:s', strtotime('+30 days'));

// Default values utk new user
$typeUser = 1;
$themeId  = 1;

// 7) Upsert ke tabel `users`
$stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
$stmt->execute([$email]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if ($user) {
    // Update last_login, expired, first_name, pictures_url
    $sql = "
      UPDATE users
      SET first_name   = :firstName,
          pictures_url = :pictureUrl,
          last_login   = :now,
          expired      = :expired
      WHERE id = :id
    ";
    $upd = $pdo->prepare($sql);
    $upd->execute([
        ':firstName'  => $firstName,
        ':pictureUrl' => $pictureUrl,
        ':now'        => $now,
        ':expired'    => $expired,
        ':id'         => $user['id']
    ]);
    $userId = (int)$user['id'];
} else {
    // Insert user baru
    $sql = "
      INSERT INTO users
        (first_name, email, pictures_url, last_login, expired, type_user, theme_id)
      VALUES
        (:firstName, :email, :pictureUrl, :now, :expired, :typeUser, :themeId)
    ";
    $ins = $pdo->prepare($sql);
    $ins->execute([
        ':firstName'  => $firstName,
        ':email'      => $email,
        ':pictureUrl' => $pictureUrl,
        ':now'        => $now,
        ':expired'    => $expired,
        ':typeUser'   => $typeUser,
        ':themeId'    => $themeId
    ]);
    $userId = (int)$pdo->lastInsertId();
}

// 8) Generate JWT aplikasi
$secretKey = 'very-secret-key';  // ganti dengan secret yang aman
$issuedAt  = time();
$expireTs  = $issuedAt + 86400;      // 1 hari

$tokenPayload = [
    'iss'  => 'https://yourdomain.com',
    'iat'  => $issuedAt,
    'nbf'  => $issuedAt,
    'exp'  => $expireTs,
    'data' => [
        'userId' => $userId,
        'email'  => $email
    ]
];
$appJwt = JWT::encode($tokenPayload, $secretKey, 'HS256');

// 9) Set cookie HttpOnly & Secure
setcookie('token', $appJwt, [
    'expires'  => $expireTs,
    'path'     => '/',
    'secure'   => true,
    'httponly' => true,
    'samesite' => 'Lax'
]);

// 10) Kirim response
echo json_encode([
    'status' => 'success',
    'token'  => $appJwt
]);
exit;

