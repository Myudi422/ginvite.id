<?php
// page/get_invitations.php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

require __DIR__ . '/../db.php';  // pastikan db.php mendefinisikan $pdo

// 1) Ambil & validasi user_id
$user_id = isset($_GET['user_id']) && is_numeric($_GET['user_id'])
    ? (int) $_GET['user_id']
    : 0;

if ($user_id <= 0) {
    http_response_code(400);
    echo json_encode([
        'status'  => 'error',
        'message' => 'Parameter user_id tidak valid',
    ], JSON_UNESCAPED_SLASHES);
    exit;
}

// 2) Query undangan
$sql = <<<SQL
SELECT
  c.id,
  c.title,
  c.status,
  c.waktu_acara AS event_date,
  t.image_theme AS avatar_url
FROM content_user AS c
JOIN theme AS t
  ON c.category_id = t.id
WHERE c.user_id = ?
ORDER BY c.waktu_acara DESC
SQL;

$stmt = $pdo->prepare($sql);
$stmt->execute([$user_id]);
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

// 3) Jika tidak ada undangan, kirim 404
if (empty($rows)) {
    http_response_code(404);
    echo json_encode([
        'status'  => 'error',
        'message' => 'Tidak ada undangan untuk user_id ' . $user_id,
    ], JSON_UNESCAPED_SLASHES);
    exit;
}

// 4) Response sukses
echo json_encode([
    'status' => 'success',
    'data'   => $rows,
], JSON_UNESCAPED_SLASHES);
