<?php
// page/result.php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
require __DIR__ . '/../db.php';

// 1) Ambil parameter dari Query-String
$userId   = isset($_GET['user']) && is_numeric($_GET['user']) ? (int)$_GET['user'] : null;
$themeId  = isset($_GET['theme']) && is_numeric($_GET['theme']) ? (int)$_GET['theme'] : null;
$title    = isset($_GET['title']) && is_string($_GET['title']) && $_GET['title'] !== '' 
            ? trim($_GET['title']) 
            : null;

if (!$userId || !$themeId || !$title) {
    http_response_code(400);
    exit(json_encode([
        'status'  => 'error',
        'message' => 'Parameter user, theme, dan title wajib',
    ]));
}

// 2) Load user & cek expired
$stmt = $pdo->prepare("SELECT id, first_name, pictures_url 
                       FROM users 
                       WHERE id = ? AND expired > NOW()");
$stmt->execute([$userId]);
$user = $stmt->fetch();
if (!$user) {
    http_response_code(404);
    exit(json_encode([
        'status'  => 'error',
        'message' => 'User tidak ditemukan atau sudah expired',
    ]));
}

// 3) Load content_user berdasarkan title & user_id
$stmt = $pdo->prepare("SELECT content, category_id 
                       FROM content_user 
                       WHERE title = ? AND user_id = ? AND status = 1 
                       LIMIT 1");
$stmt->execute([$title, $userId]);
$cu = $stmt->fetch();
if (!$cu) {
    http_response_code(404);
    exit(json_encode([
        'status'  => 'error',
        'message' => 'Undangan tidak ditemukan untuk user ini',
    ]));
}

$userContent = json_decode($cu['content'], true);
$categoryId  = (int)$cu['category_id'];

// 4) Load template berdasarkan category_id
$stmt = $pdo->prepare("SELECT content_template 
                       FROM category_type 
                       WHERE id = ?");
$stmt->execute([$categoryId]);
$templateJson = $stmt->fetchColumn();
if (!$templateJson) {
    http_response_code(404);
    exit(json_encode([
        'status'  => 'error',
        'message' => "Kategori ID={$categoryId} tidak ditemukan",
    ]));
}
$template = json_decode($templateJson, true);

// 5) Merge template + override
$content = array_merge($template, $userContent);
if (!isset($content['our_story'])) {
    $content['our_story'] = [];
}

// 6) Load theme
$stmt = $pdo->prepare("SELECT * FROM theme WHERE id = ?");
$stmt->execute([$themeId]);
$theme = $stmt->fetch();
if (!$theme) {
    http_response_code(404);
    exit(json_encode([
        'status'  => 'error',
        'message' => "Theme ID={$themeId} tidak ditemukan",
    ]));
}

// 7) Build and send JSON
$result = [
    'user'        => [
        'id'           => $user['id'],
        'first_name'   => $user['first_name'],
        'pictures_url' => $user['pictures_url'],
    ],
    'theme'       => [
        'textColor'       => $theme['text_color'],
        'accentColor'     => $theme['accent_color'],
        'defaultBgImage'  => $theme['default_bg_image'],
        'defaultBgImage1' => $theme['default_bg_image1'],
    ],
    'decorations' => [
        'topLeft'     => $theme['decorations_top_left'],
        'topRight'    => $theme['decorations_top_right'],
        'bottomLeft'  => $theme['decorations_bottom_left'],
        'bottomRight' => $theme['decorations_bottom_right'],
    ],
    'content'     => $content,
];

echo json_encode($result, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
