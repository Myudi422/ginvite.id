<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");
header('Content-Type: application/json');

$servername = "localhost";
$username = "ccgnimex";
$password = "aaaaaaac";
$dbname = "ccgnimex";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve and sanitize GET data
$anime_id = isset($_GET['anime_id']) ? intval($_GET['anime_id']) : 0;
$episode_id = isset($_GET['episode_id']) ? intval($_GET['episode_id']) : 0;

if ($anime_id == 0 || $episode_id == 0) {
    die(json_encode(["error" => "Invalid parameters."]));
}

// Prepared statement to prevent SQL Injection
$stmt = $conn->prepare("SELECT users_web.telegram_id, users_web.first_name, users_web.id_web, users_web.akses, users_web.profile_picture, comments_app.comment, CONVERT_TZ(comments_app.date_posting, 'SYSTEM', '+00:00') as date_posting, comments_app.id
                        FROM comments_app 
                        JOIN users_web ON comments_app.telegram_id = users_web.telegram_id 
                        WHERE comments_app.anime_id = ? AND comments_app.episode_id = ?");
$stmt->bind_param("ii", $anime_id, $episode_id);

$stmt->execute();
$result = $stmt->get_result();

$comments = array();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $comments[] = $row;
    }
} else {
    echo json_encode(["message" => "No comments found."]);
    exit();
}

echo json_encode($comments);

$stmt->close();
$conn->close();
?>
