<?php
// URL video
$videoUrl = "https://storages.sokuja.id/2024-fall/amgami-emusubi/SOKUJA.ID-AMGCM-1.480p.mp4";

// Fungsi untuk bypass akses menggunakan cURL
function fetchVideo($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); // Ikuti redirect jika ada

    // Tambahkan header kustom jika diperlukan
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36",
        "Referer: https://storages.sokuja.id",
        "Accept: */*",
    ]);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    // Jika berhasil, kembalikan data video
    if ($httpCode == 200) {
        return $response;
    } else {
        return false; // Jika gagal, kembalikan false
    }
}

// Jika ada request untuk video, sajikan konten video
if (isset($_GET['video']) && $_GET['video'] == 'true') {
    $videoData = fetchVideo($videoUrl);

    if ($videoData) {
        header("Content-Type: video/mp4");
        echo $videoData;
    } else {
        http_response_code(403);
        echo "Error: Unable to fetch video.";
    }
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Video Streaming</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            height: 100vh;
            margin: 0;
            background-color: #f4f4f4;
        }
        video {
            width: 80%;
            height: auto;
            border: 1px solid #ccc;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
    </style>
</head>
<body>
    <h1>Streaming Video</h1>
    <video controls>
        <source src="?video=true" type="video/mp4">
        Browser Anda tidak mendukung pemutar video.
    </video>
</body>
</html>
