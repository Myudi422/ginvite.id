<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

// Ambil data dari Flutter
$telegramId = isset($_POST['telegram_id']) ? $_POST['telegram_id'] : '';
$playlistName = isset($_POST['playlist_name']) ? $_POST['playlist_name'] : '';

// Logging
error_log("Received Telegram ID for deletion: " . $telegramId);

// Lakukan validasi data
if (empty($telegramId) || empty($playlistName)) {
    $response = array('success' => false, 'message' => 'Invalid data provided');
    echo json_encode($response);
    exit();
}

// Logging
error_log("Data validation passed. Continuing with database operation.");

// Koneksi ke database (ganti dengan informasi koneksi database Anda)
$mysqli = new mysqli("localhost", "ccgnimex", "aaaaaaac", "ccgnimex");

// Periksa koneksi database
if ($mysqli->connect_error) {
    die('Error: ' . $mysqli->connect_errno . ': ' . $mysqli->connect_error);
}

// Hapus playlist tertentu berdasarkan telegram_id dan playlist_name
$query = "DELETE FROM playlists WHERE telegram_id = ? AND playlist_name = ?";
$stmt = $mysqli->prepare($query);
$stmt->bind_param("ss", $telegramId, $playlistName);

// Eksekusi query
if ($stmt->execute()) {
    $response = array('success' => true, 'message' => 'Playlist deleted successfully.');
    // Logging
    error_log("Playlist deleted successfully.");
} else {
    $response = array('success' => false, 'message' => 'Error deleting playlist');
    // Logging
    error_log("Error deleting playlist. MySQL error: " . $stmt->error);
}

// Tutup statement dan koneksi database
$stmt->close();
$mysqli->close();

// Keluarkan hasil dalam format JSON
echo json_encode($response);
?>
