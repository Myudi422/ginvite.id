<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

// Ambil data dari Flutter
$telegramId = isset($_POST['telegram_id']) ? $_POST['telegram_id'] : '';
$playlistName = isset($_POST['playlist_name']) ? $_POST['playlist_name'] : '';
$videoLink = isset($_POST['video_link']) ? $_POST['video_link'] : '';

// Logging
error_log("Received Telegram ID: " . $telegramId);
error_log("Received Playlist Name: " . $playlistName);
error_log("Received Video Link: " . $videoLink);

// Lakukan validasi data
if (empty($telegramId) || empty($playlistName) || empty($videoLink)) {
    $response = array('success' => false, 'message' => 'Invalid data provided');
    echo json_encode($response);
    exit();
}

// Logging
error_log("Data validation passed. Continuing with database operation.");

// Simpan ke database
$mysqli = new mysqli("localhost", "ccgnimex", "aaaaaaac", "ccgnimex");

// Check connection
if ($mysqli->connect_error) {
    $response = array('success' => false, 'message' => 'Database connection error');
    echo json_encode($response);
    exit();
}

// Check if the video link already exists in the playlist
$stmtCheck = $mysqli->prepare("SELECT * FROM playlists WHERE telegram_id = ? AND playlist_name = ? AND video_link = ?");
$stmtCheck->bind_param("sss", $telegramId, $playlistName, $videoLink);
$stmtCheck->execute();
$stmtCheck->store_result();

if ($stmtCheck->num_rows > 0) {
    // Video link already exists in the playlist
    $response = array('success' => false, 'message' => 'Video already exists in the playlist');
    echo json_encode($response);
    exit();
}

$stmtCheck->close();

// Prepare and bind
$stmt = $mysqli->prepare("INSERT INTO playlists (telegram_id, playlist_name, video_link) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $telegramId, $playlistName, $videoLink);

// Execute the query
if ($stmt->execute()) {
    $response = array('success' => true, 'message' => 'Video added to playlist successfully');
    // Logging
    error_log("Video added to playlist successfully.");
} else {
    $response = array('success' => false, 'message' => 'Error adding video to playlist');
    // Logging
    error_log("Error adding video to playlist. MySQL error: " . $stmt->error);
}

// Close statement and connection
$stmt->close();
$mysqli->close();

echo json_encode($response);
?>
