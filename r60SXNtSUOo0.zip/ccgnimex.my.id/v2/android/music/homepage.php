<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

header('Content-Type: application/json');

// Database credentials
$host = 'localhost';
$dbname = 'ccgnimex';
$username = 'ccgnimex'; // change if necessary
$password = 'aaaaaaac'; // change if necessary

try {
    // Create a new PDO instance
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Fetch a random playlist ID
    $stmt = $pdo->query("SELECT playlist_id FROM playlists_home ORDER BY RAND() LIMIT 1");
    $playlist = $stmt->fetch(PDO::FETCH_ASSOC);

    // Return the playlist ID as a JSON response
    echo json_encode(['playlistId' => $playlist['playlist_id']]);
} catch (PDOException $e) {
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>
