<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

// Ambil data dari Flutter (via POST)
$telegramId = isset($_POST['telegram_id']) ? $_POST['telegram_id'] : '';
$playlistName = isset($_POST['playlist_name']) ? $_POST['playlist_name'] : '';
$videoLink = isset($_POST['video_link']) ? $_POST['video_link'] : '';

// Validasi data
if (empty($telegramId) || empty($playlistName) || empty($videoLink)) {
    echo json_encode(['success' => false, 'message' => 'Data tidak lengkap']);
    exit();
}

// Koneksi ke database
$mysqli = new mysqli("localhost", "ccgnimex", "aaaaaaac", "ccgnimex");
if ($mysqli->connect_error) {
    die('Error: ' . $mysqli->connect_error);
}

// Query hapus video dari playlist
$query = "DELETE FROM playlists WHERE telegram_id = ? AND playlist_name = ? AND video_link = ?";
$stmt = $mysqli->prepare($query);
$stmt->bind_param("sss", $telegramId, $playlistName, $videoLink);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Video berhasil dihapus dari playlist']);
} else {
    echo json_encode(['success' => false, 'message' => 'Gagal menghapus video dari playlist']);
}

$stmt->close();
$mysqli->close();
?>
