<?php
header("Access-Control-Allow-Origin: *");
// Set timezone to Jakarta
date_default_timezone_set('Asia/Jakarta');

// Database connection parameters
$servername = "localhost";
$username = "ccgnimex";
$password = "aaaaaaac";
$database = "ccgnimex";

// Establishing the connection
$conn = new mysqli($servername, $username, $password, $database);

// Checking the connection
if ($conn->connect_error) {
    die(json_encode(['status' => 'error', 'message' => 'Connection failed: ' . $conn->connect_error]));
}

// Retrieve telegram_id from the GET parameter
$telegram_id = $_GET['telegram_id'];

// Function to convert 'HH:MM:SS' format to seconds
function waktuKeDetik($waktu) {
    if (preg_match('/^\d{2}:\d{2}:\d{2}$/', $waktu)) {
        list($jam, $menit, $detik) = explode(':', $waktu);
        return $jam * 3600 + $menit * 60 + $detik;
    }
    return 0;
}

// Get the email associated with the telegram_id
$email_stmt = $conn->prepare("SELECT email FROM users_web WHERE telegram_id = ?");
if (!$email_stmt) {
    die(json_encode(['status' => 'error', 'message' => 'Prepare failed: ' . $conn->error]));
}
$email_stmt->bind_param('s', $telegram_id);
$email_stmt->execute();
$email_result = $email_stmt->get_result();

if ($email_result->num_rows > 0) {
    $email_row = $email_result->fetch_assoc();
    $email = $email_row['email'];
    
    // Check if the email is banned
    $banned_stmt = $conn->prepare("SELECT 1 FROM user_banned WHERE email = ?");
    if (!$banned_stmt) {
        die(json_encode(['status' => 'error', 'message' => 'Prepare failed: ' . $conn->error]));
    }
    $banned_stmt->bind_param('s', $email);
    $banned_stmt->execute();
    $banned_result = $banned_stmt->get_result();

    if ($banned_result->num_rows > 0) {
        echo json_encode(['status' => 'banned', 'message' => 'Access denied. Your account is restricted.']);
        $conn->close();
        exit();
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Telegram ID not found']);
    $conn->close();
    exit();
}

// Retrieve all users' watch time for ranking
$sql_all = "SELECT telegram_id, ditonton FROM users_web";
$result_all = $conn->query($sql_all);
$all_data = array();

if ($result_all) {
    while ($row_all = $result_all->fetch_assoc()) {
        $row_all['ditonton_dalam_detik'] = waktuKeDetik($row_all['ditonton']);
        $all_data[] = $row_all;
    }
    
    usort($all_data, function($a, $b) {
        return $b['ditonton_dalam_detik'] - $a['ditonton_dalam_detik'];
    });
    
    $peringkat = null;
    foreach ($all_data as $key => $user) {
        if ($user['telegram_id'] == $telegram_id) {
            $peringkat = $key + 1;
            break;
        }
    }
}

// Query for user details based on telegram_id
$sql = "SELECT akses, expired, profile_picture, first_name, ditonton FROM users_web WHERE telegram_id = ?";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    die(json_encode(['status' => 'error', 'message' => 'Prepare failed: ' . $conn->error]));
}
$stmt->bind_param('s', $telegram_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $akses = $row['akses'];
    $expired = $row['expired'];
    $profile_picture = $row['profile_picture'];
    $first_name = $row['first_name'];
    $ditonton = $row['ditonton'];

    if (is_null($expired) || strtotime($expired) < time()) {
        $akses = "Free";
    }

    $response = [
        "status" => "success",
        "akses" => $akses,
        "profile_picture" => $profile_picture,
        "first_name" => $first_name,
        "ditonton" => $ditonton,
        "peringkat" => $peringkat ?? "Not available"
    ];
} else {
    $response = [
        "status" => "error",
        "message" => "Telegram ID not found"
    ];
}

$conn->close();
echo json_encode($response);
?>
