<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

$server = 'localhost';
$username = 'ccgnimex';
$password = 'aaaaaaac';
$database = 'ccgnimex';

$conn = new mysqli($server, $username, $password, $database);

if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}

$email = $_POST['email'];

// Use prepared statements to prevent SQL injection
$stmt = $conn->prepare("SELECT * FROM users_web WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();

    $firstName = $row['first_name'];
    $telegram_id = $row['telegram_id'];
    $akses = $row['akses'] ?? 'Free'; // Set default value to 'Free' if null
    $profile_picture = $row['profile_picture'];

    echo json_encode([
        'status' => 'success',
        'message' => 'Login successful',
        'first_name' => $firstName,
        'telegram_id' => $telegram_id,
        'akses' => $akses,
        'profile_picture' => $profile_picture
    ]);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid email']);
}

// Close the statement and connection
$stmt->close();
$conn->close();
?>
