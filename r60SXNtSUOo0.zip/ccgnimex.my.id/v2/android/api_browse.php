<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

// Koneksi ke database, sesuaikan dengan informasi database Anda
$host = "localhost";
$username = "ccgnimex";
$password = "aaaaaaac";
$database = "ccgnimex";

$koneksi = mysqli_connect($host, $username, $password, $database);

// Periksa koneksi
if (!$koneksi) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

// Set header Content-Type menjadi application/json
header('Content-Type: application/json');

function fetchAndFilterArray($queryColumn, $columnName) {
    global $koneksi;

    $query = "SELECT $queryColumn FROM anilist_data";
    $result = mysqli_query($koneksi, $query);

    if (!$result) {
        die("Query error: " . mysqli_error($koneksi));
    }

    $data = array();

    while ($row = mysqli_fetch_assoc($result)) {
        $dataArray = explode(", ", $row[$queryColumn]);
        $dataArray = array_filter($dataArray, function($value) {
            return $value !== "";
        });

        $data = array_merge($data, $dataArray);
    }

    $uniqueData = array_values(array_unique($data));

    echo json_encode($uniqueData);
}

// Check if the 'tags', 'genres', 'studios', 'season', 'format', or 'status' parameter is present in the URL
if (isset($_GET['tags'])) {
    fetchAndFilterArray('tags', 'Tags');
} else if (isset($_GET['genres'])) {
    fetchAndFilterArray('genre', 'Genres');
} else if (isset($_GET['studios'])) {
    fetchAndFilterArray('studios', 'Studios');
} else if (isset($_GET['season'])) {
    fetchAndFilterArray('season', 'Seasons');
} else if (isset($_GET['format'])) {
    fetchAndFilterArray('format', 'Formats');
} else if (isset($_GET['status'])) {
    fetchAndFilterArray('status', 'Statuses');
} else {
    // If none of the parameters are present, fetch and display all data
    $query = "SELECT * FROM anilist_data ORDER BY id DESC";

    $result = mysqli_query($koneksi, $query);

    if (!$result) {
        die("Query error: " . mysqli_error($koneksi));
    }

    $data = array();

    while ($row = mysqli_fetch_assoc($result)) {
        $data[] = $row;
    }

    echo json_encode($data);
}

// Tutup koneksi database
mysqli_close($koneksi);
?>
