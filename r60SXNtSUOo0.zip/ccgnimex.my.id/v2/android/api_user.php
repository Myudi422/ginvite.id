<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");

$server = 'localhost';
$username = 'ccgnimex';
$password = 'aaaaaaac';
$database = 'ccgnimex';

$conn = new mysqli($server, $username, $password, $database);

if ($conn->connect_error) {
    die(json_encode(['status' => 'error', 'message' => 'Connection failed: ' . $conn->connect_error]));
}

$email = isset($_POST['email']) ? $_POST['email'] : (isset($_GET['email']) ? $_GET['email'] : null);
$telegram_id = isset($_POST['telegram_id']) ? $_POST['telegram_id'] : (isset($_GET['telegram_id']) ? $_GET['telegram_id'] : null);

if (empty($email) && empty($telegram_id)) {
    echo json_encode(['status' => 'error', 'message' => 'Missing email or telegram_id parameter']);
    $conn->close();
    exit();
}

// Debug: Log received parameters
error_log("Email received: $email");
error_log("Telegram ID received: $telegram_id");

// Check if the email or the email associated with the telegram_id is banned
if ($email) {
    $stmt = $conn->prepare("SELECT * FROM user_banned WHERE email = ?");
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $result_banned = $stmt->get_result();
    
    if ($result_banned->num_rows > 0) {
        echo json_encode(['status' => 'banned', 'message' => 'You are banned, please be aware.']);
        $stmt->close();
        $conn->close();
        exit();
    }
    $stmt->close();
} elseif ($telegram_id) {
    // Check if the telegram_id has an associated banned email
    $stmt = $conn->prepare("SELECT email FROM users_web WHERE telegram_id = ?");
    $stmt->bind_param('s', $telegram_id);
    $stmt->execute();
    $result_user = $stmt->get_result();

    if ($result_user->num_rows > 0) {
        $row = $result_user->fetch_assoc();
        $user_email = $row['email'];

        // Check if this associated email is in the banned list
        $banned_stmt = $conn->prepare("SELECT * FROM user_banned WHERE email = ?");
        $banned_stmt->bind_param('s', $user_email);
        $banned_stmt->execute();
        $result_banned = $banned_stmt->get_result();

        if ($result_banned->num_rows > 0) {
            echo json_encode(['status' => 'banned', 'message' => 'You are banned, please be aware.']);
            $banned_stmt->close();
            $stmt->close();
            $conn->close();
            exit();
        }
        $banned_stmt->close();
    }
    $stmt->close();
}

// Proceed to fetch user data if not banned
if ($email) {
    $stmt = $conn->prepare("SELECT * FROM users_web WHERE email = ?");
    $stmt->bind_param('s', $email);
} else {
    $stmt = $conn->prepare("SELECT * FROM users_web WHERE telegram_id = ?");
    $stmt->bind_param('s', $telegram_id);
}

$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $response = ['status' => 'success'];

    // Add relevant fields to the response
    $response['email'] = $row['email'] ?? null;
    $response['first_name'] = $row['first_name'] ?? null;
    $response['profile_picture'] = $row['profile_picture'] ?? null;
    $response['telegram_id'] = $row['telegram_id'] ?? null;
    $response['akses'] = $row['akses'] ?? null;
    $response['expired'] = $row['expired'] ?? null;

    // Check if the expired date has passed
    if (!empty($row['expired']) && strtotime($row['expired']) < time()) {
        $update_stmt = $conn->prepare("UPDATE users_web SET akses = 'Free', expired = NULL WHERE telegram_id = ?");
        $update_stmt->bind_param('s', $telegram_id);
        
        if ($update_stmt->execute() && $update_stmt->affected_rows > 0) {
            $response['akses'] = 'Free';
            $response['expired'] = null;
        }
        $update_stmt->close();
    }

   // Fetch addresses for the user
$address_stmt = $conn->prepare("SELECT * FROM addresses WHERE telegram_id = ?");
$address_stmt->bind_param('s', $telegram_id); // Use 'i' if telegram_id is an integer
$address_stmt->execute();
$address_result = $address_stmt->get_result();

$addresses = [];
while ($address_row = $address_result->fetch_assoc()) {
    $addresses[] = [
        'address_id' => $address_row['address_id'],
        'alamat_rumah' => $address_row['alamat_rumah'],
        'desa_kelurahan' => $address_row['desa_kelurahan'],
        'kecamatan' => $address_row['kecamatan'],
        'kabupaten_kota' => $address_row['kabupaten_kota'],
        'provinsi' => $address_row['provinsi'],
        'kode_pos' => $address_row['kode_pos']
    ];
}
$response['addresses'] = $addresses;

    // Debug: Log addresses fetched
    error_log("Fetched " . count($addresses) . " addresses for Telegram ID: $telegram_id");

    echo json_encode($response);
} else {
    echo json_encode(['status' => 'error', 'message' => 'User not found']);
}

$stmt->close();
$conn->close();
?>