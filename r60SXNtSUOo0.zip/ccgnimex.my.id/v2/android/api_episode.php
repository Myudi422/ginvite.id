<?php

header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: *");

// URL API Python
$pythonApiBaseUrl = "https://ongoing.ccgnimex.my.id/episode";

// Fungsi untuk memanggil API Python
function callPythonApi($method, $url, $data = null) {
    $ch = curl_init();
    $options = [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_CUSTOMREQUEST  => $method,
        CURLOPT_URL            => $url,
    ];
    
    if ($method === 'POST' && $data) {
        $options[CURLOPT_POSTFIELDS] = http_build_query($data);
        $options[CURLOPT_HTTPHEADER] = [
            'Content-Type: application/x-www-form-urlencoded'
        ];
    }
    
    curl_setopt_array($ch, $options);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    
    if (curl_errno($ch)) {
        $error = curl_error($ch);
        curl_close($ch);
        return [
            'error' => true,
            'message' => "cURL Error: $error",
            'http_code' => $httpCode
        ];
    }
    
    curl_close($ch);
    return [
        'error' => false,
        'response' => $response,
        'http_code' => $httpCode
    ];
}

// Mendapatkan metode HTTP
$method = $_SERVER['REQUEST_METHOD'];

// Menggabungkan URL API Python
$endpoint = isset($_GET['endpoint']) ? $_GET['endpoint'] : '';
$apiUrl = rtrim($pythonApiBaseUrl, '/') . '/' . ltrim($endpoint, '/');

// Proses permintaan
if ($method === 'GET') {
    $queryString = $_SERVER['QUERY_STRING'];
    $url = $apiUrl . (!empty($queryString) ? '?' . $queryString : '');
    $result = callPythonApi('GET', $url);
} elseif ($method === 'POST') {
    $data = $_POST;
    $result = callPythonApi('POST', $apiUrl, $data);
} else {
    http_response_code(405);
    echo json_encode(['error' => true, 'message' => 'Method Not Allowed']);
    exit;
}

// Mengembalikan respons dari API Python
if ($result['error']) {
    http_response_code(500);
    echo json_encode(['error' => true, 'message' => $result['message']]);
} else {
    http_response_code($result['http_code']);
    header('Content-Type: application/json');
    echo $result['response'];
}
?>
