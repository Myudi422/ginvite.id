<?php
// page/result.php
header('Content-Type: application/json');
// Ambil user_id (default = 1)
$userId = isset($_GET['user_id']) ? (int)$_GET['user_id'] : 1;

// 1) Ambil user & cek expired
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ? AND expired > NOW()");
$stmt->execute([$userId]);
$user = $stmt->fetch();
if (!$user) {
    http_response_code(404);
    exit(json_encode([
        'status'  => 'error',
        'message' => 'User not found atau sudah expired'
    ]));
}

// 2) Ambil template kategori
$stmt = $pdo->prepare("SELECT content_template FROM category_type WHERE id = ?");
$stmt->execute([$user['type_user']]);
$templateJson = $stmt->fetchColumn();
$template = json_decode($templateJson, true);

// 3) Ambil override konten user (jika ada)
$stmt = $pdo->prepare("SELECT content FROM content_user WHERE user_id = ?");
$stmt->execute([$userId]);
$userContentJson = $stmt->fetchColumn();
$userContent = $userContentJson ? json_decode($userContentJson, true) : [];

// 4) Merge (userContent override template)
$content = array_replace_recursive($template, $userContent);

// 5) Ambil theme sesuai user.theme_id
$stmt = $pdo->prepare("SELECT * FROM theme WHERE id = ?");
$stmt->execute([$user['theme_id']]);
$theme = $stmt->fetch();

// 6) Bentuk output JSON
$result = [
    'user' => [
        'id'           => $user['id'],
        'first_name'   => $user['first_name'],
        'pictures_url' => $user['pictures_url']
    ],
    'theme' => [
        'textColor'       => $theme['text_color'],
        'accentColor'     => $theme['accent_color'],
        'defaultBgImage'  => $theme['default_bg_image'],
        'defaultBgImage1' => $theme['default_bg_image1']
    ],
    'decorations' => [
        'topLeft'     => $theme['decorations_top_left'],
        'topRight'    => $theme['decorations_top_right'],
        'bottomLeft'  => $theme['decorations_bottom_left'],
        'bottomRight' => $theme['decorations_bottom_right']
    ],
    'content' => $content
];

echo json_encode($result, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
