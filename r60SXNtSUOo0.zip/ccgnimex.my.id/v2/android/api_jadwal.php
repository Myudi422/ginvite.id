<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

// Koneksi ke database
$koneksi = new mysqli("localhost", "ccgnimex", "aaaaaaac", "ccgnimex");

// Periksa koneksi
if ($koneksi->connect_error) {
    die("Koneksi gagal: " . $koneksi->connect_error);
}

// Membuat urutan hari dari Senin sampai Minggu
$urutan_hari = array("Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu");

// Inisialisasi array jadwal dengan urutan hari, setiap hari dimulai dengan array kosong
$jadwal = array("jadwal" => array());
foreach ($urutan_hari as $hari) {
    $jadwal["jadwal"][$hari] = array();
}

// Mendapatkan data jadwal dari database dengan diurutkan berdasarkan jam
$sql = "SELECT j.hari, j.jam, j.anime_id, a.judul, a.image FROM jadwal j
        JOIN anilist_data a ON j.anime_id = a.anime_id
        ORDER BY FIELD(j.hari, 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu'), j.jam ASC"; // Urutkan hari dan jam
$result = $koneksi->query($sql);

while ($row = $result->fetch_assoc()) {
    $hari = $row["hari"];
    $waktu = date("H:i", strtotime($row["jam"])); // Format jam tanpa detik
    $anime_id = $row["anime_id"];
    $judul = $row["judul"];
    $gambar = $row["image"];

    // Query untuk mendapatkan eps_terakhir dari tabel nonton
    $query_eps_terakhir = "SELECT MAX(episode_number) AS eps_terakhir FROM nonton WHERE anime_id = '$anime_id'";
    $result_eps_terakhir = $koneksi->query($query_eps_terakhir);
    $eps_terakhir = 0; // Default jika tidak ada data eps_terakhir

    if ($result_eps_terakhir && $result_eps_terakhir->num_rows > 0) {
        $row_eps_terakhir = $result_eps_terakhir->fetch_assoc();
        $eps_terakhir = $row_eps_terakhir["eps_terakhir"];
    }

    // Tambahkan data ke hari yang sesuai
    $jadwal["jadwal"][$hari][] = array(
        "anime_id" => $anime_id,
        "waktu" => $waktu,
        "gambar" => $gambar,
        "judul" => $judul
    );
}

// Menutup koneksi database
$koneksi->close();

// Mengembalikan data dalam format JSON
echo json_encode($jadwal, JSON_PRETTY_PRINT);
?>
