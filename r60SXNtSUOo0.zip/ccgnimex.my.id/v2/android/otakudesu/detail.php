<?php
function fetchAnimeDetails($id) {
    $url = "https://otakudesu.cloud/anime/" . $id;

    // Initialize cURL session
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // Disable SSL verification
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); // Follow redirects
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'); // Set User-Agent
    
    // Execute the cURL request
    $response = curl_exec($ch);

    // Check for errors
    if (curl_errno($ch)) {
        throw new Exception('cURL error: ' . curl_error($ch));
    }

    curl_close($ch);

    // Check if the response is empty
    if (empty($response)) {
        throw new Exception('Empty response from the server.');
    }

    // Load the HTML content
    $dom = new DOMDocument();
    libxml_use_internal_errors(true); // Suppress warnings due to malformed HTML
    $dom->loadHTML($response);
    libxml_clear_errors();

    $xpath = new DOMXPath($dom);

    // Fetch anime details
    $titleNode = $xpath->query('//*[@id="venkonten"]//div[contains(@class, "jdlrx")]/h1')->item(0);
    $thumbnailNode = $xpath->query('//*[@id="venkonten"]//div[contains(@class, "fotoanime")]/img')->item(0);
    $infoNodes = $xpath->query('//*[@id="venkonten"]//div[contains(@class, "infozin")]/p/span');
    $episodeNodes = $xpath->query('/html/body/div[1]/div[9]/div[2]/div[8]/ul/li');

    $title = $titleNode ? trim($titleNode->nodeValue) : null;
    $thumbnail = $thumbnailNode ? $thumbnailNode->getAttribute('src') : null;

    $info = [];
    foreach ($infoNodes as $node) {
        $info[] = trim($node->nodeValue);
    }

    $links = [];
    foreach ($episodeNodes as $node) {
        $titleNode = $xpath->query('.//span[1]/a', $node)->item(0);
        $releaseNode = $xpath->query('.//span[2]', $node)->item(0);

        $episodeTitle = $titleNode ? trim($titleNode->nodeValue) : null;
        $href = $titleNode ? $titleNode->getAttribute('href') : null;
        // Extract episode ID from href (assuming ID is the part before "-sub-indo")
        $episodeId = $href ? explode('/', $href)[4] : null;
        $release = $releaseNode ? trim($releaseNode->nodeValue) : null;

        if ($episodeTitle && $episodeId && $release) {
            $links[] = [
                'id' => $episodeId,
                'title' => $episodeTitle,
                'release' => str_replace(',', ' ', $release),
            ];
        }
    }

    return [
        'title' => trim($title),
        'thumbnail' => $thumbnail,
        'info' => $info,
        'links' => $links,
        'slug' => $id, // Using ID as slug
    ];
}

try {
    // Get the anime ID from the query parameter
    if (!isset($_GET['id'])) {
        throw new Exception('Anime ID is required.');
    }
    $animeId = $_GET['id'];
    
    // Fetch the anime details
    $animeDetails = fetchAnimeDetails($animeId);

    // Return JSON response
    header('Content-Type: application/json');
    echo json_encode([
        'status' => 200,
        'success' => true,
        'data' => $animeDetails,
    ]);
} catch (Exception $e) {
    // Handle any errors
    header('Content-Type: application/json', true, 500);
    echo json_encode([
        'status' => 500,
        'message' => $e->getMessage(),
    ]);
}
