<?php
function fetchEpisodeEmbed($episodeId) {
    $url = "https://otakudesu.cloud/episode/" . $episodeId;

    // Initialize cURL session
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // Disable SSL verification
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); // Follow redirects
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'); // Set User-Agent

    // Execute the cURL request
    $response = curl_exec($ch);

    // Check for errors
    if (curl_errno($ch)) {
        throw new Exception('cURL error: ' . curl_error($ch));
    }

    curl_close($ch);

    // Check if the response is empty
    if (empty($response)) {
        throw new Exception('Empty response from the server.');
    }

    // Load the HTML content
    $dom = new DOMDocument();
    libxml_use_internal_errors(true); // Suppress warnings due to malformed HTML
    $dom->loadHTML($response);
    libxml_clear_errors();

    $xpath = new DOMXPath($dom);

    // Fetch the iframe src link
    $iframeNode = $xpath->query('//*[@id="pembed"]/div/iframe')->item(0);
    $embedLink = $iframeNode ? $iframeNode->getAttribute('src') : null;

    // Fetch the episode title
    $titleNode = $xpath->query('//*[@id="venkonten"]/div[contains(@class, "venser")]/div[contains(@class, "venutama")]/h1')->item(0);
    $title = $titleNode ? trim($titleNode->nodeValue) : null;

    // Check if data is available
    if (!$embedLink || !$title) {
        throw new Exception('Failed to retrieve episode embed or title.');
    }

    return [
        'title' => $title,
        'embed_link' => $embedLink,
    ];
}

try {
    // Get the episode ID from the query parameter
    if (!isset($_GET['id'])) {
        throw new Exception('Episode ID is required.');
    }
    $episodeId = $_GET['id'];
    
    // Fetch the episode details
    $episodeDetails = fetchEpisodeEmbed($episodeId);

    // Return JSON response
    header('Content-Type: application/json');
    echo json_encode([
        'status' => 200,
        'success' => true,
        'data' => $episodeDetails,
    ]);
} catch (Exception $e) {
    // Handle any errors
    header('Content-Type: application/json', true, 500);
    echo json_encode([
        'status' => 500,
        'message' => $e->getMessage(),
    ]);
}
