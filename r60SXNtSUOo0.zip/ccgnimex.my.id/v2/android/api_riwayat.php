<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

// Inisialisasi array respons
$response = [];

// Buat koneksi ke database
$conn = new mysqli('127.0.0.1', 'ccgnimex', 'aaaaaaac', 'ccgnimex');
if ($conn->connect_error) {
    $response['error'] = 'Connection failed: ' . $conn->connect_error;
    echo json_encode($response);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // POST digunakan untuk operasi hapus

    // Pastikan parameter 'action' tersedia
    if (isset($_POST['action'])) {
        $action = $_POST['action'];

        // ---- HAPUS SEMUA RIWAYAT BERDASARKAN telegram_id ----
        if ($action === 'delete_all') {
            if (isset($_POST['telegram_id'])) {
                $telegram_id = $_POST['telegram_id'];
                $stmt = $conn->prepare("DELETE FROM waktu_terakhir_tontonan WHERE telegram_id = ?");
                $stmt->bind_param("s", $telegram_id);
                if ($stmt->execute()) {
                    $response['message'] = "Semua riwayat untuk telegram_id $telegram_id telah dihapus.";
                } else {
                    $response['error'] = "Gagal menghapus riwayat: " . $stmt->error;
                }
                $stmt->close();
            } else {
                $response['error'] = "Parameter telegram_id tidak ditemukan.";
            }
        // ---- HAPUS ITEM TERTENTU (multi item) berdasarkan telegram_id dan anime_id ----
        } elseif ($action === 'delete_item') {
            if (isset($_POST['telegram_id']) && isset($_POST['anime_ids'])) {
                $telegram_id = $_POST['telegram_id'];
                $anime_ids = $_POST['anime_ids'];

                // Jika anime_ids bukan array, asumsikan format string yang dipisahkan dengan koma
                if (!is_array($anime_ids)) {
                    $anime_ids = explode(",", $anime_ids);
                }

                // Buat placeholder dinamis untuk query
                $placeholders = implode(',', array_fill(0, count($anime_ids), '?'));
                $sql = "DELETE FROM waktu_terakhir_tontonan WHERE telegram_id = ? AND anime_id IN ($placeholders)";
                $stmt = $conn->prepare($sql);
                if ($stmt === false) {
                    $response['error'] = "Prepare failed: " . $conn->error;
                } else {
                    // Semua parameter dianggap string
                    $types = 's' . str_repeat('s', count($anime_ids));
                    // Gabungkan telegram_id dan array anime_ids
                    $params = array_merge([$telegram_id], $anime_ids);
                    // Binding parameter secara dinamis
                    $bind_names = [];
                    $bind_names[] = $types;
                    foreach ($params as $key => $value) {
                        $bind_names[] = &$params[$key];
                    }
                    call_user_func_array(array($stmt, 'bind_param'), $bind_names);

                    if ($stmt->execute()) {
                        $response['message'] = "Item dengan anime_id tertentu telah dihapus untuk telegram_id $telegram_id.";
                    } else {
                        $response['error'] = "Gagal menghapus item: " . $stmt->error;
                    }
                    $stmt->close();
                }
            } else {
                $response['error'] = "Parameter telegram_id atau anime_ids tidak ditemukan.";
            }
        } else {
            $response['error'] = "Action tidak valid.";
        }
    } else {
        $response['error'] = "Parameter action tidak ditemukan.";
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // GET digunakan untuk mengambil riwayat tontonan

    // Cek parameter GET telegram_id dan page
    if (isset($_GET['telegram_id']) && isset($_GET['page'])) {
        $telegram_id = $_GET['telegram_id'];
        $page = $_GET['page'];
        $limit = 20;
        $offset = ($page - 1) * $limit;

        // Query untuk ambil data dengan paginasi
        $sql = "SELECT wt.anime_id, MAX(wt.last_watched) as max_last_watched
                FROM waktu_terakhir_tontonan wt
                WHERE wt.telegram_id = ?
                GROUP BY wt.anime_id
                ORDER BY max_last_watched DESC
                LIMIT ? OFFSET ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sii", $telegram_id, $limit, $offset);
        $stmt->execute();

        // Dapatkan hasil query
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                // Ambil detail untuk tiap anime_id
                $anime_id = $row['anime_id'];
                $animeDetails = getAnimeDetails($conn, $telegram_id, $anime_id);
                $response['animeHistory'][] = $animeDetails;
            }
        } else {
            $response['message'] = 'No anime found for the specified telegram_id and page';
        }
        $stmt->close();
    } else {
        $response['error'] = 'Telegram ID or page not provided in the URL';
    }
} else {
    $response['error'] = 'Invalid request method';
}

$conn->close();
echo json_encode($response);

// Function untuk mengambil detail anime
function getAnimeDetails($conn, $telegram_id, $anime_id) {
    $sql = "SELECT wt.anime_id, wt.episode_number, wt.video_time, wt.last_watched, ad.judul, ad.image
            FROM waktu_terakhir_tontonan wt
            LEFT JOIN anilist_data ad ON wt.anime_id = ad.anime_id
            WHERE wt.telegram_id = ? AND wt.anime_id = ?
            ORDER BY wt.last_watched DESC
            LIMIT 1";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $telegram_id, $anime_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $row['anime_id'] = (int)$row['anime_id'];
    $stmt->close();

    return $row;
}
?>
