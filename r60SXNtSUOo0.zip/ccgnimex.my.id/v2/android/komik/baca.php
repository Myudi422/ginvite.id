<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

// URL target dan server parameter
$url = $_GET['url'];
$server = $_GET['server'];

// Function to scrape Mangakyo
function scrapeMangakyo($url) {
    $dom = new DOMDocument();
    libxml_use_internal_errors(true);
    $dom->loadHTMLFile($url);

    $xpath = new DOMXPath($dom);
    $title = $xpath->evaluate("string(//div[contains(@class, 'headpost')]/h1[contains(@class, 'entry-title')])");
    $scripts = $xpath->evaluate("//script");

    $prevUrl = null;
    $nextUrl = null;
    $imageUrls = [];

    foreach ($scripts as $script) {
        $scriptContent = $script->nodeValue;

        if (strpos($scriptContent, 'ts_reader.run') !== false) {
            preg_match('/"prevUrl":"([^"]+)"/', $scriptContent, $prevUrlMatch);
            if (isset($prevUrlMatch[1])) {
                $prevUrl = str_replace('\\/', '/', $prevUrlMatch[1]);
            }

            preg_match('/"nextUrl":"([^"]+)"/', $scriptContent, $nextUrlMatch);
            if (isset($nextUrlMatch[1])) {
                $nextUrl = str_replace('\\/', '/', $nextUrlMatch[1]);
            }

            preg_match_all('/"images":\s*\[([^\]]+)\]/', $scriptContent, $matches);
            if (isset($matches[1][0])) {
                $imageUrls = json_decode('[' . $matches[1][0] . ']', true);
            }

            if ($prevUrl !== null && $imageUrls) {
                break;
            }
        }
    }

    return [$title, $prevUrl, $nextUrl, $imageUrls];
}

if ($server === 'komiku-id1') {
    // Transform the URL for Komiku ID1
    $parsedUrl = parse_url($url);
    $path = $parsedUrl['path'];
    $newPath = preg_replace('/^\/([^\/]+)\//', '/$1/', $path);
    $newUrl = 'https://komiku.id' . $newPath;

    // Fetch images from Komiku
    $komikuUrl = 'https://ccgnimex.my.id/v2/android/komik/komiku.php?url=' . urlencode($newUrl);
    $komikuResponse = @file_get_contents($komikuUrl);

    if ($komikuResponse === FALSE) {
        $imageUrls = []; // Kosongkan jika gagal
    } else {
        // Decode Komiku response
        $komikuData = json_decode($komikuResponse, true);
        $imageUrls = $komikuData['imageUrls'] ?? [];
    }

    // Fetch Mangakyo data for title, prevUrl, and nextUrl
    list($title, $prevUrl, $nextUrl, $mangakyoImages) = scrapeMangakyo($url);

    $response = [
        'title' => $title,
        'prevUrl' => $prevUrl ?: "",
        'nextUrl' => $nextUrl ?: "",
        'imageUrls' => $imageUrls // Use images from Komiku
    ];
} elseif ($server === 'komiku-id2') {
    // Transform the URL for Komiku ID2
    $parsedUrl = parse_url($url);
    $path = $parsedUrl['path'];

    // Transform path for ID2
    // Convert 'chapter-01' to 'chapter-1', 'chapter-02' to 'chapter-2', etc.
    $newPath = preg_replace('/chapter-0(\d+)/', 'chapter-$1', $path);
    $newUrl = 'https://komiku.id' . $newPath;

    // Fetch images from Komiku
    $komikuUrl = 'https://ccgnimex.my.id/v2/android/komik/komiku.php?url=' . urlencode($newUrl);
    $komikuResponse = @file_get_contents($komikuUrl);

    if ($komikuResponse === FALSE) {
        $imageUrls = []; // Kosongkan jika gagal
    } else {
        // Decode Komiku response
        $komikuData = json_decode($komikuResponse, true);
        $imageUrls = $komikuData['imageUrls'] ?? [];
    }

    // Fetch Mangakyo data for title, prevUrl, and nextUrl
    list($title, $prevUrl, $nextUrl, $mangakyoImages) = scrapeMangakyo($url);

    $response = [
        'title' => $title,
        'prevUrl' => $prevUrl ?: "",
        'nextUrl' => $nextUrl ?: "",
        'imageUrls' => $imageUrls // Use images from Komiku
    ];


} elseif ($server === 'komiku-id3') {
    // Transform the URL for Komiku ID3
    $parsedUrl = parse_url($url);
    $path = $parsedUrl['path'];

    // Menghapus trailing slash jika ada
    $path = rtrim($path, '/');

    // Mengubah path URL untuk komiku-id3
    // Ganti "/shiotaiou-no-sato-san-ga-ore-ni-dake-amai-chapter-01" menjadi "/komik-shiotaiou-no-sato-san-ga-ore-ni-dake-amai-chapter-01"
    $newPath = preg_replace('/^\/(.*?)-0(\d+)$/', '/komik-$1-$2', $path);

    // Mengubah format chapter -01 menjadi -1
    $newPath = preg_replace('/-0(\d+)/', '-$1', $newPath);

    // Menambahkan "-bahasa-indonesia" di akhir
    $newPath .= '-bahasa-indonesia/';

    $newUrl = 'https://komiku.id' . $newPath;

    // Fetch images from Komiku
    $komikuUrl = 'https://ccgnimex.my.id/v2/android/komik/komiku.php?url=' . urlencode($newUrl);
    $komikuResponse = @file_get_contents($komikuUrl);

    if ($komikuResponse === FALSE) {
        $imageUrls = []; // Kosongkan jika gagal
    } else {
        // Decode Komiku response
        $komikuData = json_decode($komikuResponse, true);
        $imageUrls = $komikuData['imageUrls'] ?? [];
    }

    // Fetch Mangakyo data for title, prevUrl, and nextUrl
    list($title, $prevUrl, $nextUrl, $mangakyoImages) = scrapeMangakyo($url);

    $response = [
        'title' => $title,
        'prevUrl' => $prevUrl ?: "",
        'nextUrl' => $nextUrl ?: "",
        'imageUrls' => $imageUrls // Use images from Komiku
    ];


} elseif ($server === 'komiku-id4') {
    // Transform the URL for Komiku ID4
    $parsedUrl = parse_url($url);
    $path = $parsedUrl['path'];

    // Transform path for ID4
    // Convert 'chapter-1' to 'chapter-01', 'chapter-2' to 'chapter-02', etc.
    $newPath = preg_replace('/-(\d)$/', '-0$1', $path);
    $newUrl = 'https://komiku.id' . $newPath;

    // Fetch images from Komiku
    $komikuUrl = 'https://ccgnimex.my.id/v2/android/komik/komiku.php?url=' . urlencode($newUrl);
    $komikuResponse = @file_get_contents($komikuUrl);

    if ($komikuResponse === FALSE) {
        $imageUrls = []; // Kosongkan jika gagal
    } else {
        // Decode Komiku response
        $komikuData = json_decode($komikuResponse, true);
        $imageUrls = $komikuData['imageUrls'] ?? [];
    }

    // Fetch Mangakyo data for title, prevUrl, and nextUrl
    list($title, $prevUrl, $nextUrl, $mangakyoImages) = scrapeMangakyo($url);

    $response = [
        'title' => $title,
        'prevUrl' => $prevUrl ?: "",
        'nextUrl' => $nextUrl ?: "",
        'imageUrls' => $imageUrls // Use images from Komiku
    ];

} else {
    // Scrape Mangakyo for other servers
    list($title, $prevUrl, $nextUrl, $imageUrls) = scrapeMangakyo($url);

    $response = [
        'title' => $title,
        'prevUrl' => $prevUrl ?: "",
        'nextUrl' => $nextUrl ?: "",
        'imageUrls' => $imageUrls
    ];
}

// Output JSON response
header('Content-Type: application/json');
echo json_encode($response, JSON_PRETTY_PRINT);
?>
