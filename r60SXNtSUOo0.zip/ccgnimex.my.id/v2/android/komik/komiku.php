<?php
// Cek apakah parameter 'url' ada
if (!isset($_GET['url']) || empty($_GET['url'])) {
    http_response_code(400);
    echo json_encode(["error" => "Parameter 'url' tidak ditemukan atau kosong"], JSON_PRETTY_PRINT);
    exit;
}

// URL of the webpage
$url = $_GET['url'];

// Initialize a cURL session
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); // Follow redirects

// Execute the cURL session and get the content of the page
$html = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

// Cek apakah HTTP response code 200
if ($httpCode != 200 || empty($html)) {
    http_response_code(500);
    echo json_encode(["error" => "Gagal mengambil konten dari URL atau konten kosong"], JSON_PRETTY_PRINT);
    exit;
}

// Load the HTML content using DOMDocument
$dom = new DOMDocument();
libxml_use_internal_errors(true);
$dom->loadHTML($html);
libxml_clear_errors();

// Create a new DOMXPath object
$xpath = new DOMXPath($dom);

// XPath query untuk mendapatkan elemen gambar
$query = "//img";
$entries = $xpath->query($query);

// Extract the src attribute of each image and store in an array
$imageUrls = [];
foreach ($entries as $entry) {
    $src = $entry->getAttribute('src');
    // Pastikan URL gambar tidak kosong dan tidak mengandung ukuran 150x150 atau ekstensi .gif
    if (!empty($src) && !preg_match('/\bresize=150,150\b/', $src) && !preg_match('/\.gif$/i', $src)) {
        // Tambahkan URL gambar ke array
        $imageUrls[] = $src;
    }
}

// Convert the array to JSON format
$json = json_encode(["imageUrls" => $imageUrls], JSON_PRETTY_PRINT);

// Output the JSON
header('Content-Type: application/json');
echo $json;
?>
