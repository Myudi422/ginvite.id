<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

$servername = "localhost";
$username = "ccgnimex";
$password = "aaaaaaac";
$dbname = "ccgnimex";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die(json_encode(["status" => "error", "message" => "Connection failed"]));
}

$telegram_id = $conn->real_escape_string($_POST['telegram_id'] ?? '');
$komik_url = $conn->real_escape_string($_POST['komik_url'] ?? '');

// Debugging: Output received parameters
if (empty($telegram_id) || empty($komik_url)) {
    echo json_encode([
        "status" => "error",
        "message" => "Parameters required",
        "debug" => [
            "received_telegram_id" => $telegram_id,
            "received_komik_url" => $komik_url
        ]
    ]);
    exit;
}

$sql = "DELETE FROM fav_manga WHERE telegram_id = '$telegram_id' AND komik_url = '$komik_url'";
if ($conn->query($sql) === TRUE) {
    echo json_encode(["status" => "success", "message" => "Manga removed from favorites"]);
} else {
    echo json_encode(["status" => "error", "message" => "Failed to remove manga"]);
}

$conn->close();
?>
