<?php

// Fungsi untuk melakukan koneksi ke database
function connectToDatabase() {
    $host = 'localhost';
    $username = 'ccgnimex';
    $password = 'aaaaaaac';
    $database = 'ccgnimex';

    $connection = new mysqli($host, $username, $password, $database);

    if ($connection->connect_error) {
        die("Connection failed: " . $connection->connect_error);
    }

    return $connection;
}

// Fungsi untuk mendapatkan data dari tabel manga_history berdasarkan telegram_id dan image_url
function getMangaHistoryByTelegramId($telegramId, $imageUrl, $connection) {
    $query = "SELECT title_eps FROM manga_history WHERE telegram_id = ? AND image = ?";
    $statement = $connection->prepare($query);
    $statement->bind_param("ss", $telegramId, $imageUrl);
    $statement->execute();
    $result = $statement->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row['title_eps'];
    } else {
        return '';
    }
}

// Membuat koneksi ke database
$databaseConnection = connectToDatabase();

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

// URL target
$baseUrl = 'https://mangakyo.vip/komik';
$page = isset($_GET['page']) ? $_GET['page'] : 1;
$order = isset($_GET['order']) ? $_GET['order'] : 'update';
$status = isset($_GET['status']) ? $_GET['status'] : '';
$genres = isset($_GET['genre']) ? $_GET['genre'] : array();
$telegramId = isset($_GET['telegram_id']) ? $_GET['telegram_id'] : '';

// Membuat URL dengan parameter status, order by, dan genre
$url = $baseUrl . '?page=' . $page . '&order=' . $order . '&status=' . $status;
foreach ($genres as $genre) {
    $url .= '&genre%5B%5D=' . $genre;
}

// Memuat konten HTML dari URL
$html = file_get_contents($url);

// Membuat objek DOMDocument
$dom = new DOMDocument();

// Memuat konten HTML ke dalam objek DOMDocument
$dom->loadHTML($html);

// Mengaktifkan XPath untuk pencarian elemen
$xpath = new DOMXPath($dom);

// Mencari semua div dengan class 'bsx'
$bsxDivs = $xpath->query("//div[contains(@class, 'bsx')]");

// Array untuk menyimpan data komik
$comics = array();

// Iterasi melalui setiap div 'bsx'
foreach ($bsxDivs as $bsxDiv) {
    // Mengambil URL komik dari atribut href
    $url = $xpath->evaluate("string(.//a/@href)", $bsxDiv);

    // Mengambil judul komik
    $title = $xpath->evaluate("string(.//div[contains(@class, 'tt')])", $bsxDiv);

    // Mengambil chapter komik
    $chapter = $xpath->evaluate("string(.//div[contains(@class, 'epxs')])", $bsxDiv);

    // Mengambil URL gambar
    $image = $xpath->evaluate("string(.//img/@data-src)", $bsxDiv);

    // Mengambil informasi tambahan dari tabel manga_history berdasarkan telegram_id dan image_url
    $titleEps = '';
    if (!empty($telegramId)) {
        $titleEps = getMangaHistoryByTelegramId($telegramId, $image, $databaseConnection);
        // Memotong title_eps agar hanya menyertakan bagian chapter
        $titleEps = preg_replace("/Chapter (\d+(\.\d+)?).*/", "$1", $titleEps);
    }

    // Menyimpan data komik ke dalam array
    $comics[] = array(
        'title' => $title,
        'url' => $url,
        'chapter' => $chapter,
        'image' => $image,
        'title_eps' => $titleEps
    );
}

// Mengembalikan data komik sebagai JSON response
header('Content-Type: application/json');
echo json_encode($comics, JSON_PRETTY_PRINT);

// Menutup koneksi ke database
$databaseConnection->close();
?>
