<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

// URL target
$url = $_GET['url'];

// Membuat objek DOMDocument
$dom = new DOMDocument();

// Mematikan error dan warning ketika parsing HTML
libxml_use_internal_errors(true);

// Memuat konten HTML dari URL
$dom->loadHTMLFile($url);

// Mengaktifkan XPath untuk pencarian elemen
$xpath = new DOMXPath($dom);

// Judul komik
$title = $xpath->evaluate("string(//h1[contains(@class, 'entry-title')])");

// List genre komik
$genreListItems = $xpath->query("//div[contains(@class, 'seriestugenre')]/a");

$genres = [];
foreach ($genreListItems as $genreItem) {
    $genres[] = $genreItem->textContent;
}

// List episode komik
$episodeListItems = $xpath->query("//div[@id='chapterlist']//ul[contains(@class, 'clstyle')]/li");

$episodes = [];
foreach ($episodeListItems as $episodeItem) {
    $episodeUrl = $xpath->evaluate("string(.//a/@href)", $episodeItem);
    $episodeText = trim(preg_replace('/\s+/', ' ', $episodeItem->textContent));

    // Pisahkan title dan date menggunakan regex
    if (preg_match('/(Chapter \d+(\.\d+)?)\s*(.+)/', $episodeText, $matches)) {
        $episodeTitle = $matches[1]; // "Chapter 15.2"
        $episodeDate = $matches[3];   // "Mei 20, 2024"
    } else {
        $episodeTitle = $episodeText; // Jika tidak ada match, gunakan teks aslinya
        $episodeDate = ''; // Kosongkan tanggal jika tidak ditemukan
    }

    // Mengganti karakter '\' dengan '/'
    $episodeUrl = str_replace('\\/', '/', $episodeUrl);

    $episodes[] = [
        'url' => $episodeUrl,
        'title' => $episodeTitle,
        'date' => $episodeDate, // Tambahkan field 'date'
        'saved' => $isSaved,
    ];
}



// Gambar komik (penanganan lazy loading)
$imageNode = $xpath->query("//div[@class='thumb']/img")->item(0);
$image = '';
if ($imageNode) {
    $image = $imageNode->getAttribute('data-src') ?: $imageNode->getAttribute('src');
}

$description = $xpath->evaluate("string(//div[@class='entry-content entry-content-single']/p)");

// Rating information
$ratingPercent = $xpath->evaluate("string(//div[@class='rtp']/div[@class='rtb']/span/@style)");
$ratingValue = $xpath->evaluate("string(//div[@class='num'])");

// Comic Information
$status = $xpath->evaluate("string(//td[text()='Status']/following-sibling::td)");

// Return the fetched details as JSON response
header('Content-Type: application/json');
echo json_encode([
    'title' => $title,
    'genres' => $genres,
    'episodes' => $episodes,
    'image' => $image,
    'description' => $description,
    'rating' => [
        'percent' => $ratingPercent,
        'value' => $ratingValue,
    ],
    'status' => $status,
], JSON_PRETTY_PRINT);
?>
