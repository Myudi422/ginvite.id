<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

// Assuming you have a database connection established
$servername = "localhost";
$username = "ccgnimex";
$password = "aaaaaaac";
$dbname = "ccgnimex";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve data from the POST request
$image = $_POST['image'];
$title = $_POST['title'];
$episode_url = $_POST['episode_url'];
$title_eps = $_POST['title_eps'];
$telegram_id = $_POST['telegram_id'];

// Set the time zone to Jakarta (WIB)
date_default_timezone_set('Asia/Jakarta');

// Get the current timestamp in Jakarta time zone
$last_watched = date("Y-m-d H:i:s");

// Check if the record already exists
$check_sql = "SELECT * FROM manga_history WHERE telegram_id = '$telegram_id' AND title = '$title'";
$result = $conn->query($check_sql);

if ($result->num_rows == 0) {
    // Record does not exist, so insert it
    $insert_sql = "INSERT INTO manga_history (image, title, episode_url, title_eps, telegram_id, last_watched) VALUES ('$image', '$title', '$episode_url', '$title_eps', '$telegram_id', '$last_watched')";
    
    if ($conn->query($insert_sql) === TRUE) {
        echo "Record inserted successfully";
    } else {
        echo "Error: " . $insert_sql . "<br>" . $conn->error;
    }
} else {
    // Record already exists, so update it
    $update_sql = "UPDATE manga_history SET image='$image', episode_url='$episode_url', title_eps='$title_eps', last_watched='$last_watched' WHERE telegram_id='$telegram_id' AND title='$title'";
    
    if ($conn->query($update_sql) === TRUE) {
        echo "Record updated successfully";
    } else {
        echo "Error: " . $update_sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>
