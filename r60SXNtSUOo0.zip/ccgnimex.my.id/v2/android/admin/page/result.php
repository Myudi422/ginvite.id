<?php
// page/result.php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
require __DIR__ . '/../db.php';

// 1) Ambil parameter dari Query-String
$userId     = isset($_GET['user'])     && is_numeric($_GET['user'])     ? (int)$_GET['user']     : 1;
$themeId    = isset($_GET['theme'])    && is_numeric($_GET['theme'])    ? (int)$_GET['theme']    : null;
$categoryId = isset($_GET['category']) && is_numeric($_GET['category']) ? (int)$_GET['category'] : null;

// 2) Load user & cek expired
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ? AND expired > NOW()");
$stmt->execute([$userId]);
$user = $stmt->fetch();
if (!$user) {
    http_response_code(404);
    exit(json_encode([
        'status'  => 'error',
        'message' => 'User tidak ditemukan atau sudah expired'
    ]));
}

// 3) Tentukan categoryId & themeId akhir
$categoryId = $categoryId ?? (int)$user['type_user'];
$themeId    = $themeId    ?? (int)$user['theme_id'];

// 4) Ambil template kategori
$stmt = $pdo->prepare("SELECT content_template FROM category_type WHERE id = ?");
$stmt->execute([$categoryId]);
$templateJson = $stmt->fetchColumn();
if (!$templateJson) {
    http_response_code(404);
    exit(json_encode([
        'status'  => 'error',
        'message' => "Kategori ID={$categoryId} tidak ditemukan"
    ]));
}
$template = json_decode($templateJson, true);

// 5) Ambil override konten user berdasarkan kategori
$stmt = $pdo->prepare(
    "SELECT content 
      FROM content_user 
     WHERE user_id = ? 
       AND category_id = ?
     LIMIT 1"
);
$stmt->execute([$userId, $categoryId]);
$userContentJson = $stmt->fetchColumn();
$userContent     = $userContentJson ? json_decode($userContentJson, true) : [];

// Merge template + override
// Jika userContent memiliki parameter top-level, gunakan nilai dari userContent sepenuhnya
$content = $template;
foreach ($userContent as $key => $value) {
    $content[$key] = $value;
}

// Pastikan key our_story ada
if (!isset($content['our_story'])) {
    $content['our_story'] = [];
}

// 6) Ambil theme
$stmt = $pdo->prepare("SELECT * FROM theme WHERE id = ?");
$stmt->execute([$themeId]);
$theme = $stmt->fetch();
if (!$theme) {
    http_response_code(404);
    exit(json_encode([
        'status'  => 'error',
        'message' => "Theme ID={$themeId} tidak ditemukan"
    ]));
}

// 7) Bentuk output JSON
$result = [
    'user'        => [
        'id'           => $user['id'],
        'first_name'   => $user['first_name'],
        'pictures_url' => $user['pictures_url']
    ],
    'theme'       => [
        'textColor'       => $theme['text_color'],
        'accentColor'     => $theme['accent_color'],
        'defaultBgImage'  => $theme['default_bg_image'],
        'defaultBgImage1' => $theme['default_bg_image1']
    ],
    'decorations' => [
        'topLeft'     => $theme['decorations_top_left'],
        'topRight'    => $theme['decorations_top_right'],
        'bottomLeft'  => $theme['decorations_bottom_left'],
        'bottomRight' => $theme['decorations_bottom_right']
    ],
    'content'     => $content
];

// 8) Kirim JSON
echo json_encode($result, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
