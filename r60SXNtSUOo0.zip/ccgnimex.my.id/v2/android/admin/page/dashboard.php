<?php
// api/dashboard.php
header('Content-Type: application/json');
require __DIR__ . '/../db.php';

// 1) Query semua content_user beserta nama user
$sql = "
  SELECT 
    cu.id                AS content_id,
    cu.user_id           AS user_id,
    u.first_name         AS first_name,
    cu.category_id       AS category_id,
    cu.content           AS content_json
  FROM content_user cu
  JOIN users u ON u.id = cu.user_id
  ORDER BY u.first_name, cu.id
";
$stmt = $pdo->prepare($sql);
$stmt->execute();
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

// 2) Siapkan output
$data = array_map(function($r) {
    return [
      'content_id'  => (int)$r['content_id'],
      'user_id'     => (int)$r['user_id'],
      'first_name'  => $r['first_name'],
      'category_id' => (int)$r['category_id'],
      // kalau mau preview isi JSON-nya, bisa:
      'content'     => json_decode($r['content_json'], true),
      'actions'     => [
        'view' => "/admin/dashboard/view.php?content_id={$r['content_id']}",
        'edit' => "/admin/dashboard/edit.php?content_id={$r['content_id']}"
      ]
    ];
}, $rows);

// 3) Kirim JSON
echo json_encode([
  'status' => 'success',
  'data'   => $data
], JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT);
