
<?php
echo json_encode([
    'status'  => 'ok',
    'message' => 'Welcome to JSON API. Available endpoints: stats'
]);
?>
