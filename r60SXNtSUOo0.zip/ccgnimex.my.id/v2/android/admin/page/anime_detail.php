<?php

try {
    $animeId = isset($_GET['anime_id']) ? (int)$_GET['anime_id'] : 0;
    if (!$animeId) {
        throw new Exception('anime_id tidak valid');
    }

    // Jika ada request POST untuk menambah atau mengubah episode:
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Tambah episode baru
        if (isset($_POST['action']) && $_POST['action'] === 'add') {
            $stmt = $pdo->prepare("
                INSERT INTO nonton
                  (anime_id, episode_number, title, video_url, subtitle_links, subtitle_url, resolusi)
                VALUES
                  (:anime_id, :ep_no, :title, :video_url, :sub_links, :sub_url, :resolusi)
            ");
            $stmt->execute([
                'anime_id'   => $animeId,
                'ep_no'      => (int)$_POST['episode_number'],
                'title'      => trim($_POST['title']),
                'video_url'  => trim($_POST['video_url']),
                'sub_links'  => trim($_POST['subtitle_links'] ?? ''),
                'sub_url'    => trim($_POST['subtitle_url'] ?? ''),
                'resolusi'   => trim($_POST['resolusi'])
            ]);
        }

        // Ubah episode
        if (isset($_POST['action']) && $_POST['action'] === 'edit' && isset($_POST['id'])) {
            $stmt = $pdo->prepare("
                UPDATE nonton SET
                  episode_number = :ep_no,
                  title          = :title,
                  video_url      = :video_url,
                  subtitle_links = :sub_links,
                  subtitle_url   = :sub_url,
                  resolusi       = :resolusi
                WHERE id = :id
            ");
            $stmt->execute([
                'ep_no'     => (int)$_POST['episode_number'],
                'title'     => trim($_POST['title']),
                'video_url' => trim($_POST['video_url']),
                'sub_links' => trim($_POST['subtitle_links'] ?? ''),
                'sub_url'   => trim($_POST['subtitle_url'] ?? ''),
                'resolusi'  => trim($_POST['resolusi']),
                'id'        => (int)$_POST['id']
            ]);
        }
    }

    // Ambil data anime
    $stmt = $pdo->prepare("SELECT * FROM anilist_data WHERE anime_id = :anime_id");
    $stmt->execute(['anime_id' => $animeId]);
    $anime = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$anime) {
        throw new Exception('Data anime tidak ditemukan');
    }

    // Ambil daftar episode
    $stmt = $pdo->prepare("SELECT * FROM nonton WHERE anime_id = :anime_id ORDER BY episode_number");
    $stmt->execute(['anime_id' => $animeId]);
    $episodes = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        'status'   => 'success',
        'anime'    => $anime,
        'episodes' => $episodes
    ]);
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'status'  => 'error',
        'message' => $e->getMessage()
    ]);
}
