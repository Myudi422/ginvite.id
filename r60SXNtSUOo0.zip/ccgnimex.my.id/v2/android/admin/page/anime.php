<?php
try {
    // Ambil parameter search, page, dan status
    $search = isset($_GET['search']) ? trim($_GET['search']) : '';
    $status = isset($_GET['status']) ? trim($_GET['status']) : ''; // Tambahan filter status
    $page = isset($_GET['page']) ? max((int)$_GET['page'], 1) : 1;
    $limit = 5; // Selalu pakai limit 5
    $offset = ($page - 1) * $limit;

    $params = [];
    $sqlBase = "FROM anilist_data WHERE 1=1";

    // Filter berdasarkan judul
    if (!empty($search)) {
        $sqlBase .= " AND judul LIKE :search";
        $params['search'] = "%$search%";
    }

    // Filter berdasarkan status
    if (!empty($status)) {
        $sqlBase .= " AND status = :status";
        $params['status'] = $status;
    }

    // Hitung total hasil
    $stmt = $pdo->prepare("SELECT COUNT(*) AS total $sqlBase");
    $stmt->execute($params);
    $total = (int)$stmt->fetch()['total'];

    // Query ambil data
    $query = "SELECT * $sqlBase ORDER BY id DESC LIMIT :limit OFFSET :offset";
    $stmt = $pdo->prepare($query);

    // Bind parameter search dan status
    if (!empty($search)) {
        $stmt->bindValue(':search', "%$search%", PDO::PARAM_STR);
    }
    if (!empty($status)) {
        $stmt->bindValue(':status', $status, PDO::PARAM_STR);
    }

    // Bind limit dan offset
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);

    // Eksekusi
    $stmt->execute();
    $animeList = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Output JSON
    echo json_encode([
        'status' => 'success',
        'total' => $total,
        'page' => $page,
        'limit' => $limit,
        'data' => $animeList
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => $e->getMessage()
    ]);
}
