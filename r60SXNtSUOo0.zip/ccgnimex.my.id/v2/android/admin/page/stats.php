<?php
date_default_timezone_set('Asia/Jakarta');
$today = date('Y-m-d');

try {
    // Ensure $pdo is your PDO connection instance

    // Total users
    $stmt = $pdo->query("SELECT COUNT(id_web) AS totalUser FROM users_web");
    $totalUser = (int)$stmt->fetch()['totalUser'];

    // Total anime
    $stmt = $pdo->query("SELECT COUNT(id) AS totalAnime FROM anilist_data");
    $totalAnime = (int)$stmt->fetch()['totalAnime'];

    // New users today
    $stmt = $pdo->prepare(
        "SELECT COUNT(id_web) AS penggunaBaru FROM users_web WHERE DATE(added) = :today"
    );
    $stmt->execute(['today' => $today]);
    $penggunaBaru = (int)$stmt->fetch()['penggunaBaru'];

    // Ambil 5 komentar terbaru berdasarkan ID
    $stmt = $pdo->prepare("
        SELECT c.id,
               c.anime_id,
               c.episode_id,
               c.telegram_id,
               c.comment,
               c.date_posting,
               u.first_name,
               u.profile_picture,
               u.last_seen,
               a.judul AS anime_title,
               a.image AS anime_image
        FROM (
            SELECT id FROM comments_app ORDER BY id DESC LIMIT 5
        ) AS latest
        JOIN comments_app AS c ON c.id = latest.id
        LEFT JOIN users_web AS u ON c.telegram_id = u.telegram_id
        LEFT JOIN anilist_data AS a ON c.anime_id = a.anime_id
        ORDER BY c.id DESC
    ");
    $stmt->execute();
    $komentarterbaru = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Ambil 5 pembelian premium terbaru dari tabel purchases
$stmt = $pdo->prepare("
    SELECT p.telegram_id,
           p.product_id,
           p.status,
           p.created_at,
           u.first_name,
           u.profile_picture,
           u.last_seen
    FROM (
        SELECT id FROM purchases WHERE status = 'active' ORDER BY id DESC LIMIT 5
    ) AS latest
    JOIN purchases AS p ON p.id = latest.id
    LEFT JOIN users_web AS u 
        ON CONVERT(p.telegram_id USING utf8mb4) COLLATE utf8mb4_unicode_ci = 
           CONVERT(u.telegram_id USING utf8mb4) COLLATE utf8mb4_unicode_ci
    ORDER BY p.id DESC
");

    $stmt->execute();
    $orderpremiumterbaru = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Build response
    echo json_encode([
        'status'              => 'success',
        'totalUser'           => $totalUser,
        'totalAnime'          => $totalAnime,
        'penggunaBaru'        => $penggunaBaru,
        'produkflue'          => 0,
        'pesananflue'         => 0,
        'komentarterbaru'     => $komentarterbaru,
        'orderpremiumterbaru'=> $orderpremiumterbaru
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>
