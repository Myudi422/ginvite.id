<?php

$curl = curl_init();
#d2bef6886dmshe4ef0f03fba99a6p16d1a4jsn3d19791a4c5a
#51b5f2bf8cmshe04982548ca669bp1d294fjsnc2a2b2dc08c6

curl_setopt_array($curl, [
    CURLOPT_URL => "https://premium-anime-mobile-wallpapers-illustrations.p.rapidapi.com/rapidHandler/premium?page=80&sensitivity=0&quality=1",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => "GET",
    CURLOPT_HTTPHEADER => [
        "X-RapidAPI-Host: premium-anime-mobile-wallpapers-illustrations.p.rapidapi.com",
        "X-RapidAPI-Key: 51b5f2bf8cmshe04982548ca669bp1d294fjsnc2a2b2dc08c6"
    ],
]);

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
    echo "cURL Error #:" . $err;
} else {
    // Terjemahkan respons JSON ke dalam array PHP
    $data = json_decode($response, true);

    // Koneksi ke database
    $conn = new mysqli("localhost", "ccgnimex", "aaaaaaac", "ccgnimex");

    // Periksa koneksi
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Loop melalui data dan lakukan penyisipan jika tidak ada duplikat
    foreach ($data as $wallpaper) {
        $art_id = $wallpaper['art_id'];
        $animename = $wallpaper['animename'];
        $arturl = $wallpaper['arturl'];
        $sensitivity = $wallpaper['sensitivity'];

        $check_duplicate = $conn->query("SELECT * FROM wallpaper_anime WHERE art_id = $art_id");

        if ($check_duplicate->num_rows == 0) {
            // Tambahkan data ke dalam tabel jika tidak ada duplikat
            $conn->query("INSERT INTO wallpaper_anime (art_id, animename, arturl, sensitivity) VALUES ($art_id, '$animename', '$arturl', $sensitivity)");
            echo "Data ditambahkan: $animename\n";
        } else {
            echo "Data sudah ada: $animename\n";
        }
    }

    // Tutup koneksi
    $conn->close();
}
?>
