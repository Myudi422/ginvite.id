<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");
// Koneksi ke database (gantilah dengan informasi koneksi sesuai dengan konfigurasi Anda)
$servername = "localhost";
$username = "ccgnimex";
$password = "aaaaaaac";
$database = "ccgnimex";

$conn = new mysqli($servername, $username, $password, $database);

// Periksa koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Ambil anime_id dari URL
if (isset($_GET['anime_id'])) {
    $anime_id = $_GET['anime_id'];

    // Query untuk mendapatkan detail anime berdasarkan anime_id
    $query = "SELECT * FROM anilist_data WHERE anime_id = $anime_id";
    $result = $conn->query($query);

    // Periksa apakah data ditemukan
    if ($result->num_rows > 0) {
        $anime_data = $result->fetch_assoc();

        // Konversi data ke format JSON
        $json_response = json_encode($anime_data);

        // Set header untuk memberitahu bahwa response adalah JSON
        header('Content-Type: application/json');

        // Tampilkan response JSON
        echo $json_response;
    } else {
        // Jika anime_id tidak ditemukan
        echo json_encode(array('error' => 'Anime tidak ditemukan'));
    }
} else {
    // Jika parameter anime_id tidak ada
    echo json_encode(array('error' => 'Parameter anime_id tidak ditemukan'));
}

// Tutup koneksi database
$conn->close();

?>
