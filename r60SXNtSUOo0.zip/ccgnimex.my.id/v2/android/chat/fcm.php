<?php

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

// Pastikan request yang diterima adalah metode POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Ambil data dari body request
    $email = $_POST['email'] ?? '';
    $fcmToken = $_POST['fcm_token'] ?? '';

    // Validasi data yang diterima
    if (!empty($email) && !empty($fcmToken)) {
        // Lakukan penyimpanan FCM token dalam database atau lakukan aksi lainnya
        // Di sini Anda bisa menggunakan database atau penyimpanan lainnya untuk menyimpan data FCM token
        
        // Contoh koneksi ke database MySQL
        $servername = "localhost";
        $username = "ccgnimex";
        $password = "aaaaaaac";
        $dbname = "ccgnimex";

        // Buat koneksi
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Periksa koneksi
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Lakukan penyimpanan FCM token dalam tabel pengguna
        $sql = "UPDATE users_web SET fcm_token='$fcmToken' WHERE email='$email'";

        if ($conn->query($sql) === TRUE) {
            echo "FCM token berhasil disimpan";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }

        $conn->close();
    } else {
        // Jika ada data yang tidak lengkap, kirim respon error
        http_response_code(400);
        echo "Gagal: Data tidak lengkap";
    }
} else {
    // Jika bukan metode POST, kirim respon error
    http_response_code(405);
    echo "Method Not Allowed";
}
?>
