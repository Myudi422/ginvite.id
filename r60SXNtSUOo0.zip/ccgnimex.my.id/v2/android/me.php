<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

// Koneksi ke database
$servername = "localhost";
$username = "ccgnimex";
$password = "aaaaaaac";
$dbname = "ccgnimex";

$conn = new mysqli($servername, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Ambil parameter telegram_id dari URL
$telegram_id = isset($_GET['telegram_id']) ? $conn->real_escape_string($_GET['telegram_id']) : '';

// Cek apakah telegram_id tidak kosong
if (!empty($telegram_id)) {
    // Query untuk mendapatkan data dari tabel users_web termasuk id_web berdasarkan telegram_id
    $sql = "SELECT id_web, first_name, profile_picture, banner_picture, akses, ditonton FROM users_web WHERE telegram_id = '$telegram_id'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Ambil data dan konversi ke array asosiatif
        $row = $result->fetch_assoc();

        // Tangani nilai null dan default untuk banner_picture
        $banner_picture = $row['banner_picture'] ?? 'https://i.pinimg.com/originals/77/1a/d6/771ad62880e17694923ae4f9b7dcace5.gif';



        // Query untuk menghitung jumlah favorite_anime berdasarkan telegram_id
        $sql_fav_anime = "SELECT COUNT(*) as favorite_anime FROM fav_anime WHERE telegram_id = '$telegram_id'";
        $result_fav_anime = $conn->query($sql_fav_anime);
        $favorite_anime_count = $result_fav_anime->fetch_assoc()['favorite_anime'] ?? 0;

        // Query untuk menghitung jumlah comment berdasarkan telegram_id
        $sql_comments = "SELECT COUNT(*) as comment FROM comments_app WHERE telegram_id = '$telegram_id'";
        $result_comments = $conn->query($sql_comments);
        $comment_count = $result_comments->fetch_assoc()['comment'] ?? 0;

        // Tangani nilai null dan default untuk ditonton
        $ditonton = $row['ditonton'] ?? '0:0:0';
        list($hours, $minutes, $seconds) = explode(':', $ditonton);
        $total_seconds = (is_numeric($hours) ? (int)$hours : 0) * 3600 +
                         (is_numeric($minutes) ? (int)$minutes : 0) * 60 +
                         (is_numeric($seconds) ? (int)$seconds : 0);

        // Menentukan level dan XP yang diperlukan untuk level berikutnya
        $watch_time_xp = ($total_seconds / 3600); // 1 XP per jam
        $comment_xp = floor($comment_count / 5); // 1 XP per 5 komentar

        $current_xp = $watch_time_xp + $comment_xp;
        $level = floor($current_xp);

        // Misalnya XP yang diperlukan untuk level berikutnya meningkat sebesar 100 XP per level
        $xp_for_next_level = ($level + 1) * 100; // Contoh: Level 1 memerlukan 100 XP, Level 2 memerlukan 200 XP, dll.

        // Hitung XP yang tersisa untuk mencapai level berikutnya
        $xp_needed_for_next_level = $xp_for_next_level - $current_xp;

        // Query untuk menghitung peringkat pengguna berdasarkan durasi tonton (ditonton)
        $sql_ranking = "
            SELECT telegram_id, FIND_IN_SET(ditonton, (
                SELECT GROUP_CONCAT(ditonton ORDER BY ditonton DESC) FROM users_web
            )) AS ranking 
            FROM users_web 
            WHERE telegram_id = '$telegram_id'
        ";
        $result_ranking = $conn->query($sql_ranking);
        $peringkat = $result_ranking->fetch_assoc()['ranking'] ?? 0;

        // Mengubah data menjadi JSON
        $response = [
            'id_web' => $row['id_web'],  // Tambahkan id_web ke dalam response
            'first_name' => $row['first_name'],
            'profile_picture' => $row['profile_picture'],
            'banner_picture' => $banner_picture,
            'akses' => $row['akses'],
            'ditonton' => $row['ditonton'],
            'favorite_anime' => $favorite_anime_count,
            'comment' => $comment_count,
            'peringkat' => $peringkat,
            'level' => $level,
            'xp_for_next_level' => $xp_for_next_level,
            'current_xp' => $current_xp,
            'xp_needed_for_next_level' => max(0, $xp_needed_for_next_level) // Jangan biarkan nilai negatif
        ];

        // Mengirimkan response JSON
        header('Content-Type: application/json');
        echo json_encode($response);
    } else {
        // Jika tidak ada data yang ditemukan
        echo json_encode(['error' => 'Data tidak ditemukan']);
    }
} else {
    // Jika parameter telegram_id kosong
    echo json_encode(['error' => 'Parameter telegram_id tidak ditemukan']);
}

// Menutup koneksi database
$conn->close();
?>
