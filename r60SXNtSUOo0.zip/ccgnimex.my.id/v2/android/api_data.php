<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");


$json = file_get_contents('php://input');
$data = json_decode($json, true);

if ($data['title'] !== null) {
  try {
    $pdo = new PDO('mysql:host=localhost;dbname=your_database', 'your_username', 'your_password');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $stmt = $pdo->prepare('INSERT INTO anime_data (title, image) VALUES (?, ?)');
    $stmt->execute([$data['title'], $data['image']]);
  } catch (PDOException $e) {
    echo 'Connection failed: ' . $e->getMessage();
    http_response_code(500);
    exit();
  }

  header('Content-Type: application/json');
  echo json_encode(['status' => 'success']);
} else {
  echo 'Error: Anime title is null. Data not saved.';
  http_response_code(400);
}
