<?php
// Informasi koneksi database
$host = 'localhost'; // Ganti dengan host database Anda
$username = 'ccgnimex'; // Ganti dengan username database Anda
$password = 'aaaaaaac'; // Ganti dengan password database Anda
$database = 'ccgnimex'; // Ganti dengan nama database Anda

// Membuat koneksi ke database
$mysqli = new mysqli($host, $username, $password, $database);

// Memeriksa apakah koneksi berhasil
if ($mysqli->connect_error) {
    die("Koneksi ke database gagal: " . $mysqli->connect_error);
}

// Mendapatkan nilai query dari permintaan POST
$query = $_POST['query'];

// Memeriksa apakah checkbox "Tersedia" dicentang
$isAvailable = isset($_POST['isAvailable']) ? $_POST['isAvailable'] : false;

// Membuat query SQL berdasarkan isAvailable
if ($isAvailable) {
    $sql = "SELECT * FROM nonton WHERE anime_id LIKE '%$query%'";
} else {
    // Query untuk mencari di AniList jika "Tersedia" tidak dicentang
    // Anda harus mengganti ini dengan logika Anda sendiri untuk mengambil data dari AniList
    $sql = "SELECT * FROM anime WHERE nama LIKE '%$query%'";
}

// Menjalankan query
$result = $mysqli->query($sql);

if ($result) {
    // Menghasilkan data sebagai JSON untuk digunakan dalam JavaScript
    $data = [];
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
    echo json_encode($data);
} else {
    echo 'Error: ' . $mysqli->error;
}

// Menutup koneksi database
$mysqli->close();
?>
