<?php
// Koneksi ke database
$servername = "localhost";
$username = "ccgnimex";
$password = "aaaaaaac";
$dbname = "ccgnimex";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Koneksi ke database gagal: " . $conn->connect_error);
}

// Menerima anime_ids dari JavaScript
$animeIds = json_decode(file_get_contents('php://input'));

// Inisialisasi array untuk menyimpan status ketersediaan anime_id
$animeAvailability = array();

foreach ($animeIds as $animeId) {
    $sql = "SELECT anime_id FROM nonton WHERE anime_id = '$animeId'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Jika anime_id tersedia, tambahkan ke array dengan status "available"
        $animeAvailability[$animeId] = "available";
    } else {
        // Jika anime_id tidak tersedia, tambahkan ke array dengan status "unavailable"
        $animeAvailability[$animeId] = "unavailable";
    }
}

// Mengirim respons sebagai JSON
echo json_encode($animeAvailability);

$conn->close();
?>