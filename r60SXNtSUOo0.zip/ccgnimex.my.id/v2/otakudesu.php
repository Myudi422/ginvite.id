<?php
// Koneksi Database
$host = 'localhost';
$dbname = 'ccgnimex';
$user = 'ccgnimex';
$password = 'aaaaaaac';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Koneksi gagal: " . $e->getMessage());
}

// --- PROSES DELETE ---
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $stmt = $pdo->prepare("DELETE FROM otakudesu WHERE id = ?");
    $stmt->execute([$id]);
    header('Location: otakudesu.php');
    exit();
}

// --- PENGATURAN AWAL UNTUK FORM ---
$anime_id = '';
$slug = '';
$editMode = false;
$edit_id = '';

// Jika ada parameter edit, ambil data record untuk diedit
if (isset($_GET['edit'])) {
    $editMode = true;
    $edit_id = $_GET['edit'];
    $stmt = $pdo->prepare("SELECT * FROM otakudesu WHERE id = ?");
    $stmt->execute([$edit_id]);
    $record = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($record) {
        $anime_id = $record['anime_id'];
        $slug = $record['slug'];
    }
}

// --- PROSES CREATE & UPDATE ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Jika ada input id, berarti update
    if (isset($_POST['id']) && !empty($_POST['id'])) {
        $id = $_POST['id'];
        $anime_id = $_POST['anime_id'];
        $slug = $_POST['slug'];
        try {
            $stmt = $pdo->prepare("UPDATE otakudesu SET anime_id = ?, slug = ? WHERE id = ?");
            $stmt->execute([$anime_id, $slug, $id]);
            echo "<p class='text-green-500 text-center'>Data berhasil diperbarui.</p>";
        } catch (Exception $e) {
            echo "<p class='text-red-500 text-center'>Error: " . $e->getMessage() . "</p>";
        }
    } else {
        // Insert data baru
        $anime_id = $_POST['anime_id'];
        $slug = $_POST['slug'];
        try {
            $stmt = $pdo->prepare("INSERT INTO otakudesu (anime_id, slug) VALUES (?, ?)");
            $stmt->execute([$anime_id, $slug]);
            echo "<p class='text-green-500 text-center'>Data berhasil disimpan.</p>";
        } catch (Exception $e) {
            echo "<p class='text-red-500 text-center'>Error: " . $e->getMessage() . "</p>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Otakudesu Management</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body class="bg-gray-100 font-sans p-6">
  <div class="container mx-auto bg-white p-6 rounded-lg shadow-lg">
    <h1 class="text-2xl font-bold mb-6 text-center">Otakudesu Management</h1>

    <!-- Tab Bar -->
    <div class="flex mb-6">
      <button class="tab-button px-4 py-2 bg-blue-500 text-white rounded-l-lg" data-target="#input-tab">+ Input</button>
      <button class="tab-button px-4 py-2 bg-gray-200 rounded-r-lg" data-target="#manage-tab">Manage</button>
    </div>

    <!-- Input Tab -->
    <div id="input-tab" class="tab-content block">
      <form action="otakudesu.php" method="POST" class="space-y-6">
        <?php if ($editMode): ?>
          <input type="hidden" name="id" value="<?php echo htmlspecialchars($edit_id); ?>">
        <?php endif; ?>

        <!-- Section: Search Anime via Anilist -->
        <div class="p-4 border rounded">
          <label for="anime_search" class="block font-medium mb-2">Search Anime (Judul):</label>
          <input type="text" id="anime_search" class="border p-2 rounded w-full" placeholder="Masukkan judul anime">
          <button type="button" onclick="searchAnime()" class="mt-2 bg-blue-500 text-white px-4 py-2 rounded">Cari Anime</button>
          <div id="search_results" class="mt-4"></div>
        </div>

        <!-- Field untuk Anime ID -->
        <div>
          <label for="anime_id" class="block font-medium">Anime ID:</label>
          <input type="text" name="anime_id" id="anime_id" class="border p-2 rounded w-full" value="<?php echo htmlspecialchars($anime_id); ?>" required>
        </div>

        <!-- Section: Search Slug via API -->
        <div class="p-4 border rounded">
          <label for="slug_search" class="block font-medium mb-2">Search Slug (Judul):</label>
          <input type="text" id="slug_search" class="border p-2 rounded w-full" placeholder="Masukkan judul anime untuk slug">
          <button type="button" onclick="searchSlug()" class="mt-2 bg-blue-500 text-white px-4 py-2 rounded">Cari Slug</button>
          <div id="slug_search_results" class="mt-4"></div>
        </div>

        <!-- Field untuk Slug -->
        <div>
          <label for="slug" class="block font-medium">Slug:</label>
          <input type="text" name="slug" id="slug" class="border p-2 rounded w-full" value="<?php echo htmlspecialchars($slug); ?>" required>
        </div>

        <button type="submit" class="bg-green-500 text-white px-6 py-2 rounded">
          <?php echo $editMode ? 'Update' : 'Submit'; ?>
        </button>
      </form>
    </div>

 <!-- Manage Tab -->
    <div id="manage-tab" class="tab-content hidden">
      <table class="table-auto w-full border-collapse border border-gray-300">
        <thead>
          <tr>
            <th class="border border-gray-300 px-4 py-2">ID</th>
            <th class="border border-gray-300 px-4 py-2">Anime ID</th>
            <th class="border border-gray-300 px-4 py-2">Slug</th>
            <th class="border border-gray-300 px-4 py-2">Actions</th>
            <th class="border border-gray-300 px-4 py-2">Reload</th> <!-- Kolom baru untuk tombol Reload -->
          </tr>
        </thead>
        <tbody>
<?php
$stmt = $pdo->query("SELECT * FROM otakudesu");
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    echo "<tr>
            <td class='border border-gray-300 px-4 py-2'>" . htmlspecialchars($row['id']) . "</td>
            <td class='border border-gray-300 px-4 py-2'>" . htmlspecialchars($row['anime_id']) . "</td>
            <td class='border border-gray-300 px-4 py-2'>" . htmlspecialchars($row['slug']) . "</td>
            <td class='border border-gray-300 px-4 py-2'>
                <a href='otakudesu.php?edit=" . htmlspecialchars($row['id']) . "' class='text-blue-500 mr-2'>Edit</a>
                <a href='otakudesu.php?delete=" . htmlspecialchars($row['id']) . "' onclick='return confirm(\"Yakin hapus data ini?\")' class='text-red-500'>Delete</a>
            </td>
            <td class='border border-gray-300 px-4 py-2'>
                <button onclick=\"reloadSlug('" . htmlspecialchars($row['slug']) . "')\" class=\"bg-green-500 text-white px-3 py-1 rounded\">Reload</button>
            </td>
          </tr>";
}
?>



        </tbody>
      </table>
    </div>
  </div>

   <script>
    // Fungsi untuk mengatur tab (Input & Manage)
    document.addEventListener('DOMContentLoaded', () => {
      const tabs = document.querySelectorAll('.tab-button');
      const tabContents = document.querySelectorAll('.tab-content');

      tabs.forEach(tab => {
        tab.addEventListener('click', () => {
          // Reset tampilan tab dan kontennya
          tabs.forEach(t => t.classList.replace('bg-blue-500', 'bg-gray-200'));
          tabContents.forEach(tc => tc.classList.add('hidden'));

          // Tampilkan tab dan konten yang dipilih
          tab.classList.replace('bg-gray-200', 'bg-blue-500');
          document.querySelector(tab.dataset.target).classList.remove('hidden');
        });
      });
    });

function reloadSlug(slug) {
  if (!slug) {
    Swal.fire({
      title: 'Gagal!',
      text: 'Parameter slug tidak boleh kosong.',
      icon: 'error',
      confirmButtonText: 'OK'
    });
    return;
  }

  const url = `https://ccgnimex.my.id/v2/otakudesu_upload.php?slug=${slug}`;

  // Tampilkan popup loading
  Swal.fire({
    title: 'Memproses...',
    text: 'Sedang melakukan reload, harap tunggu...',
    allowOutsideClick: false,
    didOpen: () => {
      Swal.showLoading();
    }
  });

  // Kirim request ke server
  fetch(url)
    .then(response => response.json())  // Pastikan response dikonversi ke JSON
    .then(data => {
      if (data.error) {
        throw new Error(data.error); // Tangkap error dari server
      }
      Swal.fire({
        title: 'Berhasil!',
        text: `Reload untuk slug "${slug}" berhasil dilakukan!`,
        icon: 'success',
        confirmButtonText: 'OK'
      });
    })
    .catch(error => {
      Swal.fire({
        title: 'Gagal!',
        text: `Terjadi kesalahan: ${error.message}`,
        icon: 'error',
        confirmButtonText: 'OK'
      });
    });
}



    // Fungsi pencarian anime via Anilist GraphQL API
    function searchAnime() {
      const query = document.getElementById('anime_search').value;
      fetch('https://graphql.anilist.co', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: `
            query ($search: String) {
              Page(perPage: 5) {
                media(search: $search, type: ANIME) {
                  id
                  title {
                    romaji
                    english
                  }
                  coverImage {
                    medium
                  }
                }
              }
            }
          `,
          variables: { search: query }
        })
      })
      .then(response => response.json())
      .then(data => {
        const resultsDiv = document.getElementById('search_results');
        resultsDiv.innerHTML = '';

        if (data.data && data.data.Page.media.length > 0) {
          data.data.Page.media.forEach(anime => {
            const animeDiv = document.createElement('div');
            animeDiv.classList.add('anime-item', 'mb-4', 'p-2', 'border', 'rounded');
            animeDiv.innerHTML = `
              <div class="flex items-center space-x-4">
                <img src="${anime.coverImage.medium}" alt="${anime.title.romaji || anime.title.english}" class="w-16 h-20 object-cover">
                <div>
                  <p class="font-medium">${anime.title.romaji || anime.title.english}</p>
                  <p class="text-sm text-gray-600">ID: ${anime.id}</p>
                  <button type="button" onclick="selectAnime(${anime.id})" class="mt-2 bg-blue-500 text-white px-3 py-1 rounded text-sm">Select</button>
                </div>
              </div>
            `;
            resultsDiv.appendChild(animeDiv);
          });
        } else {
          resultsDiv.innerHTML = '<p class="text-red-500">No results found</p>';
        }
      })
      .catch(error => {
        console.error('Error fetching data:', error);
        document.getElementById('search_results').innerHTML = '<p class="text-red-500">An error occurred while fetching data</p>';
      });
    }

    // Fungsi untuk mengisi field anime_id dari hasil pencarian Anilist
    function selectAnime(animeId) {
      document.getElementById('anime_id').value = animeId;
    }

    function searchSlug() {
      const keyword = document.getElementById('slug_search').value;
      fetch(`https://ccgnimex.my.id/v2/otakudesu_proxy.php/search/?keyword=${encodeURIComponent(keyword)}`)
        .then(response => response.json())
        .then(data => {
          const resultsDiv = document.getElementById('slug_search_results');
          resultsDiv.innerHTML = '';

          // Pastikan response memiliki data yang benar
          if (data && data.data && data.data.data && Array.isArray(data.data.data) && data.data.data.length > 0) {
            data.data.data.forEach(item => {
              const itemDiv = document.createElement('div');
              itemDiv.classList.add('slug-item', 'mb-4', 'p-2', 'border', 'rounded');
              itemDiv.innerHTML = `
                <div class="flex items-center space-x-4">
                  <img src="${item.cover}" alt="${item.judul}" class="w-16 h-20 object-cover">
                  <div>
                    <p class="font-medium">${item.judul}</p>
                    <p class="text-sm text-gray-600">Slug: ${item.data}</p>
                    <button type="button" onclick="selectSlug('${item.data}')" class="mt-2 bg-blue-500 text-white px-3 py-1 rounded text-sm">Select</button>
                  </div>
                </div>
              `;
              resultsDiv.appendChild(itemDiv);
            });
          } else {
            resultsDiv.innerHTML = '<p class="text-red-500">No results found</p>';
          }
        })
        .catch(error => {
          console.error('Error fetching slug data:', error);
          document.getElementById('slug_search_results').innerHTML = '<p class="text-red-500">An error occurred while fetching data</p>';
        });
    }

    // Fungsi untuk mengisi field slug dari hasil pencarian slug
    function selectSlug(slugValue) {
      document.getElementById('slug').value = slugValue;
    }
  </script>
</body>
</html>
