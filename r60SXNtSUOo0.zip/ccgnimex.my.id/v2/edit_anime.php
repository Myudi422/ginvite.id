<?php
// Inisialisasi sesi
session_start();

// Mengambil ID Telegram dari sesi
$telegram_id = $_SESSION['telegram_id'];

// Membuat koneksi ke database (gantilah dengan detail koneksi Anda)
$servername = "localhost";
$username = "ccgnimex";
$password = "aaaaaaac";
$dbname = "ccgnimex";

$db = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);

// Periksa koneksi database
if (!$db) {
    die("Koneksi database gagal: " . $db->errorInfo());
}

// Query ke database untuk memeriksa apakah ID Telegram ada dalam tabel "admins"
$sql = "SELECT * FROM admins WHERE telegram_id = $telegram_id";
$result = $db->query($sql);

$show_edit_icon = false;

if ($result->rowCount() > 0) {
    $show_edit_icon = true;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Terima data dari permintaan POST
    $anime_id = $_POST['anime_id'];
    $episode_links_en = $_POST['episode_links_en'];
    // Add other form fields here

    // Lakukan validasi atau pemrosesan data di sini
    // Contoh validasi sederhana:
    if (empty($anime_id) || empty($episode_links_en)) {
        echo 'Data tidak lengkap. Silakan isi semua kolom.';
    } else {
        // Simpan data ke database atau lakukan tindakan lain sesuai kebutuhan

        // Jika berhasil, berikan respons berhasil
        echo 'Data berhasil diproses!';
    }
} else {
    // Tangani kasus jika permintaan bukan POST
    http_response_code(405); // Method Not Allowed
    echo 'Metode permintaan tidak diizinkan.';
}
?>
