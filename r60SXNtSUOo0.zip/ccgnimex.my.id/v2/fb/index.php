
<?php
// Allow cross-origin requests
header("Access-Control-Allow-Origin: *"); // Allows requests from any origin
header("Access-Control-Allow-Methods: POST, GET, OPTIONS"); // Allowed methods
header("Access-Control-Allow-Headers: Content-Type"); // Allowed headers
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Video Upload Form</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <script>
        function detectSource() {
            const urlInput = document.getElementById('video_url').value;
            const sourceInput = document.getElementById('source');
            
            if (urlInput.includes('tiktok.com')) {
                sourceInput.value = 'tiktok';
            } else if (urlInput.includes('instagram.com')) {
                sourceInput.value = 'instagram';
            } else {
                sourceInput.value = '';
            }
        }
    </script>
</head>
<body class="bg-gray-100 flex items-center justify-center min-h-screen">
    <div class="bg-white p-8 rounded-lg shadow-lg max-w-lg w-full">
        <h1 class="text-2xl font-bold mb-6">Upload Video</h1>
        <form action="process.php" method="post">
            <div class="mb-4 hidden">
                <label for="source" class="block text-sm font-medium text-gray-700">Sumber Video</label>
                <input type="text" id="source" name="source" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm" readonly>
            </div>
            <div class="mb-4">
                <label for="video_url" class="block text-sm font-medium text-gray-700">URL Video</label>
                <input type="text" id="video_url" name="video_url" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm" required oninput="detectSource()">
            </div>
            <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded-md shadow-sm hover:bg-blue-600">Proses Video</button>
        </form>
    </div>
</body>
</html>