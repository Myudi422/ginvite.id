<?php
// Facebook Page ID dan Access Token
$facebookPageId = "105399211074001";
$instagramUserId = "17841465554852884";
$accessToken = "EAAaDZBSQqMQIBO4pMfnNW5EZBCgqPhXvFoCEuvmIgAOnotASZAZAZCiFZBYfSen5HcQuHpot5wQBPpcDOfgM8rkl86ADfc4CPHJj3A0EW77HAb0M8tTS76kax95MZAZB7sz4nEyie5KjvGXTGNtzpruxUZCxeK2yGc5hZAlZAZBi5oJVZCB3zZCwFKy9bXYnDxgXNrZBxQZD";

// Mendapatkan URL dan sumber dari form
$source = $_POST['source']; // "tiktok" atau "instagram"
$videoUrl = $_POST['video_url'];

// API untuk mendapatkan data video
$apiUrls = [
    'tiktok' => "https://api.ryzendesu.vip/api/downloader/ttdl?url=" . urlencode($videoUrl),
    'instagram' => "https://api.ryzendesu.vip/api/downloader/igdl?url=" . urlencode($videoUrl)
];

if (!isset($apiUrls[$source])) {
    die("Error: Sumber tidak valid.");
}

$apiUrl = $apiUrls[$source];

// Menggunakan CURL untuk mengambil data API
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    'Accept: application/json',
    'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
    'Cookie: your_cookie_here' // jika diperlukan
));
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

// Mengecek status HTTP
if ($httpCode != 200) {
    die("Error: Tidak dapat mengakses API. Status Code: " . $httpCode);
}

// Decode respons JSON
$data = json_decode($response, true);

// Anda bisa menggunakan informasi tentang BMW M3 GTR di platform lain, seperti Instagram
$infoBMW = "The BMW M3 GTR is an iconic racing car renowned for its exceptional performance and aggressive styling. Equipped with a potent 4.0-liter V8 engine, it generates over 450 horsepower.

With a 0-100 km/h acceleration time of just around 4 seconds, the M3 GTR boasts an impressive top speed exceeding 280 km/h.🏎️

Featuring state-of-the-art aerodynamics and innovative handling technologies, the M3 GTR delivers unparalleled stability and precision, especially on the track.🧏

Originally priced at approximately $1.3 million, the BMW M3 GTR stands as a symbol of high-performance engineering and automotive excellence.💥

Its limited production run of only ten units adds to its allure, making it highly coveted by racing aficionados and collectors worldwide.🌍";

// Fungsi untuk mendapatkan emotikon acak
function getRandomEmoticon() {
    $emoticons = ['😄', '🔥', '🎉', '💥', '🌟', '🚀', '🎶', '💎', '✨', '🎬']; // Tambahkan lebih banyak jika diperlukan
    return $emoticons[array_rand($emoticons)];
}

// Periksa apakah API merespons dengan sukses
if ($source == 'tiktok') {
    if ($data['code'] != 0) {
        die("Error: Data tidak valid atau tidak ditemukan.");
    }
    $videoUrl = $data['data']['hdplay'];
    $title = $data['data']['title'];
} elseif ($source == 'instagram') {
    if (!$data['status']) {
        die("Error: Data tidak valid.");
    }
    $videoUrl = $data['data'][0]['url'];
    $title = getRandomEmoticon(); // Ganti dengan emotikon acak untuk Instagram
}

// Fungsi untuk mengecek apakah video sudah diunggah sebelumnya
function isVideoUploaded($videoUrl, $platform) {
    // Gantilah dengan mekanisme penyimpanan dan pengecekan yang sesuai (misalnya database atau file log)
    // Sebagai contoh, kita akan menyimpan log di file 'upload_log.txt'
    $logFile = 'upload_log.txt';
    $logData = file_exists($logFile) ? file($logFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) : [];

    // Membuat hash dari URL video dan platform untuk disimpan di log
    $videoHash = md5($videoUrl . $platform);

    return in_array($videoHash, $logData);
}

// Fungsi untuk menyimpan log setelah video berhasil diunggah
function logVideoUpload($videoUrl, $platform) {
    // Gantilah dengan mekanisme penyimpanan dan pengecekan yang sesuai (misalnya database atau file log)
    $logFile = 'upload_log.txt';
    $videoHash = md5($videoUrl . $platform);
    file_put_contents($logFile, $videoHash . PHP_EOL, FILE_APPEND);
}

// Cek apakah video sudah diunggah ke Facebook
if (isVideoUploaded($videoUrl, 'facebook')) {
    die("Error: Video sudah diunggah ke Facebook.");
}

// Upload video ke Facebook
$uploadUrlFacebook = "https://graph-video.facebook.com/v20.0/$facebookPageId/videos";
$videoDataFacebook = [
    'file_url' => $videoUrl,
    'title' => $title,
    'access_token' => $accessToken
];

// Menggunakan CURL untuk upload video ke Facebook
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $uploadUrlFacebook);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $videoDataFacebook);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$responseFacebook = curl_exec($ch);
$httpCodeFacebook = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

// Mengecek status HTTP Facebook
if ($httpCodeFacebook != 200) {
    echo "<pre>Facebook Upload Error: " . htmlspecialchars(json_encode($responseFacebook, JSON_PRETTY_PRINT)) . "</pre>";
    die("Error: Tidak dapat mengupload video ke Facebook. Status Code: " . $httpCodeFacebook);
}

// Simpan log setelah berhasil upload ke Facebook
logVideoUpload($videoUrl, 'facebook');

// Cek apakah video sudah diunggah ke Instagram
if (isVideoUploaded($videoUrl, 'instagram')) {
    die("Error: Video sudah diunggah ke Instagram.");
}

// Upload video ke Instagram Reels
$uploadUrlInstagram = "https://graph.facebook.com/v20.0/$instagramUserId/media";
$videoDataInstagram = [
    'media_type' => 'REELS',
    'video_url' => $videoUrl,
    'caption' => $infoBMW,
    'access_token' => $accessToken
];

// Menggunakan CURL untuk upload video ke Instagram Reels
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $uploadUrlInstagram);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $videoDataInstagram);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$responseInstagram = curl_exec($ch);
$httpCodeInstagram = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

$responseDataInstagram = json_decode($responseInstagram, true);

// Mengecek status HTTP Instagram
if ($httpCodeInstagram != 200) {
    echo "<pre>Instagram Upload Error: " . htmlspecialchars(json_encode($responseDataInstagram, JSON_PRETTY_PRINT)) . "</pre>";
    die("Error: Tidak dapat mengupload video ke Instagram Reels. Status Code: " . $httpCodeInstagram);
}

$creationId = $responseDataInstagram['id'] ?? null;

if ($creationId) {
    // Tambahkan delay sebelum melakukan publikasi
    sleep(40); // Tunggu selama 60 detik

    // Publikasi media setelah upload dengan opsi untuk membagikan ke Facebook Fanpage
    $publishUrlInstagram = "https://graph.facebook.com/v20.0/$instagramUserId/media_publish";
    $publishDataInstagram = [
        'creation_id' => $creationId,
        'access_token' => $accessToken,
        'share_to_feed' => true // Membagikan Reels ke Facebook Fanpage secara default
    ];

    // Menggunakan CURL untuk publikasi video ke Instagram Reels
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $publishUrlInstagram);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $publishDataInstagram);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $publishResponseInstagram = curl_exec($ch);
    $httpCodePublishInstagram = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    // Mengecek status HTTP Publikasi Instagram
    if ($httpCodePublishInstagram != 200) {
        echo "<pre>Instagram Publish Error: " . htmlspecialchars(json_encode($publishResponseInstagram, JSON_PRETTY_PRINT)) . "</pre>";
        die("Error: Tidak dapat mempublikasikan video ke Instagram Reels. Status Code: " . $httpCodePublishInstagram);
    }

    echo "<pre>Instagram Reels berhasil dipublikasikan.</pre>";
} else {
    die("Error: Tidak dapat mengunggah video ke Instagram Reels.");
}

// Simpan log setelah berhasil upload ke Instagram
logVideoUpload($videoUrl, 'instagram');

echo "<pre>Facebook Response: " . htmlspecialchars($responseFacebook) . "</pre>";
echo "<pre>Instagram Upload Response: " . htmlspecialchars($responseInstagram) . "</pre>";
echo "<pre>Instagram Publish Response: " . htmlspecialchars($publishResponseInstagram) . "</pre>";
?>
