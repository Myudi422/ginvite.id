
<style>
    /* Hide scrollbar for Chrome, Safari and Opera */
    #pilihanAnimeGrid::-webkit-scrollbar {
        display: none;
    }

    /* Hide scrollbar for IE, Edge and Firefox */
    #pilihanAnimeGrid {
        -ms-overflow-style: none;  /* IE and Edge */
        scrollbar-width: none;  /* Firefox */
    }
</style>

<?php
$pilihanHost = '127.0.0.1';
$pilihanUser = 'ccgnimex';
$pilihanPassword = 'aaaaaaac';
$pilihanDbname = 'ccgnimex';

$pilihanConn = new mysqli($pilihanHost, $pilihanUser, $pilihanPassword, $pilihanDbname);

if ($pilihanConn->connect_error) {
    die('Connection failed: ' . $pilihanConn->connect_error);
}

$pilihanSql = 'SELECT anime_id FROM nonton';
$pilihanResult = $pilihanConn->query($pilihanSql);

$pilihanAnimeIds = [];
if ($pilihanResult->num_rows > 0) {
    while ($row = $pilihanResult->fetch_assoc()) {
        $pilihanAnimeIds[] = $row['anime_id'];
    }
}

$pilihanConn->close();
?>

<section class="mt-5 px-4">
    <div class="flex justify-between items-center mb-4">
        <h2 class="text-2xl font-bold flex items-center">
            <span class="bg-purple-500 text-white rounded-full p-1 text-xs mr-2">
                <i class="fas fa-meteor text-xs"></i>
            </span>
            Saran Anime
        </h2>
    </div>
    <div id="pilihanAnimeGrid" class="flex flex-row space-x-4 overflow-x-scroll scrollbar-hide py-2" style="white-space: nowrap;">
        <!-- Anime cards will be populated here by the JavaScript -->
    </div>
</section>

<script>
const pilihanMaxPage = 50;
const pilihanPerPage = 7;
let pilihanAnimeData = []; // Store anime data on the server

const pilihanQuery = `
  query ($id_in: [Int], $page: Int, $perPage: Int) {
    Page (page: $page, perPage: $perPage) {
      pageInfo {
        total
        currentPage
        lastPage
        hasNextPage
        perPage
      }
      media (id_in: $id_in, type: ANIME, status: FINISHED, sort: TRENDING_DESC) {
        id
        title {
          romaji
        }
        coverImage {
          large
        }
        averageScore
        popularity
        trailer {
          site
          id
        }
      }
    }
  }
`;

const pilihanUrl = 'https://graphql.anilist.co';

// Function to fetch random anime recommendations
async function fetchRandomAnimeRecommendations() {
  // Shuffle the anime data to get a random order
  const shuffledData = pilihanAnimeData.slice();
  for (let i = shuffledData.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffledData[i], shuffledData[j]] = [shuffledData[j], shuffledData[i]];
  }

  // Display the first 7 shuffled anime
  const recommendations = shuffledData.slice(0, pilihanPerPage);

  // Render anime recommendations on the web page
  const pilihanAnimeGrid = document.getElementById("pilihanAnimeGrid");
  pilihanAnimeGrid.innerHTML = "";
  recommendations.forEach(anime => {
    let formattedPopularity = anime.popularity !== null && typeof anime.popularity !== 'undefined' ? pilihanFormatPopularity(anime.popularity) : 'N/A';
    let trailerIcon = anime.trailer && anime.trailer.site === 'youtube' ?
      `<a href="https://www.youtube.com/watch?v=${anime.trailer.id}" class="popup-youtube absolute top-0 right-0 bg-blue-500 text-white p-1 rounded-tl rounded-bl text-xs"><i class="fas fa-video"></i></a>` : '';
    // Add a link to the streaming.php page with the corresponding anime_id
    pilihanAnimeGrid.innerHTML += `
      <a href="streaming.php?anime_id=${anime.id}">
        <div class="inline-block rounded overflow-hidden shadow-lg m-2" style="min-width: 150px; max-width: 250px; flex: 1; margin-left: 5px;">
          <div class="relative">
            <div class="absolute top-0 left-0 bg-black bg-opacity-50 text-white p-1 rounded-tr rounded-br text-xs">${anime.averageScore !== null && typeof anime.averageScore !== 'undefined' ? anime.averageScore + '%' : 'N/A'}</div>
            ${trailerIcon}
            <div class="absolute bottom-0 left-0 bg-red-500 text-white p-1 rounded-tr text-xs"><i class="fas fa-fire text-xs"></i> ${formattedPopularity}</div>
            <a href="streaming.php?anime_id=${anime.id}">
              <img class="w-full h-48 object-cover" src="${anime.coverImage.large}" alt="${anime.title.romaji}" loading="lazy">
            </a>
          </div>
          <div class="px-6 py-4">
            <div class="font-bold text-sm md:text-xl mb-2 truncate">${anime.title.romaji}</div>
          </div>
        </div>
      </a>
    `;
  });

  $('.popup-youtube').magnificPopup({
    type: 'iframe',
    mainClass: 'mfp-fade',
    removalDelay: 160,
    preloader: false,
    fixedContentPos: false
  });
}

// Function to fetch and cache anime data on the server
async function fetchAndCacheAnimeData() {
  // Fetch the anime data from the Anilist API
  const response = await fetch(pilihanUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    },
    body: JSON.stringify({
      query: pilihanQuery,
      variables: { id_in: <?php echo json_encode($pilihanAnimeIds); ?>, page: 1, perPage: pilihanMaxPage },
    }),
  });

  if (!response.ok) {
    throw new Error(`Server response not OK: ${response.status}`);
  }

  const data = await response.json();

  if (!data || !data.data || !data.data.Page || !data.data.Page.media) {
    throw new Error('Invalid data received from the server');
  }

  // Store the anime data on the server
  pilihanAnimeData = data.data.Page.media;
}

// Function to format popularity
function pilihanFormatPopularity(value) {
  if (value >= 1000) {
    return (value / 1000).toFixed(1) + 'K';
  }
  return value;
}

window.addEventListener("load", async function() {
  try {
    // Fetch and cache anime data on the server
    await fetchAndCacheAnimeData();
    // Fetch random anime recommendations and display them
    fetchRandomAnimeRecommendations();
  } catch (error) {
    console.error('Error:', error);
  }
});
</script>
