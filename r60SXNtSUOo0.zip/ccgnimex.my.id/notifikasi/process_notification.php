<?php
// Database connection
$db_host = "localhost";
$db_name = "ccgnimex";
$db_user = "ccgnimex";
$db_password = "aaaaaaac";

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $animeId = $_POST['anilist_id'];
    $episode = $_POST['episode'];

    // Find all telegram_ids for the given anime_id
    $telegramIdQuery = "SELECT telegram_id FROM add_notif WHERE anime_id = '$animeId'";
    $telegramIdResult = $conn->query($telegramIdQuery);

    while ($row = $telegramIdResult->fetch_assoc()) {
        $telegramId = $row['telegram_id'];

        // Insert notification into notif_anime
        $insertQuery = "INSERT INTO notif_anime (telegram_id, anilist_id, episode, notification_date, is_read)
                        VALUES ('$telegramId', '$animeId', $episode, NOW(), 0)";
        $conn->query($insertQuery);
    }

    echo "Notifikasi berhasil dikirim dan disimpan kepada semua pengguna dengan anime_id yang sesuai.";
}

$conn->close();
?>