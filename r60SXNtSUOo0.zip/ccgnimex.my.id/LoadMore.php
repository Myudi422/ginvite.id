<?php
// Set up Anilist API
$clientId = '10813';
$clientSecret = 'j4jtW20LRQ4YrA6ClvZu11E0VlTcghNZijwCJXoa';

// Get access token using client_credentials grant
$accessToken = getAccessToken($clientId, $clientSecret);

// Set up query and variables
$query = '
query ($page: Int, $perPage: Int, $genre_in: [String]) {
  Page (page: $page, perPage: $perPage) {
    media (genre_in: $genre_in) {
      id
      title {
        romaji
        english
        native
      }
      coverImage {
        large
      }
    }
  }
}
';

// Get current page and selected genres from URL or use default values
$currentPage = isset($_GET['page']) ? intval($_GET['page']) : 1;
$selectedGenres = isset($_GET['genres']) ? explode(',', $_GET['genres']) : ['Romance'];

// Set up variables for query
$variables = [
  'page' => $currentPage,
  'perPage' => 10,
  'genre_in' => $selectedGenres,
];

// Execute query and get results
$results = executeQuery($query, $variables, $accessToken);

// Display results in a grid using Bootstrap 4
foreach ($results['data']['Page']['media'] as $media) {
  echo '<div class="col-sm-6 col-md-4 col-lg-3">';
  echo '<div class="card">';
  echo '<img class="card-img-top" src="' . $media['coverImage']['large'] . '" alt="' . htmlspecialchars($media['title']['romaji']) . '">';
  echo '<div class="card-body">';
  echo '<h5 class="card-title">' . htmlspecialchars($media['title']['romaji']) . '</h5>';
  echo '</div>';
  echo '</div>';
  echo '</div>';
}

function getAccessToken($clientId, $clientSecret) {
  // Set up cURL
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, 'https://anilist.co/api/v2/oauth/token');
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch, CURLOPT_POST, true);
  curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
    'grant_type' => 'client_credentials',
    'client_id' => $clientId,
    'client_secret' => $clientSecret,
  ]));
   // Execute cURL request and get response
  $response = curl_exec($ch);
  curl_close($ch);

  // Decode JSON response and return access token
  return json_decode($response)->access_token;
}
function executeQuery($query, $variables, $accessToken) {
  // Set up cURL
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, 'https://graphql.anilist.co');
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch, CURLOPT_POST, true);
  curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Accept: application/json',
    'Authorization: Bearer ' . $accessToken,
  ]);
  curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
    'query' => $query,
    'variables' => $variables,
  ]));
   // Execute cURL request and get response
  $response = curl_exec($ch);
  curl_close($ch);

  // Decode JSON response and return data
  return json_decode($response,true);
}