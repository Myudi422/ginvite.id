<?php
// Ambil data dari permintaan POST
$anime_id = $_POST['anime_id'];
$telegram_id = $_POST['telegram_id'];

// Lakukan koneksi ke database
$connection = mysqli_connect("localhost", "ccgnimex", "aaaaaaac", "ccgnimex");

// Buat query untuk menghapus data dari tabel berdasarkan anime_id dan telegram_id
$query = "DELETE FROM add_notif WHERE anime_id = '$anime_id' AND telegram_id = '$telegram_id'";

// Jalankan query
if (mysqli_query($connection, $query)) {
    echo "Data berhasil dihapus dari database.";
} else {
    echo "Error: " . $query . "<br>" . mysqli_error($connection);
}

// Tutup koneksi
mysqli_close($connection);
?>
