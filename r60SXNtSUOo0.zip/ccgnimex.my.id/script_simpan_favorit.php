<?php
// Koneksi ke database (gantilah dengan informasi koneksi Anda)
$servername = "localhost";
$username = "ccgnimex";
$password = "aaaaaaac";
$dbname = "ccgnimex";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

if (isset($_POST['favorit'])) {
    $anime_id = $_POST['anime_id']; // Ganti dengan cara Anda mendapatkan ID anime
    $telegram_id = $telegram_id; // Ganti dengan cara Anda mendapatkan ID Telegram

    // Query untuk menyimpan data favorit ke dalam tabel
    $sql = "INSERT INTO favorit_web (anime_id, telegram_id) VALUES ('$anime_id', '$telegram_id')";

    if ($conn->query($sql) === TRUE) {
        echo "Anime berhasil ditambahkan ke favorit.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>