<?php
header('Access-Control-Allow-Origin: *');
date_default_timezone_set('Asia/Jakarta');

// Koneksi ke database
$servername = "localhost";
$username = "ccgnimex";
$password = "aaaaaaac";
$dbname = "ccgnimex";

$conn = new mysqli($servername, $username, $password, $dbname);

// Cek koneksi database
if ($conn->connect_error) {
    die("Koneksi database gagal: " . $conn->connect_error);
}

// Handle the validation update request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['updateValidation'])) {
    $server = $_POST['server'];
    $website = $_POST['website'];
    $platform = $_POST['platform'];
    $validation = $_POST['validation'];

    // Update the validation column for the given server, website, and platform
    $sql = "UPDATE cookies SET validasi = ? WHERE server = ? AND website = ? AND platform = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("issi", $validation, $server, $website, $platform);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        echo json_encode(array('status' => 'success'));
    } else {
        echo json_encode(array('status' => 'error', 'message' => 'Failed to update validation'));
    }
} else {
    echo json_encode(array('status' => 'error', 'message' => 'Invalid request'));
}

// Close the database connection
$conn->close();
?>
