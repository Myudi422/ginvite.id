<link href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.2.19/tailwind.min.css" rel="stylesheet">
<?php
date_default_timezone_set('Asia/Jakarta');
$host = 'localhost';
$db   = 'ccgnimex';
$user = 'ccgnimex';
$pass = 'aaaaaaac';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$pdo = new PDO($dsn, $user, $pass);

// Mengambil data Server tanpa duplikat
$query = $pdo->query("SELECT DISTINCT Server FROM cookies");
$servers = $query->fetchAll(PDO::FETCH_COLUMN);

$selectedServer = $_POST['server'] ?? $servers[0];  // Default ke server pertama jika belum ada yang dipilih

// Mengambil data Platform berdasarkan Server yang dipilih
$stmt = $pdo->prepare("SELECT DISTINCT Platform FROM cookies WHERE Server = ?");
$stmt->execute([$selectedServer]);
$platforms = $stmt->fetchAll(PDO::FETCH_COLUMN);

// Menghandle update jika form disubmit
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['platform'], $_POST['cookie_data'])) {
    $server = $_POST['server'];
    $platform = $_POST['platform'];
    $cookie_data = $_POST['cookie_data'];
    
    $currentTimestamp = date('Y-m-d H:i:s');  // Format tanggal dan waktu sesuai dengan yang diperlukan oleh MySQL
$stmt = $pdo->prepare("UPDATE cookies SET cookie_data = ?, timestamp = ? WHERE Server = ? AND Platform = ?");
$stmt->execute([$cookie_data, $currentTimestamp, $server, $platform]);
    // Anda bisa menambahkan logic untuk update website dan timestamp jika diperlukan
}


// Form dengan dropdown dan textarea
echo '<div class="bg-white p-6 rounded shadow-md w-96">';
echo '<h1 class="text-xl font-bold mb-4">Update Cookie Data</h1>';

echo '<form method="post" action="">';

// Dropdown Server
echo '<div class="mb-4">';
echo '<label for="server" class="block text-sm font-medium text-gray-700">Server</label>';
echo '<select id="server" name="server" class="mt-1 block w-full..." onchange="this.form.submit()">';
foreach ($servers as $server) {
    $selected = ($server == $selectedServer) ? 'selected' : '';
    echo '<option value="' . $server . '" ' . $selected . '>' . $server . '</option>';
}
echo '</select></div>';

// Dropdown Platform
echo '<div class="mb-4">';
echo '<label for="platform" class="block text-sm font-medium text-gray-700">Platform</label>';
echo '<select id="platform" name="platform" class="mt-1 block w-full...">';
foreach ($platforms as $platform) {
    echo '<option value="' . $platform . '">' . $platform . '</option>';
}
echo '</select></div>';

// Textarea untuk cookie data
echo '<div class="mb-4">';
echo '<label for="cookie_data" class="block text-sm font-medium text-gray-700">Cookie Data</label>';
echo '<textarea id="cookie_data" name="cookie_data" rows="4" class="mt-1 block w-full..."></textarea>';
echo '</div>';

// Tombol Submit
echo '<div>';
echo '<button type="submit" class="w-full bg-blue-500...">Update</button>';
echo '</div>';

echo '</form>';
echo '</div>';

?>