<?php
header('Access-Control-Allow-Origin: *');
// Koneksi ke database
$host = "localhost"; // Ganti dengan host Anda
$username = "ccgnimex"; // Ganti dengan username database Anda
$password = "aaaaaaac"; // Ganti dengan password database Anda
$database = "ccgnimex"; // Ganti dengan nama database Anda

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Koneksi ke database gagal: " . $conn->connect_error);
}

// Query untuk mengambil data gambar
$sql = "SELECT * FROM images";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $images = array();
    while ($row = $result->fetch_assoc()) {
        $images[] = $row['url'];
    }
    echo json_encode($images);
} else {
    echo "Tidak ada gambar yang ditemukan.";
}

$conn->close();
?>
