<?php
// Get raw POST data
$rawData = file_get_contents('php://input');

// Decode JSON data
$data = json_decode($rawData, true);
$cookieData = $data['cookieData'];
$website = $data['website'];

// Check if cookie data and website were received correctly
if ($cookieData && $website) {
    // Create a connection to your SQL database
    $servername = "localhost";
    $username = "ccgnimex";
    $password = "aaaaaaac";
    $dbname = "ccgnimex";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection to the database failed: " . $conn->connect_error);
    }

    $cookieJson = json_encode($cookieData);

    // Check if a record with the same website URL exists
    $existingRecord = $conn->query("SELECT * FROM cookies WHERE website = '$website'");

    if ($existingRecord->num_rows > 0) {
        // Update the existing record
        $stmt = $conn->prepare("UPDATE cookies SET cookie_data = ? WHERE website = ?");
        $stmt->bind_param("ss", $cookieJson, $website);

        // Execute the statement
        if ($stmt->execute() === TRUE) {
            echo "Cookie data for $website successfully updated in the database.<br>";
        } else {
            echo "Error for $website: " . $stmt->error . "<br>";
        }
        $stmt->close();
    } else {
        // No existing record, insert a new record
        $stmt = $conn->prepare("INSERT INTO cookies (website, cookie_data) VALUES (?, ?)");
        $stmt->bind_param("ss", $website, $cookieJson);

        // Execute the statement
        if ($stmt->execute() === TRUE) {
            echo "Cookie data for $website successfully inserted into the database.<br>";
        } else {
            echo "Error for $website: " . $stmt->error . "<br>";
        }
        $stmt->close();
    }

    // Close the database connection
    $conn->close();
} else {
    echo "Cookie data or website not received.";
}
?>
