<link href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.2.19/tailwind.min.css" rel="stylesheet">
<?php
$host = 'localhost';
$db   = 'ccgnimex';
$user = 'ccgnimex';
$pass = 'aaaaaaac';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$pdo = new PDO($dsn, $user, $pass);

// Mengambil data Server dan Platform
$query = $pdo->query("SELECT DISTINCT Server, Platform FROM cookies");
$data = $query->fetchAll(PDO::FETCH_ASSOC);

// Menghandle update jika form disubmit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $server = $_POST['server'];
    $platform = $_POST['platform'];
    $cookie_data = $_POST['cookie_data'];
    
    $stmt = $pdo->prepare("UPDATE cookies SET cookie_data = ? WHERE Server = ? AND Platform = ?");
    $stmt->execute([$cookie_data, $server, $platform]);
}

// Form dengan dropdown dan textarea
echo '<div class="bg-white p-6 rounded shadow-md w-96">';
echo '<h1 class="text-xl font-bold mb-4">Update Cookie Data</h1>';

echo '<form method="post" action="">';

// Dropdown Server
echo '<div class="mb-4">';
echo '<label for="server" class="block text-sm font-medium text-gray-700">Server</label>';
echo '<select id="server" name="server" class="mt-1 block w-full...">';
foreach ($data as $row) {
    echo '<option value="' . $row['Server'] . '">' . $row['Server'] . '</option>';
}
echo '</select></div>';

// Dropdown Platform
echo '<div class="mb-4">';
echo '<label for="platform" class="block text-sm font-medium text-gray-700">Platform</label>';
echo '<select id="platform" name="platform" class="mt-1 block w-full...">';
foreach ($data as $row) {
    echo '<option value="' . $row['Platform'] . '">' . $row['Platform'] . '</option>';
}
echo '</select></div>';

// Textarea untuk cookie data
echo '<div class="mb-4">';
echo '<label for="cookie_data" class="block text-sm font-medium text-gray-700">Cookie Data</label>';
echo '<textarea id="cookie_data" name="cookie_data" rows="4" class="mt-1 block w-full..."></textarea>';
echo '</div>';

// Tombol Submit
echo '<div>';
echo '<button type="submit" class="w-full bg-blue-500...">Update</button>';
echo '</div>';

echo '</form>';
echo '</div>';

?>