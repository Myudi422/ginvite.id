<?php
header('Content-Type: application/json');

$host = 'localhost'; // Ganti dengan host Anda
$username = 'ccgnimex'; // Ganti dengan username database Anda
$password = 'aaaaaaac'; // Ganti dengan password database Anda
$database = 'ccgnimex'; // Ganti dengan nama database Anda

// Buat koneksi ke database
$conn = mysqli_connect($host, $username, $password, $database);

if (!$conn) {
    die(json_encode(['error' => 'Koneksi ke database gagal']));
}

// Ambil notifikasi dari database (misalnya, ambil notifikasi dengan ID 1)
$sql = "SELECT notification_text FROM notifikasi WHERE id = 1"; // Ganti dengan kriteria yang sesuai
$result = mysqli_query($conn, $sql);

if (!$result) {
    die(json_encode(['error' => 'Error mengambil notifikasi dari database']));
}

$row = mysqli_fetch_assoc($result);
$notificationText = $row['notification_text'];

// Tutup koneksi ke database
mysqli_close($conn);

// Kirim data notifikasi dalam format JSON
echo json_encode(['notificationText' => $notificationText]);
?>
