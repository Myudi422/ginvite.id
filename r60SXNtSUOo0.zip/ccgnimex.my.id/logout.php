<?php
// Mulai sesi
session_start();

// Hapus semua sesi
session_unset();
session_destroy();

// Hapus cookie otentikasi jika ada
if (isset($_COOKIE['telegram_login'])) {
    setcookie('telegram_login', '', time() - 3600, "/");
}

// Arahkan ke halaman login
header('Location: login.php');
exit(); // Pastikan tidak ada kode berikutnya yang dijalankan
?>
