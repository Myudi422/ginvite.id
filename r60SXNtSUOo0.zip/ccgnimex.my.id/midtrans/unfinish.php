<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pembayaran Belum Selesai</title>
</head>
<body>
    <h1>Transaksi Anda belum selesai</h1>
    <p>Silakan selesaikan pembayaran Anda sesuai dengan instruksi yang diberikan.</p>
</body>
</html>