
<?php

require_once('../vendor/autoload.php');

\Midtrans\Config::$serverKey = 'SB-Mid-server-Z0n-nKvhbWBD5qVZyKdGyxfY';
\Midtrans\Config::$isProduction = false;

$phone = isset($_POST['phone']) ? $_POST['phone'] : $_GET['phone'];
$expiry_date = isset($_POST['expiry_date']) ? $_POST['expiry_date'] : $_GET['expiry_date'];

// Set the price based on expiry_date
if ($expiry_date == '1_week') {
    $price = 15000;
} else if ($expiry_date == '1_month') {
    $price = 25000;
} else {
    $price = 10000;  // default price
}

$transaction_details = array(
    'order_id' => rand(),
    'gross_amount' => $price,
);

$item_details = array(array(
    'id' => '001',
    'price' => $price,
    'quantity' => 1,
    'name' => "Pembayaran"
));

$transaction = array(
    'transaction_details' => $transaction_details,
    'item_details' => $item_details,
    'custom_field1' => $phone,
    'custom_field2' => $transaction_details['order_id'],
    'custom_field3' => $expiry_date
);

$snapToken = \Midtrans\Snap::getSnapToken($transaction);

$server = "localhost";
$username = "ccgnimex";
$password = "aaaaaaac";
$dbname = "ccgnimex";

$conn = new mysqli($server, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$stmt = $conn->prepare("INSERT INTO transactions (order_id, phone) VALUES (?, ?)");
$stmt->bind_param("is", $transaction_details['order_id'], $phone);

if (!$stmt->execute()) {
    die("Error inserting transaction: " . $stmt->error);
}

$stmt->close();
$conn->close();

header("Location: https://app.sandbox.midtrans.com/snap/v2/vtweb/{$snapToken}");
exit();
