<?php
require_once('../vendor/autoload.php');

\Midtrans\Config::$serverKey = 'SB-Mid-server-Z0n-nKvhbWBD5qVZyKdGyxfY';
\Midtrans\Config::$isProduction = false;

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo "Invalid request";
    exit();
}

$notif = new \Midtrans\Notification();

// Log the received notification
file_put_contents("midtrans_log.txt", json_encode($notif) . "\n", FILE_APPEND);

echo "OK";
