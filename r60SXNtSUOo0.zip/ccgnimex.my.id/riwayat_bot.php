<?php
// Start the session
session_start();

?>

<!-- Tambahkan kontainer untuk menampilkan data -->
<div class="data-container"></div>
<br>
<!-- Tambahkan elemen untuk menempatkan tombol di tengah -->
<div class="text-center">
    <!-- Tambahkan tombol prev/next -->
    <button class="btn btn-primary prev-button1">Prev</button>
    <button class="btn btn-primary next-button1">Next</button>

    <!-- Tambahkan elemen untuk menampilkan nomor halaman -->
    <span class="page-number"> | Page 1</span>
</div>

<script>
// Variabel untuk menyimpan halaman saat ini
let currentPage1 = 1;

// Menangani klik tombol prev/next
document.querySelector('.prev-button1').addEventListener('click', function() {
    // Mengurangi nilai halaman saat ini
    currentPage1--;

    // Mengambil data baru dari server
    fetchData1(currentPage1);
});

document.querySelector('.next-button1').addEventListener('click', function() {
    // Menambah nilai halaman saat ini
    currentPage1++;

    // Mengambil data baru dari server
    fetchData1(currentPage1);
});

// Fungsi untuk mengambil data dari server
function fetchData1(page) {
    // Mengirim permintaan AJAX ke server untuk mengambil data
    var xhr = new XMLHttpRequest();
    xhr.open('GET', 'proses_riwayat.php?page=' + page);
    xhr.onload = function() {
        if (xhr.status === 200) {
            // Memperbarui konten halaman dengan data baru
            document.querySelector('.data-container').innerHTML = xhr.responseText;

            // Memperbarui nomor halaman
            document.querySelector('.page-number').textContent = ' | Page ' + page;

            // Cek apakah berada di halaman pertama
            if (page === 1) {
                // Jika ya, nonaktifkan tombol prev
                document.querySelector('.prev-button1').setAttribute('disabled', 'disabled');
            } else {
                // Jika tidak, aktifkan tombol prev
                document.querySelector('.prev-button1').removeAttribute('disabled');
            }

            // Cek apakah ada data yang ditampilkan
            if (xhr.responseText.trim() === '') {
                // Jika tidak, nonaktifkan tombol next
                document.querySelector('.next-button1').setAttribute('disabled', 'disabled');
            } else {
                // Jika ya, aktifkan tombol next
                document.querySelector('.next-button1').removeAttribute('disabled');
            }
        }
    };
    xhr.send();
}

// Mengambil data awal saat halaman dimuat
fetchData1(currentPage1);
</script>

<style>
table {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    grid-gap: 10px;
}

td {
    position: relative;
}

td img {
    width: 100%;
    height: 210px;
    object-fit: cover;
    margin-bottom: 10px;
}

td span {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    background-color: rgba(0, 0, 0, 0.8);
    color: white;
    padding: 5px;
}

@media (max-width: 600px) {
    table {
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    }
}
@media (max-width: 600px) {
    td span {
        font-size: 9px;
    }
}
</style>