<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name=viewport content="width=device-width,initial-scale=1,maximum-scale=1,minimum-scale=1,user-scalable=no,minimal-ui">
    <meta name="referrer" content="no-referrer">
    <title>xgplayer</title>
    <style type="text/css">
      html, body {width:100%;height:100%;margin:auto;overflow: hidden;}
    </style>
  </head>
  <body>
    <div id="mse"></div>
<link rel="stylesheet" href="https://unpkg.byted-static.com/xgplayer/3.0.1/dist/index.min.css"/>
<script charset="utf-8" src="https://unpkg.byted-static.com/xgplayer/3.0.1/dist/index.min.js"></script>

       <script>
        const config = {
          "id": "mse",
          "url": "//lf3-static.bytednsdoc.com/obj/eden-cn/nupenuvpxnuvo/xgplayer_doc/xgplayer-demo.mp4",
          "playsinline": false,
          "poster": "lf3-static.bytednsdoc.com/obj/eden-cn/nupenuvpxnuvo/xgplayer_doc/xgplayer-demo.mp4",
          "plugins": [],
          "x5-video-player-fullscreen": "true",
          "x5-video-orientation": "landscape",
          "fluid": true
        }
        
        let player = new Player(config)
        
      </script>  </body>
</html>
