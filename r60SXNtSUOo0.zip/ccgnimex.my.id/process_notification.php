<?php
$anime_id = $_POST['anime_id'];
$telegram_id = $_POST['telegram_id'];

$connection = mysqli_connect("localhost", "ccgnimex", "aaaaaaac", "ccgnimex");

$check_query = "SELECT COUNT(*) as count FROM add_notif WHERE anime_id = '$anime_id'";
$result = mysqli_query($connection, $check_query);
$row = mysqli_fetch_assoc($result);
$is_anime_added = ($row['count'] > 0);

if ($is_anime_added) {
    $delete_query = "DELETE FROM add_notif WHERE anime_id = '$anime_id'";
    mysqli_query($connection, $delete_query);
    echo "removed";
} else {
    $insert_query = "INSERT INTO add_notif (telegram_id, anime_id, created_at) VALUES ('$telegram_id', '$anime_id', NOW())";
    mysqli_query($connection, $insert_query);
    echo "success";
}

mysqli_close($connection);
?>
