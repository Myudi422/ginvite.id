<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Get the video URL, start time, and end time from the POST data
    $videoUrl = $_POST["video_url"];
    $startTime = $_POST["start_time"];
    $endTime = $_POST["end_time"];

    // Define the path to the folder where the clips will be saved
    $clipFolder = "klip/";

    // Generate a unique filename for the clip
    $clipFilename = uniqid("clip_") . ".mp4";
    $clipPath = $clipFolder . $clipFilename;

        // Execute the video cutting command using FFmpeg
        $ffmpegCmd = "ffmpeg -i " . escapeshellarg($videoUrl) . " -ss " . escapeshellarg($startTime) . " -to " . escapeshellarg($endTime) . " -c:v copy -c:a copy " . escapeshellarg($clipPath);
        exec($ffmpegCmd, $output, $returnValue);
    if ($returnValue === 0) {
        // Video cutting successful
        echo "success";
    } else {
        // Video cutting failed
        echo "error";
    }
} elseif ($_SERVER["REQUEST_METHOD"] === "GET" && isset($_GET["download"])) {
    // Handle download request
    if ($_GET["download"] === "true" && isset($_GET["video_url"]) && isset($_GET["start_time"]) && isset($_GET["end_time"])) {
        $videoUrl = $_GET["video_url"];
        $startTime = $_GET["start_time"];
        $endTime = $_GET["end_time"];

        // Define the path to the folder where the clips are saved
        $clipFolder = "klip/";

        // Generate the filename for the clip
        $clipFilename = uniqid("clip_") . ".mp4";
        $clipPath = $clipFolder . $clipFilename;

        // Execute the video cutting command using FFmpeg
        $ffmpegCmd = "ffmpeg -i " . escapeshellarg($videoUrl) . " -ss " . escapeshellarg($startTime) . " -to " . escapeshellarg($endTime) . " -c:v copy -c:a copy " . escapeshellarg($clipPath);
        exec($ffmpegCmd, $output, $returnValue);

        if ($returnValue === 0) {
            // Video cutting successful, initiate download
            header('Content-Description: File Transfer');
            header('Content-Type: application/octet-stream');
            header('Content-Disposition: attachment; filename=' . basename($clipPath));
            header('Content-Transfer-Encoding: binary');
            header('Expires: 0');
            header('Cache-Control: must-revalidate');
            header('Pragma: public');
            header('Content-Length: ' . filesize($clipPath));
            ob_clean();
            flush();
            readfile($clipPath);
            exit;
        } else {
            // Video cutting failed
            echo "Error: Video cutting failed";
        }
    } else {
        // Invalid request parameters for download
        echo "Error: Invalid request parameters for download";
    }
} else {
    // Handle invalid request method
    echo "Error: Invalid request method";
}
?>
