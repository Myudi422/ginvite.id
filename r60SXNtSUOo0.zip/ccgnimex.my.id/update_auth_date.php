<?php
// Start the session
session_start();

// When the user is not logged in, return an error response
if (!isset($_SESSION['logged-in'])) {
  http_response_code(401); // Unauthorized
  echo 'User not logged in';
  exit();
}

// Set timezone to Asia/Jakarta (WIB)
date_default_timezone_set('Asia/Jakarta');

// Database connection details
$db_host = 'localhost';
$db_name = 'ccgnimex';
$db_user = 'ccgnimex';
$db_pass = 'aaaaaaac';

// Connect to the database
try {
  $db = new PDO("mysql:host=$db_host;dbname=$db_name;charset=utf8mb4", $db_user, $db_pass);
  $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
  http_response_code(500); // Internal Server Error
  echo 'Database connection failed';
  exit();
}

// Update the auth_date for the logged-in user
$query = $db->prepare(
  "UPDATE users_web
   SET auth_date = CONVERT_TZ(NOW(), '+00:00', '+07:00')
   WHERE telegram_id = :telegram_id"
);
$query->bindParam(':telegram_id', $_SESSION['telegram_id']);
if (!$query->execute()) {
  http_response_code(500); // Internal Server Error
  echo 'Failed to update auth_date';
  exit();
}

http_response_code(200); // OK
echo 'Auth date updated successfully';
?>
