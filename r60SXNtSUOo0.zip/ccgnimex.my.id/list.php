<?php
$servername = "localhost";
$username = "ccgnimex";
$password = "aaaaaaac";
$dbname = "ccgnimex";

// Membuat koneksi ke database
$conn = new mysqli($servername, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
// Import database connection and class
require('db-config.php');


// Get current logged in user data with session
$user_data = $db->Select(
    "SELECT *
        FROM `users_web`
            WHERE `telegram_id` = :id",
    [
        'id' => $_SESSION['telegram_id']
    ]
);
// Menentukan jumlah data per halaman
$limit = 9;

// Menentukan halaman yang aktif dari data POST
$page = isset($_POST['page']) ? $_POST['page'] : 1;

// Menghitung offset data
$offset = ($page - 1) * $limit;

$sql = "SELECT DISTINCT e.anime FROM episodes e JOIN watched w ON e.id = w.episode WHERE w.user = " . $_SESSION['telegram_id'] . " ORDER BY w.id DESC LIMIT $limit OFFSET $offset";
$result = $conn->query($sql);

echo '<div class="card mb-4" style="margin-bottom: calc(1.5rem + 1px) !important;">
  <div class="card-header">
    <div class="d-flex justify-content-between align-items-center">
      <strong>Terakhir Ditonton</strong>
      <i class="fas fa-clock"></i>
    </div>
  </div>
  <div class="card-body">';
if ($result->num_rows > 0) {
    $max_columns = 9; // jumlah maksimum kolom per baris untuk desktop
    if (isset($_SERVER['HTTP_USER_AGENT']) && preg_match('/Mobi/', $_SERVER['HTTP_USER_AGENT'])) {
        // Jika user agent mengandung kata "Mobi", asumsikan pengguna menggunakan perangkat mobile
        $max_columns = 3; // jumlah maksimum kolom per baris untuk mobile
    }
    $current_column = 0; // kolom saat ini
    echo "<table><tr>";
    while($row = $result->fetch_assoc()) {
        // Menggunakan AniList API untuk mengambil data gambar dan judul anime berdasarkan id anime
        $query = '
        query ($id: Int) {
          Media (id: $id, type: ANIME) {
            title {
              romaji
            }
            coverImage {
              large
            }
          }
        }
        ';

        $variables = [
            'id' => $row["anime"]
        ];

        // ... kode untuk mengirim permintaan ke AniList API dan mengurai respons ...

        // Menampilkan gambar dan judul anime dalam bentuk grid
        // ...

        // Cek apakah jumlah kolom sudah mencapai batas maksimum
        if (++$current_column >= $max_columns) {
            // Jika ya, tambahkan baris baru dan reset kolom saat ini
            echo "</tr><tr>";
            $current_column = 0;
        }
    }
    echo "</tr></table>";

    // Menampilkan tombol prev/next dengan atribut "data-page" yang berisi nomor halaman yang sesuai
    if ($page > 1) {
        echo "<button class='prev' data-page='" . ($page - 1) . "'>Prev</button>";
    }
    echo "<button class='next' data-page='" . ($page + 1) . "'>Next</button>";
} else {
    echo "0 results";
}
echo '</div></div>';
$conn->close();
?>

<style>
table {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    grid-gap: 10px;
}

td {
    position: relative;
}

td img {
    width: 100%;
    height: 230px;
    object-fit: cover;
    margin-bottom: 10px;
}

td span {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    background-color: rgba(0, 0, 0, 0.8);
    color: white;
    padding: 5px;
}

@media (max-width: 600px) {
    table {
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    }
}
</style>