<?php
$host = '127.0.0.1';
$user = 'ccgnimex';
$password = 'aaaaaaac';
$dbname = 'ccgnimex';

$conn = new mysqli($host, $user, $password, $dbname);

if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}

$sql = 'SELECT anime_id FROM nonton';
$result = $conn->query($sql);

$animeIds = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $animeIds[] = $row['anime_id'];
    }
}
$conn->close();
?>



<div id="anime-list-tv"></div>
<br>
<div class="button-containertv">
  <button id="prev-button-tv">Prev</button>
  <button id="next-button-tv">Next</button>
</div>

<style>
.button-containertv {
  text-align: center;
}

.button-containertv button {
  background-color: #007bff;
  color: white;
  border: none;
  padding: 10px 20px;
  border-radius: 5px;
  cursor: pointer;
}

.button-containertv button:hover {
  background-color: #0069d9;
}

#anime-list-tv {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
  grid-gap: 10px;
}

@media screen and (max-width: 600px) {
  #anime-list-tv {
    grid-template-columns: repeat(auto-fit, minmax(110px, 1fr));
  }
}
.animex-item {
  position: relative;
}

.animex-item img {
  width: 100%;
}

.animex-title {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  background-color: rgba(0, 0, 0, 0.8);
  color: white;
  padding:10px;
text-align:center;
white-space:nowrap;
overflow:hidden;
text-overflow:ellipsis;
}

.animex-rating {
  position: absolute;
  top: 5px;
  right: 5px;
  background-color: rgba(0, 0, 0, 0.7);
  color: white;
  padding: 5px;
  border-radius: 5px;
}

.animex-batch {
  position: absolute;
  font-size: 13px;
  top: 45px;
  right: 5px;
  background-color: rgba(0, 0, 0, 0.7);
  color: white;
  padding: 5px;
  border-radius: 5px;
}

.animex-star {
    margin-right:0px;
    color:yellow;
    vertical-align: middle;
}

.animex-rating span + span {
    vertical-align: middle;
}

.animex-batch span + span {
    vertical-align: middle;
}

@media screen and (max-width: 600px) {
    .animex-rating {
        font-size: 12px;
        padding: 3px;
        border-radius: 3px;
    }
    .animex-batch {
        font-size: 8px;
        padding: 3px;
        border-radius: 3px;
    }
}

.animex-info {
  position: absolute;
  top: 5px;
  left: 35px;
  background-color: rgba(0, 0, 0, 0.7);
  color: white;
  padding: 5px;
  border-radius: 5px;
  cursor: pointer;
}

.animex-info:hover {
  background-color: #007bff;
}

.animex-info i {
  font-size: 16px;
}
.animex-info-no-trailer {
  left: 5px;
}
</style>

<script>
const query = `
  query ($id_in: [Int], $page: Int, $perPage: Int) {
    Page (page: $page, perPage: $perPage) {
      pageInfo {
        total
        currentPage
        lastPage
        hasNextPage
        perPage
      }
      media (id_in: $id_in, type: ANIME, status: FINISHED, format: TV, sort: POPULARITY_DESC) {
        id
        title {
          romaji
          english
          native
        }
        coverImage {
          large
        }
        trailer {
          id
          site
          thumbnail
        }
        averageScore
        description(asHtml:false)
        genres
        format
        episodes
        season
        status
        studios(isMain:true){
            nodes{
                name
            }
        }
        relations{
            edges{
                relationType(version:2)
                node{
                    title{
                        romaji
                    }
                    type
                }
            }
        }
      }
    }
  }
`;

// Mendeteksi apakah perangkat mobile atau desktop
const isMobile = window.matchMedia('(max-width: 600px)').matches;

// Tentukan jumlah item per halaman berdasarkan perangkat
const perPage = isMobile ? 6 : 18;

const variables = {
  page: 1,
  perPage: perPage,
  id_in: <?php echo json_encode($animeIds); ?>,
};
const url = 'https://graphql.anilist.co';

async function tvfetchData() {
  // Buat kunci cache untuk kueri dan variabel ini
  const cacheKey = JSON.stringify({ query, variables });

  try {
    // Coba ambil data dari penyimpanan lokal (localforage) terlebih dahulu
    const cachedData = await getCachedDataFromLocalforage(cacheKey);
    if (cachedData) {
      // Jika data ada di penyimpanan lokal, gunakan data tersebut
      return cachedData;
    }

    // Jika tidak ada data di penyimpanan lokal, ambil data dari server
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
      body: JSON.stringify({
        query,
        variables,
      }),
    });

    const data = await response.json();

    // Simpan data ke penyimpanan lokal (localforage) untuk penggunaan berikutnya
    await storeDataInLocalforage(cacheKey, data);

    return data;
  } catch (error) {
    console.error(error);
    throw error;
  }
}

// Panggil fetchData untuk mengambil data
tvfetchData()
  .then(data => {
    // Gunakan data yang diambil di sini
    console.log(data);
  })
  .catch(error => {
    // Tangani kesalahan di sini
    console.error(error);
  });

// Fungsi untuk menyimpan data di penyimpanan lokal (localforage)
async function storeDataInLocalforage(key, data) {
  await localforage.setItem(key, data);
}

// Fungsi untuk mengambil data dari penyimpanan lokal (localforage)
async function getCachedDataFromLocalforage(key) {
  const cachedData = await localforage.getItem(key);
  return cachedData;
}

async function tvrenderData() {
    const data = await tvfetchData();
    const animeList = data.data.Page.media;
    const container = document.querySelector('#anime-list-tv');
    container.innerHTML = '';
    animeList.forEach(anime => {
        const animeElement = document.createElement('div');
        animeElement.classList.add('animex-item');
        let title = anime.title.romaji;
        if (title.length > 24) {
            title = title.substring(0, 24) + '...';
        }

// Tambahkan ikon trailer jika anime memiliki trailer
let trailerIcon = '';
if (anime.trailer) {
    trailerIcon = `
        <a class="popup-youtube" href="https://www.youtube.com/watch?v=${anime.trailer.id}" target="_blank">
            <div class="animex-trailer">
                <i class="fas fa-film"></i>
            </div>
        </a>
    `;
}

// Tambahkan ikon info
let infoIcon = '';
if (anime.trailer) {
    infoIcon = `
        <div class="animex-info">
            <i class="fas fa-info-circle"></i>
        </div>
    `;
} else {
    infoIcon = `
        <div class="animex-info animex-info-no-trailer">
            <i class="fas fa-info-circle"></i>
        </div>
    `;
}

// Fungsi untuk memeriksa apakah elemen dalam viewport
function isElementInViewport(el) {
  const rect = el.getBoundingClientRect();
  return (
    rect.top >= 0 &&
    rect.left >= 0 &&
    rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
    rect.right <= (window.innerWidth || document.documentElement.clientWidth)
  );
}

// Fungsi untuk memuat gambar ketika elemen terlihat
function loadImagesOnScroll() {
  const images = document.querySelectorAll('.lazy-load');
  images.forEach((img) => {
    if (isElementInViewport(img) && !img.src) {
      img.src = img.getAttribute('data-src');
      img.classList.remove('lazy-load');
    }
  });
}

// Event listener untuk memanggil loadImagesOnScroll saat pengguna menggulir halaman
window.addEventListener('scroll', loadImagesOnScroll);

// Panggil fungsi loadImagesOnScroll pada awalnya untuk memuat gambar yang terlihat saat halaman pertama dimuat
loadImagesOnScroll();

// Bagian yang Anda berikan sebelumnya
animeElement.innerHTML = `
  <img src="${anime.coverImage.large}" alt="${anime.title.romaji}">
  ${trailerIcon}
  ${infoIcon}
  <div class="animex-title">${title}</div>
  <div class="animex-rating">
    <span class="animex-star">★</span>
    ${anime.averageScore}
  </div>
  <div class="animex-batch">
    <span class="animex-download">
      <i class="far fa-eye"></i> View More
    </span>
  </div>
`;

// Tambahkan atribut data-src ke gambar yang ingin dimuat secara lazy loading
const animeImage = animeElement.querySelector('img');
animeImage.classList.add('lazy-load');
animeImage.setAttribute('data-src', anime.coverImage.large);

async function translateText(text) {
    const response = await fetch(`translate.php?text=${encodeURIComponent(text)}`);
    const data = await response.json();
    return data.translatedText;
}
// Tambahkan event listener untuk ikon download
const batchElement = animeElement.querySelector('.animex-batch');
batchElement.onclick = event => {
    event.stopPropagation();
    const animeId = anime.id;
    window.open(`https://ccgnimex.my.id/anime_detail.php?id=${animeId}`, '_blank');
};

// Tambahkan event listener ke ikon info
const infoElement = animeElement.querySelector('.animex-info');
infoElement.onclick = async event => {
    event.stopPropagation();
    // Tampilkan modal Bootstrap 5 dengan informasi anime
    const modalElement = document.createElement('div');
    modalElement.classList.add('modal', 'fade');
    modalElement.tabIndex = -1;
    let prequel = '';
    let sequel = '';
    anime.relations.edges.forEach(edge => {
        if (edge.relationType === 'PREQUEL') {
            prequel += edge.node.title.romaji + ' ';
        } else if (edge.relationType === 'SEQUEL') {
            sequel += edge.node.title.romaji + ' ';
        }
    });
    let studio = '';
    anime.studios.nodes.forEach(node => {
        studio += node.name + ' ';
    });
    let translatedDescription = await translateText(anime.description);
    if (translatedDescription.length > 100) {
        translatedDescription = translatedDescription.substring(0, 100) + '...';
    }
    modalElement.innerHTML = `
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">${anime.title.romaji}</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <table class="table">
                        <tr>
                            <th>Sinopsis</th>
                            <td>${translatedDescription}</td>
                        </tr>
                        <tr>
                            <th>Genre</th>
                            <td>${anime.genres.join(', ')}</td>
                        </tr>
                        <tr>
                            <th>Format</th>
                            <td>${anime.format}</td>
                        </tr>
                        <tr>
                            <th>Episode</th>
                            <td>${anime.episodes}</td>
                        </tr>
                        <tr>
                            <th>Season</th>
                            <td>${anime.season}</td>
                        </tr>
                        <tr>
                            <th>Status</th>
                            <td>${anime.status}</td>
                        </tr>
                        <tr>
                            <th>Studio</th>
                            <td>${studio}</td>
                        </tr>                        
                        <tr>
                            <th>Prequel</th>
                            <td>${prequel}</td>
                        </tr>                        
                        <tr>
                            <th>Sequel</th>
                            <td>${sequel}</td>
                        </tr>                        
                    </table>                
                </div>
            </div>
        </div>`;
    document.body.appendChild(modalElement);
    const modal = new bootstrap.Modal(modalElement);
    modal.show();
};

        // Tambahkan event listener untuk mencegah event bubbling saat ikon trailer diklik
        if (anime.trailer) {
            const trailerElement = animeElement.querySelector('.popup-youtube');
            trailerElement.onclick = event => {
                event.stopPropagation();
            };
        }

        animeElement.onclick = () => {
            window.location.href = `https://ccgnimex.my.id/streaming.php?id=${anime.id}&episode=1`;
        };

        container.appendChild(animeElement);
    });

    
    // Perbarui tampilan tombol prev dan next
    const pageInfo = data.data.Page.pageInfo;
    const prevButton = document.querySelector('#prev-button-tv');
    const nextButton = document.querySelector('#next-button-tv');
    if (pageInfo.currentPage === 1) {
        prevButton.classList.add('disabled');
    } else {
        prevButton.classList.remove('disabled');
    }
    if (pageInfo.currentPage === pageInfo.lastPage) {
        nextButton.classList.add('disabled');
    } else {
        nextButton.classList.remove('disabled');
    }
    
    // Perbarui tampilan jumlah halaman saat ini dan total halaman
    pageIndicator.textContent = `| Page ${pageInfo.currentPage}`;
    
    // Inisialisasi Magnific Popup untuk menampilkan trailer dalam popup
    $('.popup-youtube').magnificPopup({
        type: 'iframe',
        mainClass: 'mfp-fade',
        removalDelay: 160,
        preloader: false,
        fixedContentPos: false
    });
}
// Tambahkan elemen baru untuk menampilkan jumlah halaman saat ini dan total halaman
const pageIndicator = document.createElement('span');
pageIndicator.id = 'page-indicator';
document.querySelector('.button-containertv').appendChild(pageIndicator);

document.querySelector('#prev-button-tv').addEventListener('click',()=>{
   if(variables.page>1 && !event.currentTarget.classList.contains('disabled')){
       variables.page-=1;
       tvrenderData();
   } 
});

document.querySelector('#next-button-tv').addEventListener('click',async()=>{
   if(!event.currentTarget.classList.contains('disabled')){
       const data=await tvfetchData();
       if(data.data.Page.pageInfo.hasNextPage){
           variables.page+=1;
           tvrenderData();
       } 
   }
});

// Tambahkan kelas CSS untuk mengubah tampilan tombol yang dinonaktifkan dan ikon trailer
const style = document.createElement('style');
style.textContent += `
.button-containertv button.disabled {
  background-color: #6c757d;
  cursor: not-allowed;
}

.animex-trailer {
  position: absolute;
  top: 5px;
  left: 5px;
  background-color: rgba(0, 0, 0, 0.7);
  color: white;
  padding: 5px;
  border-radius: 5px;
  cursor: pointer;
}

.animex-trailer:hover {
  background-color: #007bff;
}

.animex-trailer i {
  font-size: 16px;
}
`;
document.head.appendChild(style);

tvrenderData();
</script>