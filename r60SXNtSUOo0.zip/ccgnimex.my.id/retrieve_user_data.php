<?php
// Database connection details
$db_host = 'localhost';
$db_name = 'ccgnimex';
$db_user = 'ccgnimex';
$db_pass = 'aaaaaaac';

try {
  // Connect to the database
  $db = new PDO("mysql:host=$db_host;dbname=$db_name;charset=utf8mb4", $db_user, $db_pass);
  $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

  // Set timezone to Asia/Jakarta (WIB)
  $db->exec("SET time_zone = '+07:00'");

  // Retrieve user data from the database
  $query = $db->prepare("SELECT profile_picture, telegram_username, last_login FROM users_web");
  $query->execute();
  $user_data = $query->fetchAll(PDO::FETCH_ASSOC);

  // Return user data as JSON
  header('Content-Type: application/json');
  echo json_encode($user_data);
} catch (PDOException $e) {
  // Database connection or query error
  http_response_code(500); // Internal Server Error
  echo 'Failed to retrieve user data';
  exit();
}
?>
