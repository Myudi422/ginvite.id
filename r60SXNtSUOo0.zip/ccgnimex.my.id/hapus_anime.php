<?php
session_start();

if (isset($_POST['animeId'])) {
    $servername = "localhost";
    $username = "ccgnimex";
    $password = "aaaaaaac";
    $dbname = "ccgnimex";

    // Membuat koneksi ke database
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Escape animeId untuk menghindari serangan SQL injection
    $animeId = $conn->real_escape_string($_POST['animeId']);

    // Periksa apakah anime yang akan dihapus dimiliki oleh pengguna yang sedang login
    $sql = "SELECT anime_id FROM waktu_terakhir_tontonan WHERE telegram_id = " . $_SESSION['telegram_id'] . " AND anime_id = " . $animeId;
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Anime ditemukan dalam riwayat pengguna, maka hapus dari database
        $deleteSql = "DELETE FROM waktu_terakhir_tontonan WHERE telegram_id = " . $_SESSION['telegram_id'] . " AND anime_id = " . $animeId;
        $conn->query($deleteSql);
    }

    $conn->close();
}
?>
