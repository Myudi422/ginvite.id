<?php
// Database credentials
$host = 'localhost';
$username = 'ccgnimex';
$password = 'aaaaaaac';
$database = 'ccgnimex';

// Create a new database connection
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the Telegram ID, episode ID, and checked state from the AJAX request
$telegramID = $_POST['telegram_id'];
$episodeID = $_POST['episode_id'];
$isChecked = $_POST['checked'];

// Update the checkbox state in the database
$query = "REPLACE INTO episode_states (telegram_id, episode_id, checked) VALUES ('$telegramID', '$episodeID', '$isChecked')";
$conn->query($query);

$conn->close();
?>
